﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace Tante_Emma.v2.Kasse
{
    class Artikel
    {
        private int _id;
        private string _name;
        private double _preis;
        private string _artikeltyp;
        private int _menge;
        private int _regal;
        private int _platz;
        private List<Artikel> listArtikel = new List<Artikel>();
        private MySQL_Anbindung.MySQLConnect con = new MySQL_Anbindung.MySQLConnect();

        public int ID { get { return _id; } set { _id = value; } }

        public string Name { get { return _name; } set { _name = value; }  }

        public string Artikeltyp { get { return _artikeltyp; } set { _artikeltyp = value; } }

        public double Preis { get { return _preis; } set { _preis = value; } }

        public int Menge { get { return _menge; } set { _menge = value; } }

        public int Regalnr { get { return _regal; } set { _regal = value; } }

        public int Platznr { get { return _platz; } set { _platz = value; } }

        public DataTable Update_Database()
        {
          
            con.MysqlQuery("UPDATE Bestand SET Menge = "+Menge+" WHERE fiArtikel = "+ID+" AND RegalNummer = "+Regalnr+" And Platznummer = "+Platznr+";");
            return con.QueryEx();
        }
        
        public List<Artikel> getArtikel()
        {
      
            con.MysqlQuery("SELECT * FROM ARTIKEL A INNER JOIN BESTAND B ON (A.ID = B.FIARTIKEL) ORDER BY A.NAME ASC;");

            foreach (DataRow row in con.QueryEx().Rows)
            {
                listArtikel.Add(new Artikel()
                {
                    ID = (int)row["ID"],
                    Name = (string)row["Name"],
                    Artikeltyp = (string)row["Artikeltyp"],
                    Preis = (double)row["Preis"],
                    Menge = (int)row["Menge"],
                    Regalnr = (int)row["RegalNummer"],
                    Platznr = (int)row["Platznummer"]
                });
            }

            return listArtikel;

        }
    }
}
