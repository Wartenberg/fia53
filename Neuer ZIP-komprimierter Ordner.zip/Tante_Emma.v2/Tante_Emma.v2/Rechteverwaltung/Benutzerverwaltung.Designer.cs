﻿namespace Tante_Emma.v2.Rechteverwaltung
{
    partial class Benutzerverwaltung
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Chef");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("Hilfskraft");
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("Personal");
            this.btn_Hinzufügen = new System.Windows.Forms.Button();
            this.btn_Entfernen = new System.Windows.Forms.Button();
            this.btn_Bearbeiten = new System.Windows.Forms.Button();
            this.btn_Schließen = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tc_Benutzer = new System.Windows.Forms.TabPage();
            this.tv_Benutzer = new System.Windows.Forms.TreeView();
            this.lb_BenutzerRechte = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lb_Benutzer = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tc_Benutzer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_Hinzufügen
            // 
            this.btn_Hinzufügen.Location = new System.Drawing.Point(123, 315);
            this.btn_Hinzufügen.Name = "btn_Hinzufügen";
            this.btn_Hinzufügen.Size = new System.Drawing.Size(75, 23);
            this.btn_Hinzufügen.TabIndex = 1;
            this.btn_Hinzufügen.Text = "Hinzufügen";
            this.btn_Hinzufügen.UseVisualStyleBackColor = true;
            this.btn_Hinzufügen.Click += new System.EventHandler(this.btn_Hinzufügen_Click);
            // 
            // btn_Entfernen
            // 
            this.btn_Entfernen.Location = new System.Drawing.Point(204, 315);
            this.btn_Entfernen.Name = "btn_Entfernen";
            this.btn_Entfernen.Size = new System.Drawing.Size(75, 23);
            this.btn_Entfernen.TabIndex = 2;
            this.btn_Entfernen.Text = "Entfernen";
            this.btn_Entfernen.UseVisualStyleBackColor = true;
            this.btn_Entfernen.Click += new System.EventHandler(this.btn_Entfernen_Click);
            // 
            // btn_Bearbeiten
            // 
            this.btn_Bearbeiten.Location = new System.Drawing.Point(285, 315);
            this.btn_Bearbeiten.Name = "btn_Bearbeiten";
            this.btn_Bearbeiten.Size = new System.Drawing.Size(75, 23);
            this.btn_Bearbeiten.TabIndex = 3;
            this.btn_Bearbeiten.Text = "Bearbeiten...";
            this.btn_Bearbeiten.UseVisualStyleBackColor = true;
            this.btn_Bearbeiten.Click += new System.EventHandler(this.btn_Bearbeiten_Click);
            // 
            // btn_Schließen
            // 
            this.btn_Schließen.Location = new System.Drawing.Point(301, 384);
            this.btn_Schließen.Name = "btn_Schließen";
            this.btn_Schließen.Size = new System.Drawing.Size(75, 23);
            this.btn_Schließen.TabIndex = 4;
            this.btn_Schließen.Text = "Schließen";
            this.btn_Schließen.UseVisualStyleBackColor = true;
            this.btn_Schließen.Click += new System.EventHandler(this.btn_Schließen_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tc_Benutzer);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(376, 370);
            this.tabControl1.TabIndex = 6;
            // 
            // tc_Benutzer
            // 
            this.tc_Benutzer.Controls.Add(this.tv_Benutzer);
            this.tc_Benutzer.Controls.Add(this.lb_BenutzerRechte);
            this.tc_Benutzer.Controls.Add(this.pictureBox1);
            this.tc_Benutzer.Controls.Add(this.lb_Benutzer);
            this.tc_Benutzer.Controls.Add(this.btn_Hinzufügen);
            this.tc_Benutzer.Controls.Add(this.btn_Bearbeiten);
            this.tc_Benutzer.Controls.Add(this.btn_Entfernen);
            this.tc_Benutzer.Location = new System.Drawing.Point(4, 22);
            this.tc_Benutzer.Name = "tc_Benutzer";
            this.tc_Benutzer.Padding = new System.Windows.Forms.Padding(3);
            this.tc_Benutzer.Size = new System.Drawing.Size(368, 344);
            this.tc_Benutzer.TabIndex = 0;
            this.tc_Benutzer.Text = "Benutzer";
            this.tc_Benutzer.UseVisualStyleBackColor = true;
            // 
            // tv_Benutzer
            // 
            this.tv_Benutzer.Location = new System.Drawing.Point(10, 81);
            this.tv_Benutzer.Name = "tv_Benutzer";
            treeNode1.Name = "ChefNode";
            treeNode1.Text = "Chef";
            treeNode2.Name = "HilfskraftNode";
            treeNode2.Text = "Hilfskraft";
            treeNode3.Name = "PersonalNode";
            treeNode3.Text = "Personal";
            this.tv_Benutzer.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2,
            treeNode3});
            this.tv_Benutzer.Size = new System.Drawing.Size(350, 228);
            this.tv_Benutzer.TabIndex = 5;
            this.tv_Benutzer.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.tv_Benutzer_AfterSelect);
            // 
            // lb_BenutzerRechte
            // 
            this.lb_BenutzerRechte.AutoSize = true;
            this.lb_BenutzerRechte.Location = new System.Drawing.Point(66, 23);
            this.lb_BenutzerRechte.Name = "lb_BenutzerRechte";
            this.lb_BenutzerRechte.Size = new System.Drawing.Size(290, 39);
            this.lb_BenutzerRechte.TabIndex = 8;
            this.lb_BenutzerRechte.Text = "Verwenden Sie die untenstehende Liste, um neue Benutzer \r\nanzulegen.Benutzern Rec" +
    "hte zuzuweisen bzw. entfernen\r\nund um weitere Eigenschften der Benutzer zu bearb" +
    "eiten.";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Tante_Emma.v2.Properties.Resources.images;
            this.pictureBox1.Location = new System.Drawing.Point(10, 19);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(50, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // lb_Benutzer
            // 
            this.lb_Benutzer.AutoSize = true;
            this.lb_Benutzer.Location = new System.Drawing.Point(7, 65);
            this.lb_Benutzer.Name = "lb_Benutzer";
            this.lb_Benutzer.Size = new System.Drawing.Size(52, 13);
            this.lb_Benutzer.TabIndex = 6;
            this.lb_Benutzer.Text = "Benutzer:";
            // 
            // Benutzerverwaltung
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(398, 419);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.btn_Schließen);
            this.Name = "Benutzerverwaltung";
            this.Text = "Benutzerverwaltung";
            this.Load += new System.EventHandler(this.Benutzerverwaltung_Load);
            this.tabControl1.ResumeLayout(false);
            this.tc_Benutzer.ResumeLayout(false);
            this.tc_Benutzer.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Hinzufügen;
        private System.Windows.Forms.Button btn_Entfernen;
        private System.Windows.Forms.Button btn_Bearbeiten;
        private System.Windows.Forms.Button btn_Schließen;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tc_Benutzer;
        private System.Windows.Forms.Label lb_Benutzer;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lb_BenutzerRechte;
        private System.Windows.Forms.TreeView tv_Benutzer;
    }
}