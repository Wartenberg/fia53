﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Tante_Emma.v2.Rechteverwaltung
{
    public partial class HinzufügenundBearbeiten : Form
    {
        private bool EditMode = false;
        private Login.Benutzer _Benutzer = null;

        public static void EditBenutzer(Login.Benutzer benutzer)
        {
            var Edit = new HinzufügenundBearbeiten();
            
            Edit.EditMode = true;
            Edit._Benutzer = benutzer;

            Edit.tb_Benutzername.Text = benutzer.Benutzername;
            Edit.tb_Hausnr.Text = benutzer.Hausnummer;
            Edit.tb_Name.Text = benutzer.Name;
            Edit.tb_Ort.Text = benutzer.Ort;
            Edit.tb_Passwort.Text = benutzer.Passwort;
            Edit.tb_Plz.Text = benutzer.Plz.ToString();
            Edit.tb_Straße.Text = benutzer.Straße;
            Edit.tb_Vorname.Text = benutzer.Vorname;
            Edit.dtp_Geburtsdatum.Value = benutzer.Geburtsdatum;

            Edit.ShowDialog();
        }

        public HinzufügenundBearbeiten()
        {
            InitializeComponent();
        }

        private void HinzufügenundBearbeiten_Load(object sender, EventArgs e)
        {
            cb_Status.DataSource = Program.BenutzerListe;
            cb_Status.DisplayMember = "Status";
            cb_Status.ValueMember = "RechteID";
        }

        private void btn_Abbrechen_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tb_Passwort_TextChanged(object sender, EventArgs e)
        {
            if (tb_Passwort.Text == tb_PasswortWdh.Text)
            {
                lb_Check.ForeColor = System.Drawing.Color.Green;
                lb_Check.Text = "Passwort stimmt über ein";
            }
            else 
            {
                lb_Check.ForeColor = System.Drawing.Color.Red;
                lb_Check.Text = "Passwort stimmt nicht über ein";
            }
        }

        private void tb_PasswortWdh_TextChanged(object sender, EventArgs e)
        {
            if (tb_Passwort.Text == tb_PasswortWdh.Text)
            {
                lb_Check.ForeColor = System.Drawing.Color.Green;
                lb_Check.Text = "Passwort stimmt über ein";
            }
            else
            {
                lb_Check.ForeColor = System.Drawing.Color.Red;
                lb_Check.Text = "Passwort stimmt nicht über ein";
            }
        }

        private void tb_Passwort_KeyUp_1(object sender, KeyEventArgs e)
        {
            if (tb_Passwort.TextLength <= 4)
            {
                lb_Check.ForeColor = System.Drawing.Color.Red;
                lb_Check.Text = "Passwort muss mindestens\n5 Zeichen beinhalten";
            }
            else if (tb_Passwort.TextLength >= 4)
            {
                tb_PasswortWdh.Enabled = true;
            };
        }

        private void btn_Ok_Click(object sender, EventArgs e)
        {
            if (!EditMode)
            {
                if (tb_Passwort.Text == tb_PasswortWdh.Text && tb_Benutzername.Text != "")
                {
                    var NewBenutzer = new Login.Benutzer();
                    NewBenutzer.Name = tb_Name.Text;
                    NewBenutzer.Ort = tb_Ort.Text;
                    NewBenutzer.Passwort = tb_Passwort.Text;
                    NewBenutzer.Plz = Convert.ToInt32(tb_Plz.Text);
                    NewBenutzer.Straße = tb_Straße.Text;
                    NewBenutzer.Vorname = tb_Vorname.Text;
                    NewBenutzer.Hausnummer = tb_Hausnr.Text;
                    NewBenutzer.Geburtsdatum = (DateTime)dtp_Geburtsdatum.Value;
                    NewBenutzer.Benutzername = tb_Benutzername.Text;
                    NewBenutzer.RechteID = (int)cb_Status.SelectedValue;

                    NewBenutzer.InsertDB();
                }
                else if (tb_Passwort.Text != tb_PasswortWdh.Text)
                {
                    MessageBox.Show("Ihr Passwort stimmt nicht über ein");
                }
            }
            else
            {
                _Benutzer.Name = tb_Name.Text;
                _Benutzer.Ort = tb_Ort.Text;
                _Benutzer.Passwort = tb_Passwort.Text;
                _Benutzer.Plz = Convert.ToInt32(tb_Plz.Text);
                _Benutzer.Straße = tb_Straße.Text;
                _Benutzer.Vorname = tb_Vorname.Text;
                _Benutzer.Hausnummer = tb_Hausnr.Text;
                _Benutzer.Geburtsdatum = (DateTime)dtp_Geburtsdatum.Value;
                _Benutzer.Benutzername = tb_Benutzername.Text;

                _Benutzer.UpdateDB();
            }
        }
    }
}
