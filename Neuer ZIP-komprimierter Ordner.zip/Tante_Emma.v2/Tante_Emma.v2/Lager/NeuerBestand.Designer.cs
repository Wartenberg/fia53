﻿namespace Tante_Emma.v2.Lager
{
    partial class NeuerBestand
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_OK = new System.Windows.Forms.Button();
            this.btn_Abbrechen = new System.Windows.Forms.Button();
            this.tb_AlterBestand = new System.Windows.Forms.TextBox();
            this.tb_NeuerBestand = new System.Windows.Forms.TextBox();
            this.lb_AlterBestand = new System.Windows.Forms.Label();
            this.lb_NeuerBestand = new System.Windows.Forms.Label();
            this.gb_NeuerBestand = new System.Windows.Forms.GroupBox();
            this.gb_NeuerBestand.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_OK
            // 
            this.btn_OK.Location = new System.Drawing.Point(21, 114);
            this.btn_OK.Name = "btn_OK";
            this.btn_OK.Size = new System.Drawing.Size(75, 23);
            this.btn_OK.TabIndex = 0;
            this.btn_OK.Text = "Ok";
            this.btn_OK.UseVisualStyleBackColor = true;
            this.btn_OK.Click += new System.EventHandler(this.btn_OK_Click);
            // 
            // btn_Abbrechen
            // 
            this.btn_Abbrechen.Location = new System.Drawing.Point(122, 114);
            this.btn_Abbrechen.Name = "btn_Abbrechen";
            this.btn_Abbrechen.Size = new System.Drawing.Size(75, 23);
            this.btn_Abbrechen.TabIndex = 1;
            this.btn_Abbrechen.Text = "Abbrechen";
            this.btn_Abbrechen.UseVisualStyleBackColor = true;
            this.btn_Abbrechen.Click += new System.EventHandler(this.btn_Abbrechen_Click);
            // 
            // tb_AlterBestand
            // 
            this.tb_AlterBestand.Enabled = false;
            this.tb_AlterBestand.Location = new System.Drawing.Point(85, 23);
            this.tb_AlterBestand.Name = "tb_AlterBestand";
            this.tb_AlterBestand.Size = new System.Drawing.Size(100, 20);
            this.tb_AlterBestand.TabIndex = 2;
            // 
            // tb_NeuerBestand
            // 
            this.tb_NeuerBestand.Location = new System.Drawing.Point(85, 56);
            this.tb_NeuerBestand.Name = "tb_NeuerBestand";
            this.tb_NeuerBestand.Size = new System.Drawing.Size(100, 20);
            this.tb_NeuerBestand.TabIndex = 3;
            // 
            // lb_AlterBestand
            // 
            this.lb_AlterBestand.AutoSize = true;
            this.lb_AlterBestand.Location = new System.Drawing.Point(6, 26);
            this.lb_AlterBestand.Name = "lb_AlterBestand";
            this.lb_AlterBestand.Size = new System.Drawing.Size(73, 13);
            this.lb_AlterBestand.TabIndex = 4;
            this.lb_AlterBestand.Text = "Alter Bestand:";
            // 
            // lb_NeuerBestand
            // 
            this.lb_NeuerBestand.AutoSize = true;
            this.lb_NeuerBestand.Location = new System.Drawing.Point(6, 59);
            this.lb_NeuerBestand.Name = "lb_NeuerBestand";
            this.lb_NeuerBestand.Size = new System.Drawing.Size(81, 13);
            this.lb_NeuerBestand.TabIndex = 5;
            this.lb_NeuerBestand.Text = "Neuer Bestand:";
            // 
            // gb_NeuerBestand
            // 
            this.gb_NeuerBestand.Controls.Add(this.lb_AlterBestand);
            this.gb_NeuerBestand.Controls.Add(this.tb_NeuerBestand);
            this.gb_NeuerBestand.Controls.Add(this.lb_NeuerBestand);
            this.gb_NeuerBestand.Controls.Add(this.tb_AlterBestand);
            this.gb_NeuerBestand.Location = new System.Drawing.Point(12, 12);
            this.gb_NeuerBestand.Name = "gb_NeuerBestand";
            this.gb_NeuerBestand.Size = new System.Drawing.Size(207, 96);
            this.gb_NeuerBestand.TabIndex = 6;
            this.gb_NeuerBestand.TabStop = false;
            this.gb_NeuerBestand.Text = "Neuer Bestand";
            // 
            // NeuerBestand
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(237, 159);
            this.Controls.Add(this.gb_NeuerBestand);
            this.Controls.Add(this.btn_Abbrechen);
            this.Controls.Add(this.btn_OK);
            this.Name = "NeuerBestand";
            this.Text = "NeuerBestand";
            this.Load += new System.EventHandler(this.NeuerBestand_Load);
            this.gb_NeuerBestand.ResumeLayout(false);
            this.gb_NeuerBestand.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_OK;
        private System.Windows.Forms.Button btn_Abbrechen;
        private System.Windows.Forms.TextBox tb_AlterBestand;
        private System.Windows.Forms.TextBox tb_NeuerBestand;
        private System.Windows.Forms.Label lb_AlterBestand;
        private System.Windows.Forms.Label lb_NeuerBestand;
        private System.Windows.Forms.GroupBox gb_NeuerBestand;
    }
}