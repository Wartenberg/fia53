﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Tante_Emma.v2.Lager
{
    public partial class Lieferung : Form
    {

        private NeuerBestand _neuerBestand;
        private static List<Kasse.Artikel> listArtikel = new List<Kasse.Artikel>();
        public Lieferung()
        {
            InitializeComponent();
        }

        #region Lieferung Load
        private void Lieferung_Load(object sender, EventArgs e)
        {
            //Datagrid Lierfung mit Produkten füllen
            this.dgv_Lieferung.RowHeadersVisible = false;
            var artikel = new Kasse.Artikel();
            listArtikel = artikel.getArtikel();
            dgv_Lieferung.DataSource = listArtikel;


            //Combobox Artikeltyp füllen
           var getArtikeltyp = (from a in listArtikel
                                select a.Artikeltyp).ToList();
            cb_Artikeltyp.Items.AddRange(getArtikeltyp.Distinct().ToArray());

            #endregion


        #region Textbox Suche
        }
        private void tb_ProduktNr_TextChanged(object sender, EventArgs e)
        {
            {
                ////var filterArtikel = (from a in listArtikel
                ////                     where a.ID.Contains(tb_ProduktNr.Text)
                ////                     select a).ToList();
                ////dgv_Lieferung.DataSource = filterArtikel;
            }
        }

        private void tb_ProduktName_TextChanged(object sender, EventArgs e)
        {
            {
                var filterArtikelname = (from a in listArtikel
                                     where a.Name.ToUpper().Contains(tb_ProduktName.Text.ToUpper())
                                     select a).ToList();
                dgv_Lieferung.DataSource = filterArtikelname;
            }
        }

        private void cb_Artikeltyp_TextChanged(object sender, EventArgs e)
        {
            var filterArtikeltyp = (from a in listArtikel
                                 where a.Artikeltyp.ToUpper().Contains(cb_Artikeltyp.Text.ToUpper())
                                 select a).ToList();
            dgv_Lieferung.DataSource = filterArtikeltyp;
        }

        #endregion


        #region CheckChanged CheckBox
        private void cb_NeuErstellen_CheckedChanged(object sender, EventArgs e)
        {
            if (cb_NeuErstellen.Checked == true)
            {
                if (MessageBox.Show("Wollen Sie ein neues Produkt erstellen?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    btn_Erstellen.Visible = true;
                    lb_Preis.Visible = true;
                    lb_Regalnummer.Visible = true;
                    lb_Menge.Visible = true;
                    lb_Platznummer.Visible = true;
                    tb_Platznummer.Visible = true;
                    tb_Regalnummer.Visible = true;
                    tb_Preis.Visible = true;
                    tb_Menge.Visible = true;
                    btn_NeuerBestand.Visible = false;
                }
                else
                {
                    cb_NeuErstellen.Checked = false;
                }
            }
            else if (cb_NeuErstellen.Checked == false)
            {
                btn_Erstellen.Visible = false;
                lb_Preis.Visible = false;
                lb_Regalnummer.Visible = false;
                lb_Menge.Visible = false;
                lb_Platznummer.Visible = false;
                tb_Platznummer.Visible = false;
                tb_Regalnummer.Visible = false;
                tb_Preis.Visible = false;
                tb_Menge.Visible = false;
                btn_NeuerBestand.Visible = true;
            }
        }
        #endregion

        private void btn_NeuerBestand_Click(object sender, EventArgs e)
        {
            int selecteditem = dgv_Lieferung.SelectedRows.Count;
            if (selecteditem > 0)
            {
                _neuerBestand.ShowDialog();
            }
        }

        private void dgv_Lieferung_SelectionChanged(object sender, EventArgs e)
        {
            if (dgv_Lieferung.SelectedRows.Count > 0)
            {
                DataGridViewRow row = this.dgv_Lieferung.SelectedRows[0];

                string ID = row.Cells["ID"].Value.ToString();
                string Platznummer = row.Cells["Platznr"].Value.ToString();
                string Regalnummer = row.Cells["Regalnr"].Value.ToString();
                string Menge = row.Cells["Menge"].Value.ToString();



               _neuerBestand = new NeuerBestand(ID, Platznummer, Regalnummer, Menge);

            }
        }

        private void btn_Erstellen_Click(object sender, EventArgs e)
        {

        }
    }
}

