﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Tante_Emma.v2.Lager
{
    public partial class Lager : Form
    {
        private List<Kasse.Artikel> listArtikel = new List<Kasse.Artikel>();
        private MySQL_Anbindung.MySQLConnect con;
        public Lager()
        {
            InitializeComponent();
        }

        private void Lager_Load(object sender, EventArgs e)
        {
            con = new MySQL_Anbindung.MySQLConnect();

            con.MysqlQuery("SELECT * FROM ARTIKEL A INNER JOIN BESTAND B ON (A.ID = B.FIARTIKEL) ORDER BY A.NAME ASC;");

            foreach (DataRow row in con.QueryEx().Rows)
            {
                listArtikel.Add(new Kasse.Artikel()
                {
                    ID = (int)row["ID"],
                    Name = (string)row["Name"],
                    Artikeltyp = (string)row["Artikeltyp"],
                    Preis = (double)row["Preis"],
                    Menge = (int)row["Menge"],
                    Regalnr = (int)row["RegalNummer"],
                    Platznr = (int)row["Platznummer"]

                });

               
            }
            dgv_Lager.DataSource = listArtikel;
        }

        private void btn_Lieferung_Click(object sender, EventArgs e)
        {

        }

        private void btn_Lieferung_Click_1(object sender, EventArgs e)
        {
            Lieferung lf = new Lieferung();
            lf.ShowDialog();
        }
    }
}
