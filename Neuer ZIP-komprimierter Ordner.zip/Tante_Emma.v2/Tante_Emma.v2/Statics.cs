﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tante_Emma.v2
{
    static class Statics
    {

        public static Login.Benutzer ActiveUser { get; set; }

    }
}
