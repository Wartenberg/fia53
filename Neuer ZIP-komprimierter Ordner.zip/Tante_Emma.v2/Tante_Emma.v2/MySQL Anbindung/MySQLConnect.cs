﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MySql.Data.MySqlClient;
using System.Data;

namespace Tante_Emma.v2.MySQL_Anbindung
{
    public class MySQLConnect
    {
        private MySqlConnection _con;
        private MySqlCommand Cmd;
        private MySqlDataAdapter _sda;
        private DataTable _dt;



        public MySQLConnect()
        {
            _con = new MySqlConnection("SERVER=localhost;" +
                                        "DATABASE=emma;" +
                                        "UID=root;" +
                                        "PASSWORD=;");
            _con.Open();
        }

        public void MysqlQuery(string querytext)
        {
            Cmd = new MySqlCommand(querytext, _con);

        }

        public DataTable QueryEx()
        {
            _sda = new MySqlDataAdapter(Cmd);
            _dt = new DataTable();
            _sda.Fill(_dt);
             
            return _dt;
        }
        public void NonQueryEx()
        {
            Cmd.ExecuteNonQuery();

        }

    }
}

