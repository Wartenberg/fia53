﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace Tante_Emma.v2.Login
{
    class Benutzer
    {
        private Guid _id;
        private string _benutzername;
        private string _passwort;
        private int _rechteID;
        private string _vorname;
        private string _name;
        private DateTime _geburtsdatum;
        private string _straße;
        private string _hausnr;
        private int _plz;
        private string _ort;
        private Rechteverwaltung.Rechte _Rechte = null;

        public Benutzer()
        {
            _id = Guid.NewGuid();
            _benutzername = String.Empty;
            _passwort = String.Empty;
            _rechteID = 0;
            _vorname = String.Empty;
            _name = String.Empty;
            _geburtsdatum = DateTime.Now;
            _straße = String.Empty;
            _hausnr = String.Empty;
            _plz = 0;
            _ort = String.Empty;
        }

        public Guid ID { get { return _id; }  set { _id = value; } }

        public string Benutzername { get { return _benutzername; } set { _benutzername = value; } }

        public string Passwort { get { return _passwort; } set { _passwort = value; } }

        public int RechteID { get { return _rechteID; } set { _rechteID = value; } }

        public string Vorname { get { return _vorname; } set { _vorname = value; } }

        public string Name { get { return _name; } set { _name = value; } }
        public DateTime Geburtsdatum { get { return _geburtsdatum; } set { _geburtsdatum = value; } }

        public string Straße { get { return _straße; } set { _straße = value; } }

        public string Hausnummer { get { return _hausnr; } set { _hausnr = value; } }
        public int Plz { get { return _plz; } set { _plz = value; } }

        public string Ort { get { return _ort; } set { _ort = value; } }

        public Rechteverwaltung.Rechte Rechte { get { return _Rechte; } }

        public static void GetAllBenutzer()
        {
            try
            {
                var con = new MySQL_Anbindung.MySQLConnect();
                con.MysqlQuery("SELECT * FROM Mitarbeiter ORDER BY Benutzername ASC;");

                foreach (DataRow row in con.QueryEx().Rows)
                {
                    var Benutzer = new Benutzer();
                    Benutzer.ID = (Guid)row["ID"];
                    Benutzer.LoadData();

                    Program.BenutzerListe.Add(Benutzer);
                }
            }
            catch (Exception ex)
            {

            }
        }

        public void UpdateDB()
        {
            try
            {
                var con = new MySQL_Anbindung.MySQLConnect();
                string UpdateQuery = String.Format(@"
                    update Mitarbeiter set
                    fiRechte = {0},
                    Benutzername = '{1}', 
                    Passwort = '{2}', 
                    Vorname = '{3}',
                    Name = '{4}',
                    Geburtsdatum = '{5}',
                    Str = '{6}',
                    Hnr = '{7}',
                    Plz = '{8}',
                    Ort = '{9}'
                    where ID = '{10}'",
                    RechteID, Benutzername, Passwort, Vorname, Name, Geburtsdatum.Year + "-" + Geburtsdatum.Month + "-" + Geburtsdatum.Day, Straße, Hausnummer, Plz,Ort, ID);

                con.MysqlQuery(UpdateQuery);
                con.QueryEx();
            }
            catch (Exception ex)
            {

            }
        }

        public void LoadData()
        {
            try
            {
                var con = new MySQL_Anbindung.MySQLConnect();
                string UpdateQuery = String.Format(@"
                    select * from Mitarbeiter where ID='{0}'",this.ID);
                con.MysqlQuery(UpdateQuery);

                foreach (DataRow row in con.QueryEx().Rows)
                {
                    this.Hausnummer = (string)row["Hnr"];
                    this.Straße = (string)row["Str"];
                    this.Ort = (string)row["Ort"];
                    this.Plz = Convert.ToInt32(row["Plz"]);
                    this.Geburtsdatum = Convert.ToDateTime(row["Geburtsdatum"]);
                    this.Name = (string)row["Name"];
                    this.Vorname = (string)row["Vorname"];
                    this.Benutzername = (string)row["Benutzername"];
                    this.RechteID = (int)row["fiRechte"];
                    this.Passwort = (string)row["Passwort"];

                    this._Rechte = new Rechteverwaltung.Rechte(this._rechteID);
                    this._Rechte.LoadData();
                }
            }
            catch (Exception ex)
            {

            }
        }

        public void InsertDB()
        {
            try
            {
                var con = new MySQL_Anbindung.MySQLConnect();
                string UpdateQuery = String.Format(@"
                    Insert into Mitarbeiter(ID, fiRechte,Benutzername, Passwort, Vorname,Name,Geburtsdatum,Str,Hnr,Plz,Ort)
                    Values ({0}, {1}, {2}, {3}, {4}, {5}, {6}, {7}, {8}, {9}, {10})",
                    ID, RechteID, Benutzername, Passwort, Vorname, Name, Geburtsdatum.Year + "-" + Geburtsdatum.Month + "-" + Geburtsdatum.Day, Straße, Hausnummer, Plz, Ort);

                con.MysqlQuery(UpdateQuery);
                con.QueryEx();
            }
            catch (Exception ex)
            {

            }
        }

        public void DeleteDB()
        {
            try
            {
                var con = new MySQL_Anbindung.MySQLConnect();
                string UpdateQuery = String.Format(@"
                    Delete from Mitarbeiter where Id='{0}'", ID);

                con.MysqlQuery(UpdateQuery);
                con.QueryEx();
            }
            catch (Exception ex)
            {

            }
        }
    }
}
