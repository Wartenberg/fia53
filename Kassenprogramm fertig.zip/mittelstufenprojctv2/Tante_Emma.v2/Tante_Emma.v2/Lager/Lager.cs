﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Tante_Emma.v2.Lager
{
	public partial class Lager : Form
	{
		private List<Artikel> _listArtikel;

		public Lager()
		{
			InitializeComponent();
		}

		private void Lager_Load(object sender, EventArgs e)
		{
			_listArtikel = Artikel.GetAllArtikel();
			ArtikelBindingSource.DataSource = _listArtikel;
		}

		private void dgv_Lager_CellEndEdit(object sender, DataGridViewCellEventArgs e)
		{
			if (ArtikelBindingSource.Current != null && ArtikelBindingSource.Current is Artikel)
			{
				(ArtikelBindingSource.Current as Artikel).UpdateDB();
			}
		}

		private void btn_AddArtikel_Click(object sender, EventArgs e)
		{
			var NewArtikel = new Artikel();
			NewArtikel.InsertDB();

			_listArtikel.Add(NewArtikel);

			ArtikelBindingSource.ResetBindings(false);
		}

		private void btn_DeleteArtikel_Click(object sender, EventArgs e)
		{
			if (ArtikelBindingSource.Current != null && ArtikelBindingSource.Current is Artikel)
			{
				(ArtikelBindingSource.Current as Artikel).DeleteDB();
				_listArtikel.Remove(ArtikelBindingSource.Current as Artikel);

				ArtikelBindingSource.ResetBindings(false);
			}
		}

		private void tsmi_LagerzugangBuchen_Click(object sender, EventArgs e)
		{
			if (ArtikelBindingSource.Current != null && ArtikelBindingSource.Current is Artikel)
			{
				var bestand = new Bestand();
				bestand.ArtikelID = (ArtikelBindingSource.Current as Artikel).ID;
				var DlgNewBestand = new NeuerBestand(bestand);

				if (DlgNewBestand.ShowDialog() == DialogResult.OK)
				{
					bestand.InsertDB();
					(ArtikelBindingSource.Current as Artikel).LoadData();

					ArtikelBindingSource.ResetBindings(false);
				}
			}
		}

		private void dgv_Lager_MouseClick(object sender, MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Right)
			{
				if (ArtikelBindingSource.Current != null && ArtikelBindingSource.Current is Artikel)
				{
					contextMenuStrip1.Show(Cursor.Position.X, Cursor.Position.Y);
				}
			}
		}
	}
}
