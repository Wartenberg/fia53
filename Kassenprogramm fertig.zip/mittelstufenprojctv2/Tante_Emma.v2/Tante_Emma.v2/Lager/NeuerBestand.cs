﻿using System;
using System.Windows.Forms;

namespace Tante_Emma.v2.Lager
{
	public partial class NeuerBestand : Form
	{
		private Bestand CurrentBestand;

		public NeuerBestand()
		{
			InitializeComponent();
		}

		public NeuerBestand(Bestand OldBestand)
			: this()
		{
			CurrentBestand = OldBestand;
			BestandBindingSource.DataSource = CurrentBestand;
		}

		private void btn_Abbrechen_Click(object sender, EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
		}

		private void btn_OK_Click(object sender, EventArgs e)
		{
			if (nud_Menge.Value > 0 && nud_Platz.Value > 0 && nud_Regal.Value > 0)
			{
				if (Bestand.IsRegalplatzFrei((int)nud_Regal.Value, (int)nud_Platz.Value))
					this.DialogResult = DialogResult.OK;
				else
					MessageBox.Show("Dieser Platz ist schon belegt! Bitte wählen Sie einen anderen Platz aus.",
										"Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
			else
				MessageBox.Show("Es sind nicht alle Werte korrekt ausgefüllt.\nJeder Wert muss größer als 0 null. Bitte stellen Sie sicher, dass dies der Fall ist.",
										"Warnung", MessageBoxButtons.OK, MessageBoxIcon.Warning);
		}
	}
}
