﻿using System;
using System.Collections.Generic;
using System.Data;

namespace Tante_Emma.v2.Bestellen
{
	public class Bestellung : Interfaces.IDBMethoden
	{
		#region Public Member
		public const string STATUS_OFFEN = "Offen";
		public const string STATUS_ABGESCHLOSSEN = "Abgeschlossen";
		#endregion

		#region Private Member
		private Guid _id;
		private Guid _mitarbeiterid;
		private Guid _kundeid;
		private DateTime _betselltam;
		private byte _bestellungszyklus;
		private DateTime _leiferungam;
		private string _status;
		#endregion

		#region C'tor
		public Bestellung()
		{
			_id = Guid.NewGuid();
			_mitarbeiterid = Guid.Empty;
			_kundeid = Guid.Empty;
			_betselltam = DateTime.Now;
			_bestellungszyklus = 0;
			_leiferungam = DateTime.Now;
			_status = Bestellung.STATUS_OFFEN;
		}

		public Bestellung(Guid Mitarbeiter, Guid Kunde)
			: this()
		{
			_mitarbeiterid = Mitarbeiter;
			_kundeid = Kunde;
		}
		#endregion

		#region Properties
		public Guid ID
		{
			get
			{
				return _id;
			}
			set
			{
				if (value != null && value != Guid.Empty)
					_id = value;
			}
		}

		public Guid MitarbeiterId
		{
			get
			{
				return _mitarbeiterid;
			}
			set
			{
				if (value != null && value != Guid.Empty)
					_mitarbeiterid = value;
			}
		}

		public string Status
		{
			get
			{
				return _status;
			}
			set
			{
				if (!String.IsNullOrEmpty(value))
					_status = value;
			}
		}

		public DateTime LieferungAm
		{
			get
			{
				return _leiferungam;
			}
			set
			{
				if (value >= DateTime.Now)
					_leiferungam = value;
			}
		}

		public string LieferungCaption
		{
			get
			{
				return LieferungAm.ToShortDateString();
			}
		}

		public byte BestellungsZyklus
		{
			get
			{
				return _bestellungszyklus;
			}
			set
			{
				if (value != _bestellungszyklus)
					_bestellungszyklus = value;
			}
		}
		
		public DateTime BestelltAm
		{
			get
			{
				return _betselltam;
			}
			set
			{
				if (value <= DateTime.Now)
					_betselltam = value;
			}
		}

		public Guid KundeId
		{
			get
			{
				return _kundeid;
			}
			set
			{
				if (value != null && value != Guid.Empty)
					_kundeid = value;
			}
		}

		public string ListName
		{
			get
			{
				return "Bestellung vom " + BestelltAm.ToShortDateString();
			}
		}
		#endregion

		#region DB-Methoden
		public void LoadData()
		{
			try
			{
				var con = new MySQL_Anbindung.MySQLConnect();
				string UpdateQuery = String.Format(@"
                    select * from Bestellung where ID='{0}'", this.ID);

				foreach (DataRow row in con.QueryEx(UpdateQuery).Rows)
				{
					this.MitarbeiterId = (Guid)row["fiMitarbeiter"];
					this.BestelltAm = (DateTime)row["BestelltAm"];
					this.KundeId = (Guid)row["fiKunde"];
					this.BestellungsZyklus = Convert.ToByte(row["wiederkehrend"]);
					this.LieferungAm = (DateTime)row["LieferungAm"];
					this.BestelltAm = (DateTime)row["BestelltAm"];
					this.Status = (string)row["Status"];
				}
			}
			catch (Exception ex)
			{

			}
		}

		public void UpdateDB()
		{
			try
			{
				var con = new MySQL_Anbindung.MySQLConnect();
				string UpdateQuery = String.Format(@"
                    update Bestellung set
                    fiMitarbeiter = '{1}',
						  fiKunde = '{2}',
						  BestelltAm = '{3}',
						  wiederkehrend = {4},
						  LieferungAm = '{5}',
						  Status = '{6}'
						  where ID = '{0}'",
					 ID, MitarbeiterId, KundeId, BestelltAm.Year + "-" + BestelltAm.Month + "-" + BestelltAm.Day,
					 BestellungsZyklus, LieferungAm.Year + "-" + LieferungAm.Month + "-" + LieferungAm.Day, Status);

				con.QueryEx(UpdateQuery);
			}
			catch (Exception ex)
			{

			}
		}

		public void InsertDB()
		{
			try
			{
				var con = new MySQL_Anbindung.MySQLConnect();
				string UpdateQuery = String.Format(@"
                    Insert into Bestellung(ID, fiMitarbeiter, fiKunde, BestelltAm, wiederkehrend, LieferungAm, Status)
                    Values ('{0}', '{1}', '{2}', '{3}', {4}, '{5}', '{6}')", ID, MitarbeiterId, KundeId,
																			BestelltAm.Year + "-" + BestelltAm.Month + "-" + BestelltAm.Day, BestellungsZyklus,
																			LieferungAm.Year + "-" + LieferungAm.Month + "-" + LieferungAm.Day, Status);

				con.QueryEx(UpdateQuery);
			}
			catch (Exception ex)
			{

			}
		}

		public void DeleteDB()
		{
			try
			{
				var con = new MySQL_Anbindung.MySQLConnect();
				string UpdateQuery = String.Format(@"
                    Delete from Bestellung where Id='{0}'", ID);

				con.QueryEx(UpdateQuery);

				foreach (WarenkorbEintrag wke in WarenkorbEintrag.GetByVorgangId(ID))
					wke.DeleteDB();
			}
			catch (Exception ex)
			{

			}
		}

		public static List<Bestellung> GetBestellungenByKundeId(Guid Kunde)
		{
			try
			{
				var listBestellung = new List<Bestellung>();

				var con = new MySQL_Anbindung.MySQLConnect();
				var Query = String.Format("SELECT ID FROM Bestellung where fiKunde='{0}';", Kunde);

				foreach (DataRow row in con.QueryEx(Query).Rows)
				{
					var Bestellung = new Bestellung() { ID = (Guid)row["ID"] };
					Bestellung.LoadData();
					listBestellung.Add(Bestellung);
				}

				return listBestellung;
			}
			catch (Exception ex)
			{

			}

			return null;
		}
		#endregion
	}
}
