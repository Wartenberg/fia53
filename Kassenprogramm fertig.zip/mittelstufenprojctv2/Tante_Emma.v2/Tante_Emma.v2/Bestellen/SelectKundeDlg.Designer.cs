﻿namespace Tante_Emma.v2.Bestellen
{
	partial class SelectKundeDlg
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.KundeBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.listBox1 = new System.Windows.Forms.ListBox();
			this.label1 = new System.Windows.Forms.Label();
			this.btn_OK = new System.Windows.Forms.Button();
			this.btn_Cancel = new System.Windows.Forms.Button();
			this.dtp_Lieferdate = new System.Windows.Forms.DateTimePicker();
			this.lbl_Lieferdate = new System.Windows.Forms.Label();
			this.rb_Tag = new System.Windows.Forms.RadioButton();
			this.rb_Woche = new System.Windows.Forms.RadioButton();
			this.rb_Monat = new System.Windows.Forms.RadioButton();
			this.lbl_Lieferzyklus = new System.Windows.Forms.Label();
			this.rb_Einmal = new System.Windows.Forms.RadioButton();
			((System.ComponentModel.ISupportInitialize)(this.KundeBindingSource)).BeginInit();
			this.SuspendLayout();
			// 
			// KundeBindingSource
			// 
			this.KundeBindingSource.DataSource = typeof(Tante_Emma.v2.Kundenverwaltung.Kunde);
			// 
			// listBox1
			// 
			this.listBox1.DataSource = this.KundeBindingSource;
			this.listBox1.DisplayMember = "GanzerName";
			this.listBox1.FormattingEnabled = true;
			this.listBox1.Location = new System.Drawing.Point(12, 29);
			this.listBox1.Name = "listBox1";
			this.listBox1.Size = new System.Drawing.Size(191, 225);
			this.listBox1.TabIndex = 0;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(12, 9);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(321, 13);
			this.label1.TabIndex = 1;
			this.label1.Text = "Bitte wählen Sie den Kunden aus der diese Bestellung getätigt hat.";
			// 
			// btn_OK
			// 
			this.btn_OK.Location = new System.Drawing.Point(12, 256);
			this.btn_OK.Name = "btn_OK";
			this.btn_OK.Size = new System.Drawing.Size(97, 23);
			this.btn_OK.TabIndex = 2;
			this.btn_OK.Text = "Bestätigen";
			this.btn_OK.UseVisualStyleBackColor = true;
			this.btn_OK.Click += new System.EventHandler(this.btn_OK_Click);
			// 
			// btn_Cancel
			// 
			this.btn_Cancel.Location = new System.Drawing.Point(266, 256);
			this.btn_Cancel.Name = "btn_Cancel";
			this.btn_Cancel.Size = new System.Drawing.Size(97, 23);
			this.btn_Cancel.TabIndex = 3;
			this.btn_Cancel.Text = "Abbrechen";
			this.btn_Cancel.UseVisualStyleBackColor = true;
			this.btn_Cancel.Click += new System.EventHandler(this.btn_Cancel_Click);
			// 
			// dtp_Lieferdate
			// 
			this.dtp_Lieferdate.Location = new System.Drawing.Point(223, 52);
			this.dtp_Lieferdate.Name = "dtp_Lieferdate";
			this.dtp_Lieferdate.Size = new System.Drawing.Size(140, 20);
			this.dtp_Lieferdate.TabIndex = 4;
			// 
			// lbl_Lieferdate
			// 
			this.lbl_Lieferdate.AutoSize = true;
			this.lbl_Lieferdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbl_Lieferdate.Location = new System.Drawing.Point(220, 36);
			this.lbl_Lieferdate.Name = "lbl_Lieferdate";
			this.lbl_Lieferdate.Size = new System.Drawing.Size(65, 13);
			this.lbl_Lieferdate.TabIndex = 5;
			this.lbl_Lieferdate.Text = "Lieferdatum:";
			// 
			// rb_Tag
			// 
			this.rb_Tag.AutoSize = true;
			this.rb_Tag.Location = new System.Drawing.Point(225, 123);
			this.rb_Tag.Name = "rb_Tag";
			this.rb_Tag.Size = new System.Drawing.Size(60, 17);
			this.rb_Tag.TabIndex = 7;
			this.rb_Tag.Tag = "2";
			this.rb_Tag.Text = "Täglich";
			this.rb_Tag.UseVisualStyleBackColor = true;
			// 
			// rb_Woche
			// 
			this.rb_Woche.AutoSize = true;
			this.rb_Woche.Location = new System.Drawing.Point(225, 146);
			this.rb_Woche.Name = "rb_Woche";
			this.rb_Woche.Size = new System.Drawing.Size(85, 17);
			this.rb_Woche.TabIndex = 8;
			this.rb_Woche.Tag = "3";
			this.rb_Woche.Text = "Wöchentlich";
			this.rb_Woche.UseVisualStyleBackColor = true;
			// 
			// rb_Monat
			// 
			this.rb_Monat.AutoSize = true;
			this.rb_Monat.Location = new System.Drawing.Point(225, 169);
			this.rb_Monat.Name = "rb_Monat";
			this.rb_Monat.Size = new System.Drawing.Size(71, 17);
			this.rb_Monat.TabIndex = 9;
			this.rb_Monat.Tag = "4";
			this.rb_Monat.Text = "Monatlich";
			this.rb_Monat.UseVisualStyleBackColor = true;
			// 
			// lbl_Lieferzyklus
			// 
			this.lbl_Lieferzyklus.AutoSize = true;
			this.lbl_Lieferzyklus.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbl_Lieferzyklus.Location = new System.Drawing.Point(222, 103);
			this.lbl_Lieferzyklus.Name = "lbl_Lieferzyklus";
			this.lbl_Lieferzyklus.Size = new System.Drawing.Size(62, 13);
			this.lbl_Lieferzyklus.TabIndex = 10;
			this.lbl_Lieferzyklus.Text = "Lieferzyklus";
			// 
			// rb_Einmal
			// 
			this.rb_Einmal.AutoSize = true;
			this.rb_Einmal.Checked = true;
			this.rb_Einmal.Location = new System.Drawing.Point(225, 192);
			this.rb_Einmal.Name = "rb_Einmal";
			this.rb_Einmal.Size = new System.Drawing.Size(64, 17);
			this.rb_Einmal.TabIndex = 11;
			this.rb_Einmal.TabStop = true;
			this.rb_Einmal.Tag = "1";
			this.rb_Einmal.Text = "Einmalig";
			this.rb_Einmal.UseVisualStyleBackColor = true;
			// 
			// SelectKundeDlg
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(370, 285);
			this.Controls.Add(this.rb_Einmal);
			this.Controls.Add(this.lbl_Lieferzyklus);
			this.Controls.Add(this.rb_Monat);
			this.Controls.Add(this.rb_Woche);
			this.Controls.Add(this.rb_Tag);
			this.Controls.Add(this.lbl_Lieferdate);
			this.Controls.Add(this.dtp_Lieferdate);
			this.Controls.Add(this.btn_Cancel);
			this.Controls.Add(this.btn_OK);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.listBox1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "SelectKundeDlg";
			this.ShowIcon = false;
			this.ShowInTaskbar = false;
			this.Load += new System.EventHandler(this.SelectKundeDlg_Load);
			((System.ComponentModel.ISupportInitialize)(this.KundeBindingSource)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.BindingSource KundeBindingSource;
		private System.Windows.Forms.ListBox listBox1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button btn_OK;
		private System.Windows.Forms.Button btn_Cancel;
		private System.Windows.Forms.DateTimePicker dtp_Lieferdate;
		private System.Windows.Forms.Label lbl_Lieferdate;
		private System.Windows.Forms.RadioButton rb_Tag;
		private System.Windows.Forms.RadioButton rb_Woche;
		private System.Windows.Forms.RadioButton rb_Monat;
		private System.Windows.Forms.Label lbl_Lieferzyklus;
		private System.Windows.Forms.RadioButton rb_Einmal;
	}
}