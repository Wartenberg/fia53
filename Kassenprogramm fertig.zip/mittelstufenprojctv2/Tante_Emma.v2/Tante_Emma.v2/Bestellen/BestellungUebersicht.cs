﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Tante_Emma.v2.Bestellen
{
	public partial class BestellungUebersicht : Form
	{
		private List<Bestellung> listBestellung;
		private List<Kundenverwaltung.Kunde> listKunden;
		private List<WarenkorbEintrag> listWKE;

		public BestellungUebersicht()
		{
			InitializeComponent();

			listBestellung = new List<Bestellung>();
			listKunden = Kundenverwaltung.Kunde.GetAllKunden();
			listWKE = new List<WarenkorbEintrag>();

			ResetList();
		}

		private void KundeBindingSource_CurrentChanged(object sender, EventArgs e)
		{
			listWKE.Clear();
			listBestellung.Clear();

			if (KundeBindingSource.Current != null)
			{
				listBestellung = Bestellung.GetBestellungenByKundeId((KundeBindingSource.Current as Kundenverwaltung.Kunde).ID);

				ResetList();
			}
		}

		private void BestellungBindingSource_CurrentChanged(object sender, EventArgs e)
		{
			if (BestellungBindingSource.Current != null)
			{
				listWKE = WarenkorbEintrag.GetByVorgangId((BestellungBindingSource.Current as Bestellung).ID);

				ResetList();

				if ((BestellungBindingSource.Current as Bestellung).Status == Bestellung.STATUS_OFFEN &&
					 (BestellungBindingSource.Current as Bestellung).LieferungAm.ToShortDateString() == DateTime.Now.ToShortDateString())
				{
					btn_BestellungAbschließen.Enabled = true;
				}
				else
				{
					btn_BestellungAbschließen.Enabled = false;
				}
			}
		}

		private void ResetList()
		{
			WKEBindingSource.Clear();

			KundeBindingSource.DataSource = listKunden;
			BestellungBindingSource.DataSource = listBestellung;

			WKEBindingSource.DataSource = listWKE;
		}

		private void btn_BestellungAbschließen_Click(object sender, EventArgs e)
		{
			// Einmalig
			if ((BestellungBindingSource.Current as Bestellung).BestellungsZyklus == 1)
				(BestellungBindingSource.Current as Bestellung).Status = Bestellung.STATUS_ABGESCHLOSSEN;
			//Täglich
			else if ((BestellungBindingSource.Current as Bestellung).BestellungsZyklus == 2)
				(BestellungBindingSource.Current as Bestellung).LieferungAm = (BestellungBindingSource.Current as Bestellung).LieferungAm.AddDays(1);
			//Wöchentlich
			else if ((BestellungBindingSource.Current as Bestellung).BestellungsZyklus == 3)
				(BestellungBindingSource.Current as Bestellung).LieferungAm = (BestellungBindingSource.Current as Bestellung).LieferungAm.AddDays(7);
			//Monatlich
			else if ((BestellungBindingSource.Current as Bestellung).BestellungsZyklus == 4)
				(BestellungBindingSource.Current as Bestellung).LieferungAm = (BestellungBindingSource.Current as Bestellung).LieferungAm.AddMonths(1);

			(BestellungBindingSource.Current as Bestellung).UpdateDB();
			
			btn_BestellungAbschließen.Enabled = false;

			this.Refresh();
		}

		private void lb_Bestellung_MouseClick(object sender, MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Right && BestellungBindingSource.Current != null)
			{
				var menu = new ContextMenuStrip();
				menu.Items.Add("Bestellung löschen").Click += DeleteBestellung;

				menu.Show(Cursor.Position);
			}
		}

		private void DeleteBestellung (object sender, EventArgs e)
		{
			if ((BestellungBindingSource.Current as Bestellung).Status == Bestellung.STATUS_OFFEN &&
				 (BestellungBindingSource.Current as Bestellung).BestellungsZyklus == 1)
			{
				if (MessageBox.Show("Wollen Sie díe Bestellung wirklich löschen?", "Frage", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
				{
					(BestellungBindingSource.Current as Bestellung).DeleteDB();
					listBestellung.Remove(BestellungBindingSource.Current as Bestellung);
				}
			}
			else if ((BestellungBindingSource.Current as Bestellung).Status == Bestellung.STATUS_ABGESCHLOSSEN)
			{
				MessageBox.Show("Eine Abgeschlossene Bestellung kann nicht gelöscht werden!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
		}
	}
}
