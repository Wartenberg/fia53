﻿using System;
using System.Data;

namespace Tante_Emma.v2.Login
{
	public class Benutzer : Mitarbeiter, Interfaces.IDBMethoden
	{
		#region Private Member
		private Guid _id;
		private string _benutzername;
		private string _passwort;
		private int _rechteID;
		private Rechteverwaltung.Rechte _Rechte = null;
		#endregion

		#region C'tor
		public Benutzer()
			: base()
		{
			_benutzername = String.Empty;
			_passwort = String.Empty;
			_rechteID = 0;
		}
		#endregion

		#region Properties

		public string Benutzername
		{
			get
			{
				return _benutzername;
			}
			set
			{
				if (!String.IsNullOrEmpty(value) && value != _benutzername)
					_benutzername = value;
			}
		}

		public string Passwort
		{
			get
			{
				return _passwort;
			}
			set
			{
				_passwort = value;
			}
		}

		public int RechteID
		{
			get
			{
				return _rechteID;
			}
			set
			{
				if (value >= 1)
					_rechteID = value;
			}
		}

		public Rechteverwaltung.Rechte Rechte
		{
			get
			{
				return 
					_Rechte;
			}
		}
		#endregion

		#region DB-Methoden
		public static void GetAllBenutzer()
		{
			try
			{
				Program.BenutzerListe = new System.Collections.Generic.List<Benutzer>();

				var con = new MySQL_Anbindung.MySQLConnect();
				var Query = "SELECT * FROM Mitarbeiter ORDER BY Benutzername ASC;";

				foreach (DataRow row in con.QueryEx(Query).Rows)
				{
					var Benutzer = new Benutzer();
					Benutzer.ID = (Guid)row["ID"];
					Benutzer.LoadData();

					Program.BenutzerListe.Add(Benutzer);
				}
			}
			catch (Exception ex)
			{

			}
		}

		public void UpdateDB()
		{
			try
			{
				var con = new MySQL_Anbindung.MySQLConnect();
				string UpdateQuery = String.Format(@"
                    update Mitarbeiter set
                    fiRechte = {0},
                    Benutzername = '{1}', 
                    Passwort = '{2}', 
                    Vorname = '{3}',
                    Name = '{4}',
                    Geburtsdatum = '{5}',
                    Str = '{6}',
                    Hnr = '{7}',
                    Plz = '{8}',
                    Ort = '{9}'
                    where ID = '{10}'",
					 RechteID, Benutzername, Passwort, Vorname, Name, Geburtsdatum.Year + "-" + Geburtsdatum.Month + "-" + Geburtsdatum.Day, Straße, Hausnummer, Plz, Ort, ID);

				con.QueryEx(UpdateQuery);
			}
			catch (Exception ex)
			{

			}
		}

		public void LoadData()
		{
			try
			{
				var con = new MySQL_Anbindung.MySQLConnect();
				string UpdateQuery = String.Format(@"
                    select * from Mitarbeiter where ID='{0}'", this.ID);

				foreach (DataRow row in con.QueryEx(UpdateQuery).Rows)
				{
					this.Hausnummer = (string)row["Hnr"];
					this.Straße = (string)row["Str"];
					this.Ort = (string)row["Ort"];
					this.Plz = Convert.ToInt32(row["Plz"]);
					this.Geburtsdatum = Convert.ToDateTime(row["Geburtsdatum"]);
					this.Name = (string)row["Name"];
					this.Vorname = (string)row["Vorname"];
					this.Benutzername = (string)row["Benutzername"];
					this.RechteID = (int)row["fiRechte"];
					this.Passwort = (string)row["Passwort"];

					this._Rechte = new Rechteverwaltung.Rechte(this._rechteID);
					this._Rechte.LoadData();
				}
			}
			catch (Exception ex)
			{

			}
		}

		public void InsertDB()
		{
			try
			{
				var con = new MySQL_Anbindung.MySQLConnect();
				string UpdateQuery = String.Format(@"
                    Insert into Mitarbeiter(ID, fiRechte,Benutzername, Passwort, Vorname,Name,Geburtsdatum,Str,Hnr,Plz,Ort)
                    Values ('{0}', {1}, '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', {9}, '{10}')",
					 ID, RechteID, Benutzername, Passwort, Vorname, Name, Geburtsdatum.Year + "-" + Geburtsdatum.Month + "-" + Geburtsdatum.Day, Straße, Hausnummer, Plz, Ort);

				con.QueryEx(UpdateQuery);
			}
			catch (Exception ex)
			{

			}
		}

		public void DeleteDB()
		{
			try
			{
				var con = new MySQL_Anbindung.MySQLConnect();
				string UpdateQuery = String.Format(@"
                    Delete from Mitarbeiter where Id='{0}'", ID);

				con.QueryEx(UpdateQuery);
			}
			catch (Exception ex)
			{

			}
		}
		#endregion
	}
}
