DROP DATABASE IF EXISTS EMMA;
CREATE DATABASE EMMA;
USE EMMA;

DROP TABLE IF EXISTS Rechte;
DROP TABLE IF EXISTS Artikel;
DROP TABLE IF EXISTS Bestand;
DROP TABLE IF EXISTS Bestellung;
DROP TABLE IF EXISTS Posten;
DROP TABLE IF EXISTS Person;
DROP TABLE IF EXISTS Mitarbeiter;

CREATE TABLE `Rechte` (
  `ID` int(11) NOT NULL,
  `Status` enum('Hilfskraft','Personal','Chef') NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB;

CREATE TABLE `Kunde` (
  `ID` char(36) NOT NULL,
  `Vorname` varchar(45) DEFAULT NULL,
  `Name` varchar(45) DEFAULT NULL,
  `Geburtsdatum` DATE ,
  `Str` varchar(45) DEFAULT NULL,
  `Hnr` varchar(7) DEFAULT NULL,
  `Plz` char(5) DEFAULT NULL,
  `Ort` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB ;


CREATE TABLE `Mitarbeiter` (
  `ID` char(36) NOT NULL,
  `fiRechte` int(11) NOT NULL,
  `Benutzername` varchar(45) NOT NULL,
  `Passwort` varchar(45) NOT NULL,
  `Vorname` varchar(45) DEFAULT NULL,
  `Name` varchar(45) DEFAULT NULL,
  `Geburtsdatum` DATE ,
  `Str` varchar(45) DEFAULT NULL,
  `Hnr` varchar(7) DEFAULT NULL,
  `Plz` char(5) DEFAULT NULL,
  `Ort` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `fiRechte` (`fiRechte`),
 FOREIGN KEY (`fiRechte`) REFERENCES `rechte` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB;


CREATE TABLE `Artikel` (
  `ID` char(36) NOT NULL,
  `Name` varchar(45) NULL,
  `Preis` double DEFAULT NULL,
  `ArtikelTyp` varchar(45) DEFAULT NULL,
  `ArtikelNr` varchar(25) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB;

CREATE TABLE `Bestand` (
  `ID` char(36) NOT NULL,
  `fiArtikel` char(36) NOT NULL,
  `RegalNummer` int(11) DEFAULT NULL,
  `PlatzNummer` int(11) DEFAULT NULL,
  `Menge` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  CONSTRAINT `bestand_ibfk_1` FOREIGN KEY (`fiArtikel`) REFERENCES `artikel` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB ;


CREATE TABLE `Bestellung` (
  `ID` char(36) NOT NULL,
  `fiKunde` char(36) NOT NULL,
  `fiMitarbeiter` char(36) NOT NULL,
  `wiederkehrend` tinyint DEFAULT NULL,
  `LieferungAm` date DEFAULT NULL,
  `BestelltAm` date DEFAULT NULL,
  `Status` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `fiKunde` (`fiKunde`),
  KEY `fiMitarbeiter` (`fiMitarbeiter`),
  CONSTRAINT `bestellung_ibfk_1` FOREIGN KEY (`fiKunde`) REFERENCES `kunde` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `bestellung_ibfk_2` FOREIGN KEY (`fiMitarbeiter`) REFERENCES `mitarbeiter` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE `Posten` (
  `ID` char(36) NOT NULL,
  `fiArtikel` char(36) NOT NULL,
  `fiBestellung` char(36) NOT NULL,
  `Menge` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `fiArtikel` (`fiArtikel`),
  KEY `fiBestellung` (`fiBestellung`),
  CONSTRAINT `posten_ibfk_1` FOREIGN KEY (`fiArtikel`) REFERENCES `artikel` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `posten_ibfk_2` FOREIGN KEY (`fiBestellung`) REFERENCES `bestellung` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB;

INSERT INTO `emma`.`Artikel`
(`ID`,
`Name`,
`Preis`,
`Artikeltyp`)
VALUES
(UUID(),"Apfel", 0.36,"Obst"),
(UUID(),"Birne", 0.41,"Obst"),
(UUID(),"Bananen", 1.29,"Obst"),
(UUID(),"Schokolade", 2.32,"S��waren"),
(UUID(),"Kakao", 1.83,"S��waren"),
(UUID(),"Milch", 0.23,"Milchprodukte"),
(UUID(),"Honig", 0.43,"S��waren"),
(UUID(),"Brot", 1.23,"Backwaren"),
(UUID(),"Mega Hero Zeitschrift", 2.49,"Zeitschrift");


INSERT INTO `emma`.`Kunde`
(`ID`,`Vorname`,
`Name`,
`Geburtsdatum`,
`Str`,
`Hnr`,
`Plz`,
`Ort`)
VALUES
(UUID(),"Fritz", "Baumgart", "1993-04-20", "Herbst Stra�e", "2a", "48290", "K�ln"),
(UUID(),"Norbert", "B�gelbrett", "2001-03-01", "Br�ggen Stra�e", "2a", "32390", "K�ln"),
(UUID(),"Anna", "Weg", "1995-05-03", "Orbit Allee", "2a", "43490", "K�ln"),
(UUID(),"Rudolf", "Gather", "1986-02-04", "Troisdorfer Stra�e", "2a", "43230", "K�ln"),
(UUID(),"Arnold", "Black", "1991-05-08", "Zentralen Stra�e", "2a", "48340", "K�ln"),
(UUID(),"Emma", "Rich", "1987-03-02", "Luxenburger Stra�e", "32", "48340", "K�ln");

INSERT INTO `emma`.`Rechte` 
  (`Id`,
  `Status`)
  VALUES 
  (1,"Chef"),
  (2,"Hilfskraft"),
  (3,"Personal");

INSERT INTO `emma`.`mitarbeiter`
(`ID`,`fiRechte`,
`Benutzername`,
`Passwort`,
`Vorname`,
`Name`,
`Geburtsdatum`,
`Str`,
`Hnr`,
`Plz`,
`Ort`)
VALUES
(UUID(),1, "Fabian", "test","Fabian", "K�pper", "1992-03-01", "Br�ggen Stra�e", "14", "50127", "Bergheim"),
(UUID(),2, "Pascal", "test" ,"Pascal", "Lentz", "1992-02-11", "Carl-Benz-Stra�e", "22", "50171", "Kerpen"),
(UUID(),2, "Julius", "test","Julius", "Jupp-Tupp", "1993-03-12","Brahmssta�e", "33", "32390", "K�ln"),
(UUID(),3, "Rudi", "test","Rudi", "B�gelbrett", "2001-03-01", "Petunienweg", "2a", "32390", "K�ln");


