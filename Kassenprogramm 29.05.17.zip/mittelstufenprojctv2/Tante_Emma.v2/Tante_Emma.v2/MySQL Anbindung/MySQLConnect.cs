﻿using MySql.Data.MySqlClient;
using System.Data;
using System;

namespace Tante_Emma.v2.MySQL_Anbindung
{
	public class MySQLConnect
	{
		private MySqlConnection _con;
		private MySqlCommand Cmd;
		private MySqlDataAdapter _sda;
		private DataTable _dt;

		public MySQLConnect()
		{
			_con = new MySqlConnection(Properties.Settings.Default.ConnectionString);
			_con.Open();
		}

		private void MysqlQuery(string querytext)
		{
			Cmd = new MySqlCommand(querytext, _con);
		}

		public DataTable QueryEx(string querytext = "")
		{
			if (!String.IsNullOrEmpty(querytext))
				MysqlQuery(querytext);

			_sda = new MySqlDataAdapter(Cmd);
			_dt = new DataTable();
			_sda.Fill(_dt);

			return _dt;
		}
		public void NonQueryEx(string querytext = "")
		{
			if (!String.IsNullOrEmpty(querytext))
				MysqlQuery(querytext);

			Cmd.ExecuteNonQuery();
		}
	}
}

