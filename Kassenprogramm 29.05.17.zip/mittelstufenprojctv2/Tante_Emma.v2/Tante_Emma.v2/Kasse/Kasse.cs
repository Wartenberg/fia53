﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using Tante_Emma.v2.Lager;
using System.Windows.Forms;

namespace Tante_Emma.v2.Kasse
{
	public partial class Kasse : Form
	{
		private DataTable WarenkorbDataTable = null;
		private DataTable ProduktDataTable = null;
		private List<Bestand> EditedBestand = new List<Bestand>();

		private static List<Artikel> listArtikel = null;
		public Kasse()
		{
			InitializeComponent();

		#region Rechtevergebung
			if (Program.CurrentBenutzer.RechteID == 1)
			{
				//NOOP
			}
			else if (Program.CurrentBenutzer.RechteID == 2)
			{

			}
			else if (Program.CurrentBenutzer.RechteID == 3)
			{

			}
			else
			{
				MessageBox.Show("Ein Fehler ist bei den Rechten aufgetreten!!");
			}
		}
		#endregion

		#region Kasse_Load
		private void Kasse_Load(object sender, EventArgs e)
		{
			InitializeGrids();
		}
		#endregion

		#region Button_Click Anzahl
		private void btn_Plus_Click(object sender, EventArgs e)
		{
			if (tb_Anzahl.Text == "")
			{
				tb_Anzahl.Text = "1";
			}
			else if (dgv_Produkte.SelectedRows.Count == 0)
			{
				tb_Anzahl.Text = "1";
				MessageBox.Show("Makieren sie Ihr Produkt");
			}
			else
			{
				int Anzahl = Convert.ToInt32(tb_Anzahl.Text);

				Anzahl++;

				tb_Anzahl.Text = Anzahl.ToString();
			}

		}

		private void btn_Minus_Click(object sender, EventArgs e)
		{
			if (Convert.ToInt32(tb_Anzahl.Text) <= 1)
			{
				tb_Anzahl.Text = "1";
			}
			else if (tb_Anzahl.Text == "")
			{
				tb_Anzahl.Text = "1";
			}
			else
			{
				int Anzahl = Convert.ToInt32(tb_Anzahl.Text);

				Anzahl--;

				tb_Anzahl.Text = Anzahl.ToString();
			}
		}

		private void tb_Anzahl_TextChanged(object sender, EventArgs e)
		{
			if (artikelBindingSource.Current != null)
			{
				if ((artikelBindingSource.Current as Artikel).Gesamtmenge <= 0)
				{
					btn_Warenkorb.Enabled = false;
					btn_Minus.Enabled = false;
					btn_Plus.Enabled = false;

					return;
				}
				else if (Convert.ToInt32(tb_Anzahl.Text) < (artikelBindingSource.Current as Artikel).Gesamtmenge)
				{
					btn_Warenkorb.Enabled = true;
					btn_Minus.Enabled = true;
					btn_Plus.Enabled = true;	
				}
				else if (Convert.ToInt32(tb_Anzahl.Text) == (artikelBindingSource.Current as Artikel).Gesamtmenge)
				{
					btn_Plus.Enabled = false;
					btn_Warenkorb.Enabled = true;
					btn_Minus.Enabled = true;
				}
				else if (Convert.ToInt32(tb_Anzahl.Text) > (artikelBindingSource.Current as Artikel).Gesamtmenge)
				{
					tb_Anzahl.Text = (artikelBindingSource.Current as Artikel).Gesamtmenge.ToString();
				}

				int anzahl = Convert.ToInt32(tb_Anzahl.Text);
				double einzelbetrag = (artikelBindingSource.Current as Artikel).Preis;
				double gesamtpreis = anzahl * einzelbetrag;

				tb_Summe.Text = Convert.ToString(gesamtpreis);
			}
			else
			{
				MessageBox.Show("Makieren sie Ihr Produkt");
			}
		}


		#endregion

		#region Button_Click Warenkorb Kaufen Bestellen
		// Warenkorb Datagridview mit Produkten füllen
		private void btn_Warenkorb_Click(object sender, EventArgs e)
		{
			if (artikelBindingSource.Current != null && artikelBindingSource.Current is Artikel)
			{
				int menge = Convert.ToInt32(Convert.ToInt32(tb_Anzahl.Text));
				WarenkorbDataTable.Rows.Add((artikelBindingSource.Current as Artikel).ID, 
													 (artikelBindingSource.Current as Artikel).ArtikelNr, (artikelBindingSource.Current as Artikel).Name,
													 menge, (menge * (artikelBindingSource.Current as Artikel).Preis) + " €");

				ResetMenge(menge);
				CalculateWarenkorb();

				if ((artikelBindingSource.Current as Artikel).Gesamtmenge > 0)
					tb_Anzahl.Text = "1";
				else
					tb_Anzahl.Text = "0";
			}
			else
			{
				MessageBox.Show("Die Lagermenge kann nicht überschritten werden");
			}
		}

		private void dgv_Warenkorb_MouseClick(object sender, MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Right)
			{
				ContextMenuStrip mymenu = new ContextMenuStrip();
				int postiton_xy_mouse_row = dgv_Warenkorb.HitTest(e.X, e.Y).RowIndex;

				if (postiton_xy_mouse_row >= 0)
				{
					mymenu.Items.Add("Löschen").Name = "Löschen";
				}

				mymenu.Show(dgv_Warenkorb, new Point(e.X, e.Y));
				mymenu.ItemClicked += new ToolStripItemClickedEventHandler(mymenu_ItemClicked);
			}
		}

		private void mymenu_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
		{
			if (WarenkorbBindingSource.Current != null)
			{	
				WarenkorbDataTable.Rows.Remove((WarenkorbBindingSource.Current as DataRowView).Row);

				foreach (var artikel in listArtikel)
					artikel.LoadData();

				CalculateWarenkorb();
			}
		}

		private void btn_Kaufen_Click(object sender, EventArgs e)
		{
			if (WarenkorbDataTable.Rows.Count == 0)
			{
				MessageBox.Show("Ihr Warenkorb ist leer");
			}
			else
			{
				if (MessageBox.Show("Wollen Sie die Produkte wirklich kaufen?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
				{
					WarenkorbDataTable.Clear();

					foreach (var bestand in EditedBestand)
					{
						if (bestand.Menge == 0)
							bestand.DeleteDB();
						else
							bestand.UpdateDB();
					}

					// Artikel neu laden
					foreach (var artikel in listArtikel)
						artikel.LoadData();

					tb_Gesamtbetrag.Text = "";

					artikelBindingSource.ResetBindings(false);
					WarenkorbBindingSource.ResetBindings(false);
				}
			}

		}

		#endregion

		#region ToolStripButton Kundenverwaltung Lagerverwaltung
		private void tsb_Lagerverwaltung_Click(object sender, EventArgs e)
		{
			Lager.Lager la = new Lager.Lager();
			la.ShowDialog();

			InitializeGrids();
		}
		#endregion

		#region TollStripButton Extras
		private void passwortÄndernToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Rechteverwaltung.Passwort_Ändern psae = new Rechteverwaltung.Passwort_Ändern();
			psae.ShowDialog();
		}
		#endregion

		#region TollStripButton Benutzerveraltung
		private void benutzerveraltungToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Rechteverwaltung.Benutzerverwaltung rb = new Rechteverwaltung.Benutzerverwaltung();
			rb.ShowDialog();
		}
		#endregion

		#region Methoden
		public void InitializeGrids()
		{
			ProduktDataTable = new DataTable();
			WarenkorbDataTable = new DataTable();
			listArtikel = new List<Artikel>();

			foreach (var artikel in Artikel.GetAllArtikel())
			{
				if (artikel.Gesamtmenge > 0)
					listArtikel.Add(artikel);
			}

			//Datagridview Produkte mit Datatable füllen
			ProduktDataTable.Columns.Add("ArtikelNr", typeof(string));
			ProduktDataTable.Columns.Add("Name", typeof(string));
			ProduktDataTable.Columns.Add("Preis", typeof(string));
			ProduktDataTable.Columns.Add("Menge", typeof(int));
			ProduktDataTable.Columns.Add("ArtikelID", typeof(Guid));
			ProduktDataTable.Columns.Add("BestandID", typeof(Guid));
			ProduktDataTable.Columns.Add("Regal", typeof(int));
			ProduktDataTable.Columns.Add("Platz", typeof(int));
			ProduktDataTable.Columns["BestandID"].ColumnMapping = MappingType.Hidden;
			ProduktDataTable.Columns["ArtikelID"].ColumnMapping = MappingType.Hidden;

			//Datagridview Warenkorb mit Datatable füllen
			WarenkorbDataTable.Columns.Add("ArtikelID", typeof(Guid));
			//WarenkorbDataTable.Columns.Add("BestandID", typeof(Guid));
			WarenkorbDataTable.Columns.Add("ArtikelNr", typeof(string));
			WarenkorbDataTable.Columns.Add("Name", typeof(string));
			WarenkorbDataTable.Columns.Add("Menge", typeof(int));
			WarenkorbDataTable.Columns.Add("Preis", typeof(string));		
			//WarenkorbDataTable.Columns.Add("Regal", typeof(int));
			//WarenkorbDataTable.Columns.Add("Platz", typeof(int));
			//WarenkorbDataTable.Columns["BestandID"].ColumnMapping = MappingType.Hidden;
			WarenkorbDataTable.Columns["ArtikelID"].ColumnMapping = MappingType.Hidden;
			//WarenkorbDataTable.Columns["Regal"].ColumnMapping = MappingType.Hidden;
			//WarenkorbDataTable.Columns["Platz"].ColumnMapping = MappingType.Hidden;

			foreach (var artikel in listArtikel)
			{
				foreach (var bestand in Bestand.GetListByArtikelId(artikel.ID))
				{
					ProduktDataTable.Rows.Add(artikel.ArtikelNr, artikel.Name, artikel.Preis + " €",
													  bestand.Menge, artikel.ID, bestand.ID, bestand.Regal, bestand.Platz);
				}
			}

			WarenkorbBindingSource.DataSource = WarenkorbDataTable;
			artikelBindingSource.DataSource = listArtikel;
			dgv_Warenkorb.DataSource = WarenkorbBindingSource;
		}

		private void ResetMenge(int menge)
		{
			if (artikelBindingSource.Current != null && artikelBindingSource.Current is Artikel &&
				 menge > 0 && menge <= (artikelBindingSource.Current as Artikel).Gesamtmenge)
			{
				foreach (var bestand in (artikelBindingSource.Current as Artikel).Bestandsliste)
				{
					if (menge == 0)
						break;

					if (menge >= bestand.Menge)
					{
						menge -= bestand.Menge;
						bestand.Menge = 0;
						EditedBestand.Add(bestand);
					}
					else if (menge < bestand.Menge)
					{
						bestand.Menge -= menge;
						EditedBestand.Add(bestand);
					}
				}
			}
		}

		private void CalculateWarenkorb()
		{
			decimal Gesamtbetrag = 0;
			foreach (DataRow row in WarenkorbDataTable.Rows)
			{
				foreach (DataColumn col in WarenkorbDataTable.Columns)
				{
					if (col.ColumnName == "Preis")
					{
						string[] temp = row[col].ToString().Split(' ');

						if (temp.Length > 1)
							Gesamtbetrag += Convert.ToDecimal(temp[0]);
					}
				}
			}

			tb_Gesamtbetrag.Text = Gesamtbetrag.ToString() + " €";

			artikelBindingSource.ResetBindings(false);
			WarenkorbBindingSource.ResetBindings(false);
		}
		#endregion

		private void artikelBindingSource_CurrentChanged(object sender, EventArgs e)
		{
			tb_Summe.Text = (artikelBindingSource.Current as Artikel).Preis.ToString();

			if ((artikelBindingSource.Current as Artikel).Gesamtmenge <= 0)
				tb_Anzahl.Text = "0";
			else
				tb_Anzahl.Text = "1";
		}

		private void tsb_Kundenverwaltung_Click(object sender, EventArgs e)
		{
			var KundenDlg = new Kundenverwaltung.KundenverwaltungDlg();
			KundenDlg.ShowDialog();
		}

		private void btn_Bestellen_Click(object sender, EventArgs e)
		{
			if (WarenkorbDataTable.Rows.Count > 0)
			{
				var SelectKunde = new Bestellen.SelectKundeDlg();
				if (SelectKunde.ShowDialog() == DialogResult.OK)
				{
					var CurrentBestellung = new Bestellen.Bestellung(Program.CurrentBenutzer.ID, SelectKunde.CurrentKunde.ID);
					CurrentBestellung.LieferungAm = SelectKunde.Lieferdatum;
					CurrentBestellung.BestellungsZyklus = SelectKunde.Lieferzyklus;
					CurrentBestellung.InsertDB();

					foreach (DataRow row in WarenkorbDataTable.Rows)
					{
						Bestellen.WarenkorbEintrag wke = null;

						foreach (DataColumn col in WarenkorbDataTable.Columns)
						{
							if (col.ColumnName == "ArtikelID")
							{
								wke = new Bestellen.WarenkorbEintrag(CurrentBestellung.ID, (Guid)row[col]);
							}

							if (col.ColumnName == "Menge" && wke != null)
							{
								wke.Menge = (int)row[col];
								wke.InsertDB();
							}
						}
					}

					WarenkorbDataTable.Clear();

					artikelBindingSource.ResetBindings(false);
					WarenkorbBindingSource.ResetBindings(false);
				}
			}
		}

		private void tsb_BestellUebersicht_Click(object sender, EventArgs e)
		{
			var Dlg = new Bestellen.BestellungUebersicht();
			Dlg.ShowDialog(); 
		}
	}
}

