﻿namespace Tante_Emma.v2.Kasse
{
    partial class Kasse
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Kasse));
			this.dgv_Produkte = new System.Windows.Forms.DataGridView();
			this.artikeltypDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Gesamtmenge = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.preisDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.artikelBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.dgv_Warenkorb = new System.Windows.Forms.DataGridView();
			this.artikelNrDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.nameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.preisDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.WarenkorbBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.tb_Anzahl = new System.Windows.Forms.TextBox();
			this.tb_EinzelPreis = new System.Windows.Forms.TextBox();
			this.tb_Summe = new System.Windows.Forms.TextBox();
			this.tb_Gesamtbetrag = new System.Windows.Forms.TextBox();
			this.btn_Warenkorb = new System.Windows.Forms.Button();
			this.btn_Bestellen = new System.Windows.Forms.Button();
			this.btn_Kaufen = new System.Windows.Forms.Button();
			this.tb_Suche = new System.Windows.Forms.TextBox();
			this.lb_Suche = new System.Windows.Forms.Label();
			this.lb_stück = new System.Windows.Forms.Label();
			this.lb_Summe = new System.Windows.Forms.Label();
			this.btn_Plus = new System.Windows.Forms.Button();
			this.btn_Minus = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.toolStrip1 = new System.Windows.Forms.ToolStrip();
			this.tsb_Extras = new System.Windows.Forms.ToolStripDropDownButton();
			this.passwortÄndernToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.benutzerveraltungToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.tsb_Lagerverwaltung = new System.Windows.Forms.ToolStripButton();
			this.tsb_Kundenverwaltung = new System.Windows.Forms.ToolStripButton();
			this.tsb_BestellUebersicht = new System.Windows.Forms.ToolStripButton();
			((System.ComponentModel.ISupportInitialize)(this.dgv_Produkte)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.artikelBindingSource)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dgv_Warenkorb)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.WarenkorbBindingSource)).BeginInit();
			this.toolStrip1.SuspendLayout();
			this.SuspendLayout();
			// 
			// dgv_Produkte
			// 
			this.dgv_Produkte.AllowUserToAddRows = false;
			this.dgv_Produkte.AllowUserToDeleteRows = false;
			this.dgv_Produkte.AllowUserToResizeRows = false;
			this.dgv_Produkte.AutoGenerateColumns = false;
			this.dgv_Produkte.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dgv_Produkte.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.artikeltypDataGridViewTextBoxColumn,
            this.nameDataGridViewTextBoxColumn,
            this.Gesamtmenge,
            this.preisDataGridViewTextBoxColumn});
			this.dgv_Produkte.DataSource = this.artikelBindingSource;
			this.dgv_Produkte.Location = new System.Drawing.Point(7, 55);
			this.dgv_Produkte.Name = "dgv_Produkte";
			this.dgv_Produkte.ReadOnly = true;
			this.dgv_Produkte.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.dgv_Produkte.Size = new System.Drawing.Size(444, 324);
			this.dgv_Produkte.TabIndex = 0;
			// 
			// artikeltypDataGridViewTextBoxColumn
			// 
			this.artikeltypDataGridViewTextBoxColumn.DataPropertyName = "ArtikelNr";
			this.artikeltypDataGridViewTextBoxColumn.HeaderText = "ArtikelNr";
			this.artikeltypDataGridViewTextBoxColumn.Name = "artikeltypDataGridViewTextBoxColumn";
			this.artikeltypDataGridViewTextBoxColumn.ReadOnly = true;
			// 
			// nameDataGridViewTextBoxColumn
			// 
			this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
			this.nameDataGridViewTextBoxColumn.HeaderText = "Name";
			this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
			this.nameDataGridViewTextBoxColumn.ReadOnly = true;
			// 
			// Gesamtmenge
			// 
			this.Gesamtmenge.DataPropertyName = "Gesamtmenge";
			this.Gesamtmenge.HeaderText = "Menge";
			this.Gesamtmenge.Name = "Gesamtmenge";
			this.Gesamtmenge.ReadOnly = true;
			// 
			// preisDataGridViewTextBoxColumn
			// 
			this.preisDataGridViewTextBoxColumn.DataPropertyName = "Preis";
			this.preisDataGridViewTextBoxColumn.HeaderText = "Preis";
			this.preisDataGridViewTextBoxColumn.Name = "preisDataGridViewTextBoxColumn";
			this.preisDataGridViewTextBoxColumn.ReadOnly = true;
			// 
			// artikelBindingSource
			// 
			this.artikelBindingSource.DataSource = typeof(Tante_Emma.v2.Lager.Artikel);
			this.artikelBindingSource.CurrentChanged += new System.EventHandler(this.artikelBindingSource_CurrentChanged);
			// 
			// dgv_Warenkorb
			// 
			this.dgv_Warenkorb.AllowUserToAddRows = false;
			this.dgv_Warenkorb.AllowUserToDeleteRows = false;
			this.dgv_Warenkorb.AllowUserToOrderColumns = true;
			this.dgv_Warenkorb.AllowUserToResizeColumns = false;
			this.dgv_Warenkorb.AllowUserToResizeRows = false;
			this.dgv_Warenkorb.AutoGenerateColumns = false;
			this.dgv_Warenkorb.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dgv_Warenkorb.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.artikelNrDataGridViewTextBoxColumn,
            this.nameDataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn1,
            this.preisDataGridViewTextBoxColumn1});
			this.dgv_Warenkorb.DataSource = this.WarenkorbBindingSource;
			this.dgv_Warenkorb.Location = new System.Drawing.Point(457, 55);
			this.dgv_Warenkorb.Name = "dgv_Warenkorb";
			this.dgv_Warenkorb.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.dgv_Warenkorb.Size = new System.Drawing.Size(444, 324);
			this.dgv_Warenkorb.TabIndex = 1;
			this.dgv_Warenkorb.MouseClick += new System.Windows.Forms.MouseEventHandler(this.dgv_Warenkorb_MouseClick);
			// 
			// artikelNrDataGridViewTextBoxColumn
			// 
			this.artikelNrDataGridViewTextBoxColumn.DataPropertyName = "ArtikelNr";
			this.artikelNrDataGridViewTextBoxColumn.HeaderText = "ArtikelNr";
			this.artikelNrDataGridViewTextBoxColumn.Name = "artikelNrDataGridViewTextBoxColumn";
			// 
			// nameDataGridViewTextBoxColumn1
			// 
			this.nameDataGridViewTextBoxColumn1.DataPropertyName = "Name";
			this.nameDataGridViewTextBoxColumn1.HeaderText = "Name";
			this.nameDataGridViewTextBoxColumn1.Name = "nameDataGridViewTextBoxColumn1";
			// 
			// dataGridViewTextBoxColumn1
			// 
			this.dataGridViewTextBoxColumn1.DataPropertyName = "Menge";
			this.dataGridViewTextBoxColumn1.HeaderText = "Menge";
			this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
			// 
			// preisDataGridViewTextBoxColumn1
			// 
			this.preisDataGridViewTextBoxColumn1.DataPropertyName = "Preis";
			this.preisDataGridViewTextBoxColumn1.HeaderText = "Preis";
			this.preisDataGridViewTextBoxColumn1.Name = "preisDataGridViewTextBoxColumn1";
			// 
			// WarenkorbBindingSource
			// 
			this.WarenkorbBindingSource.DataSource = typeof(Tante_Emma.v2.Lager.Artikel);
			// 
			// tb_Anzahl
			// 
			this.tb_Anzahl.Location = new System.Drawing.Point(7, 385);
			this.tb_Anzahl.Name = "tb_Anzahl";
			this.tb_Anzahl.Size = new System.Drawing.Size(100, 20);
			this.tb_Anzahl.TabIndex = 2;
			this.tb_Anzahl.Text = "1";
			this.tb_Anzahl.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.tb_Anzahl.TextChanged += new System.EventHandler(this.tb_Anzahl_TextChanged);
			// 
			// tb_EinzelPreis
			// 
			this.tb_EinzelPreis.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.artikelBindingSource, "Preis", true));
			this.tb_EinzelPreis.Enabled = false;
			this.tb_EinzelPreis.Location = new System.Drawing.Point(179, 385);
			this.tb_EinzelPreis.Name = "tb_EinzelPreis";
			this.tb_EinzelPreis.Size = new System.Drawing.Size(100, 20);
			this.tb_EinzelPreis.TabIndex = 3;
			this.tb_EinzelPreis.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// tb_Summe
			// 
			this.tb_Summe.Enabled = false;
			this.tb_Summe.Location = new System.Drawing.Point(179, 411);
			this.tb_Summe.Name = "tb_Summe";
			this.tb_Summe.Size = new System.Drawing.Size(100, 20);
			this.tb_Summe.TabIndex = 4;
			this.tb_Summe.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// tb_Gesamtbetrag
			// 
			this.tb_Gesamtbetrag.Enabled = false;
			this.tb_Gesamtbetrag.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tb_Gesamtbetrag.Location = new System.Drawing.Point(822, 385);
			this.tb_Gesamtbetrag.Name = "tb_Gesamtbetrag";
			this.tb_Gesamtbetrag.ReadOnly = true;
			this.tb_Gesamtbetrag.Size = new System.Drawing.Size(80, 22);
			this.tb_Gesamtbetrag.TabIndex = 5;
			// 
			// btn_Warenkorb
			// 
			this.btn_Warenkorb.Location = new System.Drawing.Point(326, 385);
			this.btn_Warenkorb.Name = "btn_Warenkorb";
			this.btn_Warenkorb.Size = new System.Drawing.Size(125, 35);
			this.btn_Warenkorb.TabIndex = 6;
			this.btn_Warenkorb.Text = "In den Warenkorb";
			this.btn_Warenkorb.UseVisualStyleBackColor = true;
			this.btn_Warenkorb.Click += new System.EventHandler(this.btn_Warenkorb_Click);
			// 
			// btn_Bestellen
			// 
			this.btn_Bestellen.Location = new System.Drawing.Point(709, 411);
			this.btn_Bestellen.Name = "btn_Bestellen";
			this.btn_Bestellen.Size = new System.Drawing.Size(75, 35);
			this.btn_Bestellen.TabIndex = 7;
			this.btn_Bestellen.Text = "Bestellen";
			this.btn_Bestellen.UseVisualStyleBackColor = true;
			this.btn_Bestellen.Click += new System.EventHandler(this.btn_Bestellen_Click);
			// 
			// btn_Kaufen
			// 
			this.btn_Kaufen.Location = new System.Drawing.Point(827, 411);
			this.btn_Kaufen.Name = "btn_Kaufen";
			this.btn_Kaufen.Size = new System.Drawing.Size(75, 35);
			this.btn_Kaufen.TabIndex = 8;
			this.btn_Kaufen.Text = "Kaufen";
			this.btn_Kaufen.UseVisualStyleBackColor = true;
			this.btn_Kaufen.Click += new System.EventHandler(this.btn_Kaufen_Click);
			// 
			// tb_Suche
			// 
			this.tb_Suche.Location = new System.Drawing.Point(48, 33);
			this.tb_Suche.Name = "tb_Suche";
			this.tb_Suche.Size = new System.Drawing.Size(100, 20);
			this.tb_Suche.TabIndex = 9;
			// 
			// lb_Suche
			// 
			this.lb_Suche.AutoSize = true;
			this.lb_Suche.Location = new System.Drawing.Point(4, 36);
			this.lb_Suche.Name = "lb_Suche";
			this.lb_Suche.Size = new System.Drawing.Size(38, 13);
			this.lb_Suche.TabIndex = 11;
			this.lb_Suche.Text = "Suche";
			// 
			// lb_stück
			// 
			this.lb_stück.AutoSize = true;
			this.lb_stück.Location = new System.Drawing.Point(113, 388);
			this.lb_stück.Name = "lb_stück";
			this.lb_stück.Size = new System.Drawing.Size(60, 13);
			this.lb_stück.TabIndex = 12;
			this.lb_stück.Text = "Stück zu je";
			// 
			// lb_Summe
			// 
			this.lb_Summe.AutoSize = true;
			this.lb_Summe.Location = new System.Drawing.Point(131, 414);
			this.lb_Summe.Name = "lb_Summe";
			this.lb_Summe.Size = new System.Drawing.Size(45, 13);
			this.lb_Summe.TabIndex = 13;
			this.lb_Summe.Text = "Summe:";
			// 
			// btn_Plus
			// 
			this.btn_Plus.Location = new System.Drawing.Point(77, 408);
			this.btn_Plus.Name = "btn_Plus";
			this.btn_Plus.Size = new System.Drawing.Size(30, 23);
			this.btn_Plus.TabIndex = 14;
			this.btn_Plus.Text = "+";
			this.btn_Plus.UseVisualStyleBackColor = true;
			this.btn_Plus.Click += new System.EventHandler(this.btn_Plus_Click);
			// 
			// btn_Minus
			// 
			this.btn_Minus.Location = new System.Drawing.Point(7, 408);
			this.btn_Minus.Name = "btn_Minus";
			this.btn_Minus.Size = new System.Drawing.Size(31, 23);
			this.btn_Minus.TabIndex = 15;
			this.btn_Minus.Text = "-";
			this.btn_Minus.UseVisualStyleBackColor = true;
			this.btn_Minus.Click += new System.EventHandler(this.btn_Minus_Click);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(706, 386);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(110, 16);
			this.label1.TabIndex = 16;
			this.label1.Text = "Gesamtbetrag:";
			// 
			// toolStrip1
			// 
			this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsb_Extras,
            this.tsb_Lagerverwaltung,
            this.tsb_Kundenverwaltung,
            this.tsb_BestellUebersicht});
			this.toolStrip1.Location = new System.Drawing.Point(0, 0);
			this.toolStrip1.Name = "toolStrip1";
			this.toolStrip1.Size = new System.Drawing.Size(911, 25);
			this.toolStrip1.TabIndex = 17;
			this.toolStrip1.Text = "toolStrip1";
			// 
			// tsb_Extras
			// 
			this.tsb_Extras.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.tsb_Extras.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.passwortÄndernToolStripMenuItem,
            this.benutzerveraltungToolStripMenuItem});
			this.tsb_Extras.Image = ((System.Drawing.Image)(resources.GetObject("tsb_Extras.Image")));
			this.tsb_Extras.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.tsb_Extras.Name = "tsb_Extras";
			this.tsb_Extras.Size = new System.Drawing.Size(50, 22);
			this.tsb_Extras.Text = "Extras";
			// 
			// passwortÄndernToolStripMenuItem
			// 
			this.passwortÄndernToolStripMenuItem.Name = "passwortÄndernToolStripMenuItem";
			this.passwortÄndernToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
			this.passwortÄndernToolStripMenuItem.Text = "Passwort Ändern";
			this.passwortÄndernToolStripMenuItem.Click += new System.EventHandler(this.passwortÄndernToolStripMenuItem_Click);
			// 
			// benutzerveraltungToolStripMenuItem
			// 
			this.benutzerveraltungToolStripMenuItem.Name = "benutzerveraltungToolStripMenuItem";
			this.benutzerveraltungToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
			this.benutzerveraltungToolStripMenuItem.Text = "Benutzerveraltung";
			this.benutzerveraltungToolStripMenuItem.Click += new System.EventHandler(this.benutzerveraltungToolStripMenuItem_Click);
			// 
			// tsb_Lagerverwaltung
			// 
			this.tsb_Lagerverwaltung.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.tsb_Lagerverwaltung.Image = ((System.Drawing.Image)(resources.GetObject("tsb_Lagerverwaltung.Image")));
			this.tsb_Lagerverwaltung.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.tsb_Lagerverwaltung.Name = "tsb_Lagerverwaltung";
			this.tsb_Lagerverwaltung.Size = new System.Drawing.Size(99, 22);
			this.tsb_Lagerverwaltung.Text = "Lagerverwaltung";
			this.tsb_Lagerverwaltung.Click += new System.EventHandler(this.tsb_Lagerverwaltung_Click);
			// 
			// tsb_Kundenverwaltung
			// 
			this.tsb_Kundenverwaltung.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.tsb_Kundenverwaltung.Image = ((System.Drawing.Image)(resources.GetObject("tsb_Kundenverwaltung.Image")));
			this.tsb_Kundenverwaltung.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.tsb_Kundenverwaltung.Name = "tsb_Kundenverwaltung";
			this.tsb_Kundenverwaltung.Size = new System.Drawing.Size(111, 22);
			this.tsb_Kundenverwaltung.Text = "Kundenverwaltung";
			this.tsb_Kundenverwaltung.Click += new System.EventHandler(this.tsb_Kundenverwaltung_Click);
			// 
			// tsb_BestellUebersicht
			// 
			this.tsb_BestellUebersicht.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.tsb_BestellUebersicht.Image = ((System.Drawing.Image)(resources.GetObject("tsb_BestellUebersicht.Image")));
			this.tsb_BestellUebersicht.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.tsb_BestellUebersicht.Name = "tsb_BestellUebersicht";
			this.tsb_BestellUebersicht.Size = new System.Drawing.Size(94, 22);
			this.tsb_BestellUebersicht.Text = "Bestellübersicht";
			this.tsb_BestellUebersicht.Click += new System.EventHandler(this.tsb_BestellUebersicht_Click);
			// 
			// Kasse
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(911, 452);
			this.Controls.Add(this.toolStrip1);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.btn_Minus);
			this.Controls.Add(this.btn_Plus);
			this.Controls.Add(this.lb_Summe);
			this.Controls.Add(this.lb_stück);
			this.Controls.Add(this.lb_Suche);
			this.Controls.Add(this.tb_Suche);
			this.Controls.Add(this.btn_Kaufen);
			this.Controls.Add(this.btn_Bestellen);
			this.Controls.Add(this.btn_Warenkorb);
			this.Controls.Add(this.tb_Gesamtbetrag);
			this.Controls.Add(this.tb_Summe);
			this.Controls.Add(this.tb_EinzelPreis);
			this.Controls.Add(this.tb_Anzahl);
			this.Controls.Add(this.dgv_Warenkorb);
			this.Controls.Add(this.dgv_Produkte);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "Kasse";
			this.Load += new System.EventHandler(this.Kasse_Load);
			((System.ComponentModel.ISupportInitialize)(this.dgv_Produkte)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.artikelBindingSource)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dgv_Warenkorb)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.WarenkorbBindingSource)).EndInit();
			this.toolStrip1.ResumeLayout(false);
			this.toolStrip1.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_Produkte;
        private System.Windows.Forms.DataGridView dgv_Warenkorb;
        private System.Windows.Forms.TextBox tb_Anzahl;
        private System.Windows.Forms.TextBox tb_EinzelPreis;
        private System.Windows.Forms.TextBox tb_Summe;
        private System.Windows.Forms.TextBox tb_Gesamtbetrag;
        private System.Windows.Forms.Button btn_Warenkorb;
        private System.Windows.Forms.Button btn_Bestellen;
        private System.Windows.Forms.Button btn_Kaufen;
        private System.Windows.Forms.TextBox tb_Suche;
        private System.Windows.Forms.Label lb_Suche;
        private System.Windows.Forms.Label lb_stück;
        private System.Windows.Forms.Label lb_Summe;
        private System.Windows.Forms.DataGridViewTextBoxColumn mengeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn regalnrDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn platznrDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource artikelBindingSource;
        private System.Windows.Forms.Button btn_Plus;
        private System.Windows.Forms.Button btn_Minus;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripDropDownButton tsb_Extras;
        private System.Windows.Forms.ToolStripMenuItem passwortÄndernToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem benutzerveraltungToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton tsb_Lagerverwaltung;
        private System.Windows.Forms.ToolStripButton tsb_Kundenverwaltung;
		private System.Windows.Forms.BindingSource WarenkorbBindingSource;
		private System.Windows.Forms.DataGridViewTextBoxColumn gesamtmengeDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn artikeltypDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn Gesamtmenge;
		private System.Windows.Forms.DataGridViewTextBoxColumn preisDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn artikelNrDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn1;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
		private System.Windows.Forms.DataGridViewTextBoxColumn preisDataGridViewTextBoxColumn1;
		private System.Windows.Forms.ToolStripButton tsb_BestellUebersicht;
	}
}