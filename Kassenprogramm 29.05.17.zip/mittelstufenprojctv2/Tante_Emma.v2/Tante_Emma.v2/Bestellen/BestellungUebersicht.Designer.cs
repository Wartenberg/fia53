﻿namespace Tante_Emma.v2.Bestellen
{
	partial class BestellungUebersicht
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.lb_Kunden = new System.Windows.Forms.ListBox();
			this.KundeBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.lbl_ListKunde = new System.Windows.Forms.Label();
			this.lb_Bestellung = new System.Windows.Forms.ListBox();
			this.BestellungBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.lbl_Bestellung = new System.Windows.Forms.Label();
			this.lbl_Details = new System.Windows.Forms.Label();
			this.lbl_Status = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.lbl_Lieferung = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.lb_Artikel = new System.Windows.Forms.ListBox();
			this.WKEBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.lbl_Artikel = new System.Windows.Forms.Label();
			this.btn_BestellungAbschließen = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.KundeBindingSource)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.BestellungBindingSource)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.WKEBindingSource)).BeginInit();
			this.SuspendLayout();
			// 
			// lb_Kunden
			// 
			this.lb_Kunden.DataSource = this.KundeBindingSource;
			this.lb_Kunden.DisplayMember = "GanzerName";
			this.lb_Kunden.FormattingEnabled = true;
			this.lb_Kunden.Location = new System.Drawing.Point(15, 29);
			this.lb_Kunden.Name = "lb_Kunden";
			this.lb_Kunden.Size = new System.Drawing.Size(169, 251);
			this.lb_Kunden.TabIndex = 0;
			// 
			// KundeBindingSource
			// 
			this.KundeBindingSource.DataSource = typeof(Tante_Emma.v2.Kundenverwaltung.Kunde);
			this.KundeBindingSource.CurrentChanged += new System.EventHandler(this.KundeBindingSource_CurrentChanged);
			// 
			// lbl_ListKunde
			// 
			this.lbl_ListKunde.AutoSize = true;
			this.lbl_ListKunde.Location = new System.Drawing.Point(12, 13);
			this.lbl_ListKunde.Name = "lbl_ListKunde";
			this.lbl_ListKunde.Size = new System.Drawing.Size(47, 13);
			this.lbl_ListKunde.TabIndex = 1;
			this.lbl_ListKunde.Text = "Kunden:";
			// 
			// lb_Bestellung
			// 
			this.lb_Bestellung.DataSource = this.BestellungBindingSource;
			this.lb_Bestellung.DisplayMember = "ListName";
			this.lb_Bestellung.FormattingEnabled = true;
			this.lb_Bestellung.Location = new System.Drawing.Point(201, 29);
			this.lb_Bestellung.Name = "lb_Bestellung";
			this.lb_Bestellung.Size = new System.Drawing.Size(174, 251);
			this.lb_Bestellung.TabIndex = 2;
			// 
			// BestellungBindingSource
			// 
			this.BestellungBindingSource.DataSource = typeof(Tante_Emma.v2.Bestellen.Bestellung);
			this.BestellungBindingSource.CurrentChanged += new System.EventHandler(this.BestellungBindingSource_CurrentChanged);
			// 
			// lbl_Bestellung
			// 
			this.lbl_Bestellung.AutoSize = true;
			this.lbl_Bestellung.Location = new System.Drawing.Point(198, 13);
			this.lbl_Bestellung.Name = "lbl_Bestellung";
			this.lbl_Bestellung.Size = new System.Drawing.Size(71, 13);
			this.lbl_Bestellung.TabIndex = 3;
			this.lbl_Bestellung.Text = "Bestellungen:";
			// 
			// lbl_Details
			// 
			this.lbl_Details.AutoSize = true;
			this.lbl_Details.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbl_Details.Location = new System.Drawing.Point(390, 150);
			this.lbl_Details.Name = "lbl_Details";
			this.lbl_Details.Size = new System.Drawing.Size(107, 13);
			this.lbl_Details.TabIndex = 4;
			this.lbl_Details.Text = "Bestellungsübersicht:";
			// 
			// lbl_Status
			// 
			this.lbl_Status.AutoSize = true;
			this.lbl_Status.Location = new System.Drawing.Point(390, 177);
			this.lbl_Status.Name = "lbl_Status";
			this.lbl_Status.Size = new System.Drawing.Size(40, 13);
			this.lbl_Status.TabIndex = 5;
			this.lbl_Status.Text = "Status:";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.BestellungBindingSource, "Status", true));
			this.label1.Location = new System.Drawing.Point(498, 177);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(0, 13);
			this.label1.TabIndex = 6;
			// 
			// lbl_Lieferung
			// 
			this.lbl_Lieferung.AutoSize = true;
			this.lbl_Lieferung.Location = new System.Drawing.Point(390, 203);
			this.lbl_Lieferung.Name = "lbl_Lieferung";
			this.lbl_Lieferung.Size = new System.Drawing.Size(65, 13);
			this.lbl_Lieferung.TabIndex = 7;
			this.lbl_Lieferung.Text = "Lieferdatum:";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.BestellungBindingSource, "LieferungCaption", true));
			this.label2.Location = new System.Drawing.Point(498, 203);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(0, 13);
			this.label2.TabIndex = 8;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(390, 227);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(93, 13);
			this.label3.TabIndex = 9;
			this.label3.Text = "Bestellungsdatum:";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.BestellungBindingSource, "BestelltAm", true));
			this.label4.Location = new System.Drawing.Point(498, 227);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(0, 13);
			this.label4.TabIndex = 10;
			// 
			// lb_Artikel
			// 
			this.lb_Artikel.DataSource = this.WKEBindingSource;
			this.lb_Artikel.DisplayMember = "ListName";
			this.lb_Artikel.FormattingEnabled = true;
			this.lb_Artikel.Location = new System.Drawing.Point(393, 29);
			this.lb_Artikel.Name = "lb_Artikel";
			this.lb_Artikel.Size = new System.Drawing.Size(174, 95);
			this.lb_Artikel.TabIndex = 11;
			// 
			// WKEBindingSource
			// 
			this.WKEBindingSource.DataSource = typeof(Tante_Emma.v2.Bestellen.WarenkorbEintrag);
			// 
			// lbl_Artikel
			// 
			this.lbl_Artikel.AutoSize = true;
			this.lbl_Artikel.Location = new System.Drawing.Point(390, 13);
			this.lbl_Artikel.Name = "lbl_Artikel";
			this.lbl_Artikel.Size = new System.Drawing.Size(39, 13);
			this.lbl_Artikel.TabIndex = 12;
			this.lbl_Artikel.Text = "Artikel:";
			// 
			// btn_BestellungAbschließen
			// 
			this.btn_BestellungAbschließen.Enabled = false;
			this.btn_BestellungAbschließen.Location = new System.Drawing.Point(393, 257);
			this.btn_BestellungAbschließen.Name = "btn_BestellungAbschließen";
			this.btn_BestellungAbschließen.Size = new System.Drawing.Size(174, 23);
			this.btn_BestellungAbschließen.TabIndex = 13;
			this.btn_BestellungAbschließen.Text = "Bestellung abschließen";
			this.btn_BestellungAbschließen.UseVisualStyleBackColor = true;
			this.btn_BestellungAbschließen.Click += new System.EventHandler(this.btn_BestellungAbschließen_Click);
			// 
			// BestellungUebersicht
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(580, 290);
			this.Controls.Add(this.btn_BestellungAbschließen);
			this.Controls.Add(this.lbl_Artikel);
			this.Controls.Add(this.lb_Artikel);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.lbl_Lieferung);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.lbl_Status);
			this.Controls.Add(this.lbl_Details);
			this.Controls.Add(this.lbl_Bestellung);
			this.Controls.Add(this.lb_Bestellung);
			this.Controls.Add(this.lbl_ListKunde);
			this.Controls.Add(this.lb_Kunden);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "BestellungUebersicht";
			this.ShowIcon = false;
			this.ShowInTaskbar = false;
			((System.ComponentModel.ISupportInitialize)(this.KundeBindingSource)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.BestellungBindingSource)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.WKEBindingSource)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.ListBox lb_Kunden;
		private System.Windows.Forms.Label lbl_ListKunde;
		private System.Windows.Forms.BindingSource KundeBindingSource;
		private System.Windows.Forms.ListBox lb_Bestellung;
		private System.Windows.Forms.BindingSource BestellungBindingSource;
		private System.Windows.Forms.Label lbl_Bestellung;
		private System.Windows.Forms.Label lbl_Details;
		private System.Windows.Forms.Label lbl_Status;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label lbl_Lieferung;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.ListBox lb_Artikel;
		private System.Windows.Forms.Label lbl_Artikel;
		private System.Windows.Forms.BindingSource WKEBindingSource;
		private System.Windows.Forms.Button btn_BestellungAbschließen;
	}
}