﻿using System;
using System.Data;
using System.Collections.Generic;

namespace Tante_Emma.v2.Bestellen
{
	public class WarenkorbEintrag : Interfaces.IDBMethoden
	{
		#region Private Member
		private Guid _id;
		private Guid _vorgangid;
		private Guid _artikelid;
		private int _menge;
		#endregion

		#region C'tor
		public WarenkorbEintrag()
		{
			_id = Guid.NewGuid();
			_vorgangid = Guid.Empty;
			_artikelid = Guid.Empty;
			_menge = 0;
		}

		public WarenkorbEintrag(Guid Bestellung, Guid Artikel)
			: this()
		{
			_vorgangid = Bestellung;
			_artikelid = Artikel;
		}
		#endregion

		#region Properties
		public Guid ID
		{
			get
			{
				return _id;
			}
			set
			{
				if (value != null && value != Guid.Empty)
					_id = value;
			}
		}

		public Guid ArtikelId
		{
			get
			{
				return _artikelid;
			}
			set
			{
				if (value != null && value != Guid.Empty)
					_artikelid = value;
			}
		}

		public Lager.Artikel Artikel
		{
			get
			{
				var temp = new Lager.Artikel();
				temp.ID = _artikelid;
				temp.LoadData();

				return temp;
			}
		}

		public Guid VorgangId
		{
			get
			{
				return _vorgangid;
			}
			set
			{
				if (value != null && value != Guid.Empty)
					_vorgangid = value;
			}
		}

		public int Menge
		{
			get
			{
				return _menge;
			}
			set
			{
				if (value > 0 && value != _menge)
					_menge = value;
			}
		}

		public string ListName
		{
			get
			{
				try
				{
					return Menge + "x  " + Artikel.Name;
				}
				catch
				{
					return String.Empty;
				}
			}
		}

		#endregion

		#region DB-Methoden
		public void LoadData()
		{
			try
			{
				var con = new MySQL_Anbindung.MySQLConnect();
				string UpdateQuery = String.Format(@"
                    select * from Posten where ID='{0}'", this.ID);

				foreach (DataRow row in con.QueryEx(UpdateQuery).Rows)
				{
					this.ArtikelId = (Guid)row["fiArtikel"];
					this.VorgangId = (Guid)row["fiBestellung"];
					this.Menge = (int)row["Menge"];
				}
			}
			catch (Exception ex)
			{

			}
		}

		public void UpdateDB()
		{
			try
			{
				var con = new MySQL_Anbindung.MySQLConnect();
				string UpdateQuery = String.Format(@"
                    update Posten set
                    fiBestellung = '{1}',
						  fiArtikel = '{2}',
						  Menge = {3}
						  where ID = '{0}'",
					 ID, VorgangId, ArtikelId, Menge);

				con.QueryEx(UpdateQuery);
			}
			catch (Exception ex)
			{

			}
		}

		public void InsertDB()
		{
			try
			{
				var con = new MySQL_Anbindung.MySQLConnect();
				string UpdateQuery = String.Format(@"
                    Insert into Posten(ID, fiBestellung, fiArtikel, Menge)
                    Values ('{0}', '{1}', '{2}', {3})", ID, VorgangId, ArtikelId, Menge);

				con.QueryEx(UpdateQuery);
			}
			catch (Exception ex)
			{

			}
		}

		public void DeleteDB()
		{
			try
			{
				var con = new MySQL_Anbindung.MySQLConnect();
				string UpdateQuery = String.Format(@"
                    Delete from Posten where Id='{0}'", ID);

				con.QueryEx(UpdateQuery);
			}
			catch (Exception ex)
			{

			}
		}

		public static List<WarenkorbEintrag> GetByVorgangId(Guid Vorgang)
		{
			try
			{
				var list = new List<WarenkorbEintrag>();
				var con = new MySQL_Anbindung.MySQLConnect();
				string UpdateQuery = String.Format(@"
                    select * from Posten where fiBestellung='{0}'", Vorgang);

				foreach (DataRow row in con.QueryEx(UpdateQuery).Rows)
				{
					var temp = new WarenkorbEintrag();
					temp.ArtikelId = (Guid)row["fiArtikel"];
					temp.VorgangId = (Guid)row["fiBestellung"];
					temp.Menge = (int)row["Menge"];

					list.Add(temp);
				}

				return list;
			}
			catch (Exception ex)
			{

			}

			return null;
		}
		#endregion
	}
}
