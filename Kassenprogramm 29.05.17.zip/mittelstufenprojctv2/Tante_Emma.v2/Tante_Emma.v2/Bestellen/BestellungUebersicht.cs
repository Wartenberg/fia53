﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Tante_Emma.v2.Bestellen
{
	public partial class BestellungUebersicht : Form
	{
		private List<Bestellung> listBestellung;
		private List<Kundenverwaltung.Kunde> listKunden;
		private List<WarenkorbEintrag> listWKE;

		public BestellungUebersicht()
		{
			InitializeComponent();

			listBestellung = new List<Bestellung>();
			listKunden = Kundenverwaltung.Kunde.GetAllKunden();
			listWKE = new List<WarenkorbEintrag>();

			ResetList();
		}

		private void KundeBindingSource_CurrentChanged(object sender, EventArgs e)
		{
			listWKE.Clear();
			listBestellung.Clear();
			
			if (KundeBindingSource.Current != null)
			{
				listBestellung = Bestellung.GetBestellungenByKundeId((KundeBindingSource.Current as Kundenverwaltung.Kunde).ID);

				ResetList();
			}
		}

		private void BestellungBindingSource_CurrentChanged(object sender, EventArgs e)
		{
			if (BestellungBindingSource.Current != null)
			{
				listWKE = WarenkorbEintrag.GetByVorgangId((BestellungBindingSource.Current as Bestellung).ID);

				ResetList();

				if ((BestellungBindingSource.Current as Bestellung).Status == "Offen" &&
					 (BestellungBindingSource.Current as Bestellung).LieferungAm.ToShortDateString() == DateTime.Now.ToShortDateString())
				{
					btn_BestellungAbschließen.Enabled = true;
				}
				else
				{
					btn_BestellungAbschließen.Enabled = false;
				}
			}
		}

		private void ResetList()
		{
			WKEBindingSource.Clear();

			KundeBindingSource.DataSource = listKunden;
			BestellungBindingSource.DataSource = listBestellung;
			
			WKEBindingSource.DataSource = listWKE;
		}

		private void btn_BestellungAbschließen_Click(object sender, EventArgs e)
		{
			// Einmalig
			if ((BestellungBindingSource.Current as Bestellung).BestellungsZyklus == 1)
				(BestellungBindingSource.Current as Bestellung).Status = "Abgeschlossen";
			//Täglich
			else if ((BestellungBindingSource.Current as Bestellung).BestellungsZyklus == 2)
				(BestellungBindingSource.Current as Bestellung).LieferungAm = (BestellungBindingSource.Current as Bestellung).LieferungAm.AddDays(1);
			//Wöchentlich
			else if ((BestellungBindingSource.Current as Bestellung).BestellungsZyklus == 3)
				(BestellungBindingSource.Current as Bestellung).LieferungAm = (BestellungBindingSource.Current as Bestellung).LieferungAm.AddDays(7);
			//Monatlich
			else if ((BestellungBindingSource.Current as Bestellung).BestellungsZyklus == 4)
				(BestellungBindingSource.Current as Bestellung).LieferungAm = (BestellungBindingSource.Current as Bestellung).LieferungAm.AddMonths(1);

			(BestellungBindingSource.Current as Bestellung).UpdateDB();

			btn_BestellungAbschließen.Enabled = false;
		}
	}
}
