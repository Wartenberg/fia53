﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Tante_Emma.v2.Bestellen
{
	public partial class SelectKundeDlg : Form
	{
		private List<Kundenverwaltung.Kunde> listKunde;
		private Kundenverwaltung.Kunde currentKunde;
		private DateTime _Lieferdate;
		private byte _Zyklus;

		public SelectKundeDlg()
		{
			InitializeComponent();
		}

		private void SelectKundeDlg_Load(object sender, EventArgs e)
		{
			listKunde = Kundenverwaltung.Kunde.GetAllKunden();
			KundeBindingSource.DataSource = listKunde;
		}

		public Kundenverwaltung.Kunde CurrentKunde
		{
			get
			{
				if (currentKunde != null)
					return currentKunde;

				return null;
			}
		}

		public DateTime Lieferdatum
		{
			get
			{
				return _Lieferdate;
			}
		}

		public byte Lieferzyklus
		{
			get
			{
				return _Zyklus;
			}
		}

		private void btn_Cancel_Click(object sender, EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
		}

		private void btn_OK_Click(object sender, EventArgs e)
		{
			if (KundeBindingSource.Current != null && dtp_Lieferdate.Value >= DateTime.Now)
			{
				currentKunde = (KundeBindingSource.Current as Kundenverwaltung.Kunde);
				_Lieferdate = dtp_Lieferdate.Value;

				if (rb_Einmal.Checked)
					_Zyklus = Convert.ToByte(rb_Einmal.Tag);
				else if (rb_Tag.Checked)
					_Zyklus = Convert.ToByte(rb_Tag.Tag);
				else if (rb_Woche.Checked)
					_Zyklus = Convert.ToByte(rb_Woche.Tag);
				else if (rb_Monat.Checked)
					_Zyklus = Convert.ToByte(rb_Monat.Tag);
				else
					_Zyklus = 0;

				this.DialogResult = DialogResult.OK;
			}
		}
	}
}
