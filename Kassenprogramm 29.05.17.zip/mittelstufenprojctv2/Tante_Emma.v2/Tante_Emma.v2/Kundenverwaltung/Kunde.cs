﻿using System;
using System.Collections.Generic;
using System.Data;

namespace Tante_Emma.v2.Kundenverwaltung
{
	public class Kunde : Interfaces.IDBMethoden
	{
		#region Private Member
		private Guid _id;
		private string _vorname;
		private string _name;
		private string _straße;
		private string _hausnr;
		private string _ort;
		private int _plz;
		private DateTime _geburtsdatum;
		#endregion

		#region C'tor
		public Kunde()
		{
			_id = Guid.NewGuid();
			_vorname = String.Empty;
			_name = String.Empty;
			_straße = String.Empty;
			_hausnr = String.Empty;
			_ort = String.Empty;
			_plz = 0;
			_geburtsdatum = new DateTime();
		}
		#endregion

		#region Properties
		public Guid ID
		{
			get
			{
				return _id;
			}
			set
			{
				if (value != null && value != Guid.Empty)
					_id = value;
			}
		}

		public string Vorname
		{
			get
			{
				return _vorname;
			}
			set
			{
				if (!String.IsNullOrEmpty(value) && value != _vorname)
					_vorname = value;
			}
		}

		public DateTime Geburtsdatum
		{
			get
			{
				return _geburtsdatum;
			}
			set
			{
				if (value != null && value < DateTime.Now)
					_geburtsdatum = value;
			}
		}

		public string Name
		{
			get
			{
				return _name;
			}
			set
			{
				if (!String.IsNullOrEmpty(value) && value != _name)
					_name = value;
			}
		}

		public string GanzerName
		{
			get
			{
				return Vorname + ", " + Name;
			}
		}

		public string Ort
		{
			get
			{
				return _ort;
			}
			set
			{
				if (!String.IsNullOrEmpty(value) && value != _ort)
					_ort = value;
			}
		}

		public string Straße
		{
			get
			{
				return _straße;
			}
			set
			{
				if (!String.IsNullOrEmpty(value) && value != _straße)
					_straße = value;
			}
		}

		public string HausNr
		{
			get
			{
				return _hausnr;
			}
			set
			{
				if (!String.IsNullOrEmpty(value) && value != _hausnr)
					_hausnr = value;
			}
		}

		public int PLZ
		{
			get
			{
				return _plz;
			}
			set
			{
				if (value > 9999 && value < 100000)
					_plz = value;
			}
		}
		#endregion

		#region DB-Methoden
		public void LoadData()
		{
			try
			{
				var con = new MySQL_Anbindung.MySQLConnect();
				string UpdateQuery = String.Format(@"
                    select * from Kunde where ID='{0}'", this.ID);

				foreach (DataRow row in con.QueryEx(UpdateQuery).Rows)
				{
					this.Vorname = (string)row["Vorname"];
					this.Name = (string)row["Name"];
					this.Ort = (string)row["Ort"];
					this.PLZ = Convert.ToInt32(row["Plz"]);
					this.Geburtsdatum = Convert.ToDateTime(row["Geburtsdatum"]);
					this.Straße = (string)row["Str"];
					this.HausNr = (string)row["Hnr"];
				}
			}
			catch (Exception ex)
			{

			}
		}

		public void UpdateDB()
		{
			try
			{
				var con = new MySQL_Anbindung.MySQLConnect();
				string UpdateQuery = String.Format(@"
                    update Kunde set
                    Vorname = '{1}',
                    Name = '{2}', 
                    Geburtsdatum = '{3}', 
                    Str = '{4}',
						  Hnr = '{5}',
						  Plz = {6},
						  Ort = '{7}'
                    where ID = '{0}'",
					 ID, Vorname, Name, Geburtsdatum.Year + "-" + Geburtsdatum.Month + "-" + Geburtsdatum.Day, Straße, HausNr, PLZ, Ort);

				con.QueryEx(UpdateQuery);
			}
			catch (Exception ex)
			{

			}
		}

		public void InsertDB()
		{
			try
			{
				var con = new MySQL_Anbindung.MySQLConnect();
				string UpdateQuery = String.Format(@"
                    Insert into Kunde(ID, Vorname, Name, Geburtsdatum, Str, Hnr, Plz, Ort)
                    Values ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', {6}, '{7}')",
					 ID, Vorname, Name, Geburtsdatum.Year + "-" + Geburtsdatum.Month + "-" + Geburtsdatum.Day, Straße, HausNr, PLZ, Ort);

				con.QueryEx(UpdateQuery);
			}
			catch (Exception ex)
			{

			}
		}

		public void DeleteDB()
		{
			try
			{
				var con = new MySQL_Anbindung.MySQLConnect();
				string UpdateQuery = String.Format(@"
                    Delete from Kunde where Id='{0}'", ID);

				con.QueryEx(UpdateQuery);
			}
			catch (Exception ex)
			{

			}
		}

		public static List<Kunde> GetAllKunden()
		{
			try
			{
				var list = new List<Kunde>();

				var con = new MySQL_Anbindung.MySQLConnect();
				string Query = String.Format(@"
                    select ID from Kunde;");

				foreach (DataRow row in con.QueryEx(Query).Rows)
				{
					var k = new Kunde();
					k.ID = (Guid)row["ID"];

					k.LoadData();

					list.Add(k);
				}

				return list;
			}
			catch (Exception ex)
			{

			}

			return null;
		}
		#endregion
	}
}
