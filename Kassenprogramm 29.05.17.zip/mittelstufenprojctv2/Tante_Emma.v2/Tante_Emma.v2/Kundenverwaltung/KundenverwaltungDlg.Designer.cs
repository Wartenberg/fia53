﻿namespace Tante_Emma.v2.Kundenverwaltung
{
	partial class KundenverwaltungDlg
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.dgv_Kunde = new System.Windows.Forms.DataGridView();
			this.vornameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.straßeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.hausNrDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.pLZDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ortDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.KundeBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.lbl_Vorname = new System.Windows.Forms.Label();
			this.lbl_Name = new System.Windows.Forms.Label();
			this.lbl_Ort = new System.Windows.Forms.Label();
			this.lbl_Plz = new System.Windows.Forms.Label();
			this.lbl_HausNr = new System.Windows.Forms.Label();
			this.lbl_Strasse = new System.Windows.Forms.Label();
			this.lbl_GebDate = new System.Windows.Forms.Label();
			this.tb_Vorname = new System.Windows.Forms.TextBox();
			this.tb_Name = new System.Windows.Forms.TextBox();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.textBox3 = new System.Windows.Forms.TextBox();
			this.textBox4 = new System.Windows.Forms.TextBox();
			this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			this.btn_AddKunde = new System.Windows.Forms.Button();
			this.btn_DeleteKunde = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.dgv_Kunde)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.KundeBindingSource)).BeginInit();
			this.SuspendLayout();
			// 
			// dgv_Kunde
			// 
			this.dgv_Kunde.AllowUserToAddRows = false;
			this.dgv_Kunde.AllowUserToDeleteRows = false;
			this.dgv_Kunde.AllowUserToOrderColumns = true;
			this.dgv_Kunde.AllowUserToResizeColumns = false;
			this.dgv_Kunde.AllowUserToResizeRows = false;
			this.dgv_Kunde.AutoGenerateColumns = false;
			this.dgv_Kunde.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
			this.dgv_Kunde.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dgv_Kunde.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.vornameDataGridViewTextBoxColumn,
            this.nameDataGridViewTextBoxColumn,
            this.straßeDataGridViewTextBoxColumn,
            this.hausNrDataGridViewTextBoxColumn,
            this.pLZDataGridViewTextBoxColumn,
            this.ortDataGridViewTextBoxColumn});
			this.dgv_Kunde.DataSource = this.KundeBindingSource;
			this.dgv_Kunde.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
			this.dgv_Kunde.Location = new System.Drawing.Point(12, 119);
			this.dgv_Kunde.MultiSelect = false;
			this.dgv_Kunde.Name = "dgv_Kunde";
			this.dgv_Kunde.Size = new System.Drawing.Size(643, 239);
			this.dgv_Kunde.TabIndex = 0;
			// 
			// vornameDataGridViewTextBoxColumn
			// 
			this.vornameDataGridViewTextBoxColumn.DataPropertyName = "Vorname";
			this.vornameDataGridViewTextBoxColumn.HeaderText = "Vorname";
			this.vornameDataGridViewTextBoxColumn.Name = "vornameDataGridViewTextBoxColumn";
			// 
			// nameDataGridViewTextBoxColumn
			// 
			this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
			this.nameDataGridViewTextBoxColumn.HeaderText = "Name";
			this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
			// 
			// straßeDataGridViewTextBoxColumn
			// 
			this.straßeDataGridViewTextBoxColumn.DataPropertyName = "Straße";
			this.straßeDataGridViewTextBoxColumn.HeaderText = "Straße";
			this.straßeDataGridViewTextBoxColumn.Name = "straßeDataGridViewTextBoxColumn";
			// 
			// hausNrDataGridViewTextBoxColumn
			// 
			this.hausNrDataGridViewTextBoxColumn.DataPropertyName = "HausNr";
			this.hausNrDataGridViewTextBoxColumn.HeaderText = "HausNr";
			this.hausNrDataGridViewTextBoxColumn.Name = "hausNrDataGridViewTextBoxColumn";
			// 
			// pLZDataGridViewTextBoxColumn
			// 
			this.pLZDataGridViewTextBoxColumn.DataPropertyName = "PLZ";
			this.pLZDataGridViewTextBoxColumn.HeaderText = "PLZ";
			this.pLZDataGridViewTextBoxColumn.Name = "pLZDataGridViewTextBoxColumn";
			// 
			// ortDataGridViewTextBoxColumn
			// 
			this.ortDataGridViewTextBoxColumn.DataPropertyName = "Ort";
			this.ortDataGridViewTextBoxColumn.HeaderText = "Ort";
			this.ortDataGridViewTextBoxColumn.Name = "ortDataGridViewTextBoxColumn";
			// 
			// KundeBindingSource
			// 
			this.KundeBindingSource.DataSource = typeof(Tante_Emma.v2.Kundenverwaltung.Kunde);
			// 
			// lbl_Vorname
			// 
			this.lbl_Vorname.AutoSize = true;
			this.lbl_Vorname.Location = new System.Drawing.Point(12, 18);
			this.lbl_Vorname.Name = "lbl_Vorname";
			this.lbl_Vorname.Size = new System.Drawing.Size(52, 13);
			this.lbl_Vorname.TabIndex = 1;
			this.lbl_Vorname.Text = "Vorname:";
			// 
			// lbl_Name
			// 
			this.lbl_Name.AutoSize = true;
			this.lbl_Name.Location = new System.Drawing.Point(12, 44);
			this.lbl_Name.Name = "lbl_Name";
			this.lbl_Name.Size = new System.Drawing.Size(62, 13);
			this.lbl_Name.TabIndex = 2;
			this.lbl_Name.Text = "Nachname:";
			// 
			// lbl_Ort
			// 
			this.lbl_Ort.AutoSize = true;
			this.lbl_Ort.Location = new System.Drawing.Point(467, 18);
			this.lbl_Ort.Name = "lbl_Ort";
			this.lbl_Ort.Size = new System.Drawing.Size(24, 13);
			this.lbl_Ort.TabIndex = 3;
			this.lbl_Ort.Text = "Ort:";
			// 
			// lbl_Plz
			// 
			this.lbl_Plz.AutoSize = true;
			this.lbl_Plz.Location = new System.Drawing.Point(335, 18);
			this.lbl_Plz.Name = "lbl_Plz";
			this.lbl_Plz.Size = new System.Drawing.Size(30, 13);
			this.lbl_Plz.TabIndex = 4;
			this.lbl_Plz.Text = "PLZ:";
			// 
			// lbl_HausNr
			// 
			this.lbl_HausNr.AutoSize = true;
			this.lbl_HausNr.Location = new System.Drawing.Point(12, 96);
			this.lbl_HausNr.Name = "lbl_HausNr";
			this.lbl_HausNr.Size = new System.Drawing.Size(72, 13);
			this.lbl_HausNr.TabIndex = 5;
			this.lbl_HausNr.Text = "Hausnummer:";
			// 
			// lbl_Strasse
			// 
			this.lbl_Strasse.AutoSize = true;
			this.lbl_Strasse.Location = new System.Drawing.Point(12, 70);
			this.lbl_Strasse.Name = "lbl_Strasse";
			this.lbl_Strasse.Size = new System.Drawing.Size(41, 13);
			this.lbl_Strasse.TabIndex = 6;
			this.lbl_Strasse.Text = "Straße:";
			// 
			// lbl_GebDate
			// 
			this.lbl_GebDate.AutoSize = true;
			this.lbl_GebDate.Location = new System.Drawing.Point(335, 51);
			this.lbl_GebDate.Name = "lbl_GebDate";
			this.lbl_GebDate.Size = new System.Drawing.Size(76, 13);
			this.lbl_GebDate.TabIndex = 7;
			this.lbl_GebDate.Text = "Geburtsdatum:";
			// 
			// tb_Vorname
			// 
			this.tb_Vorname.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.KundeBindingSource, "Vorname", true));
			this.tb_Vorname.Location = new System.Drawing.Point(97, 15);
			this.tb_Vorname.Name = "tb_Vorname";
			this.tb_Vorname.Size = new System.Drawing.Size(217, 20);
			this.tb_Vorname.TabIndex = 8;
			this.tb_Vorname.Validated += new System.EventHandler(this.ControlsValidated);
			// 
			// tb_Name
			// 
			this.tb_Name.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.KundeBindingSource, "Name", true));
			this.tb_Name.Location = new System.Drawing.Point(97, 41);
			this.tb_Name.Name = "tb_Name";
			this.tb_Name.Size = new System.Drawing.Size(217, 20);
			this.tb_Name.TabIndex = 9;
			this.tb_Name.Validated += new System.EventHandler(this.ControlsValidated);
			// 
			// textBox1
			// 
			this.textBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.KundeBindingSource, "Straße", true));
			this.textBox1.Location = new System.Drawing.Point(97, 67);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(217, 20);
			this.textBox1.TabIndex = 10;
			this.textBox1.Validated += new System.EventHandler(this.ControlsValidated);
			// 
			// textBox2
			// 
			this.textBox2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.KundeBindingSource, "HausNr", true));
			this.textBox2.Location = new System.Drawing.Point(97, 93);
			this.textBox2.Name = "textBox2";
			this.textBox2.Size = new System.Drawing.Size(85, 20);
			this.textBox2.TabIndex = 11;
			this.textBox2.Validated += new System.EventHandler(this.ControlsValidated);
			// 
			// textBox3
			// 
			this.textBox3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.KundeBindingSource, "PLZ", true));
			this.textBox3.Location = new System.Drawing.Point(371, 15);
			this.textBox3.Name = "textBox3";
			this.textBox3.Size = new System.Drawing.Size(71, 20);
			this.textBox3.TabIndex = 12;
			this.textBox3.Validated += new System.EventHandler(this.ControlsValidated);
			// 
			// textBox4
			// 
			this.textBox4.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.KundeBindingSource, "Ort", true));
			this.textBox4.Location = new System.Drawing.Point(497, 15);
			this.textBox4.Name = "textBox4";
			this.textBox4.Size = new System.Drawing.Size(158, 20);
			this.textBox4.TabIndex = 13;
			this.textBox4.Validated += new System.EventHandler(this.ControlsValidated);
			// 
			// dateTimePicker1
			// 
			this.dateTimePicker1.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.KundeBindingSource, "Geburtsdatum", true));
			this.dateTimePicker1.Location = new System.Drawing.Point(417, 45);
			this.dateTimePicker1.Name = "dateTimePicker1";
			this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
			this.dateTimePicker1.TabIndex = 14;
			this.dateTimePicker1.Validated += new System.EventHandler(this.ControlsValidated);
			// 
			// btn_AddKunde
			// 
			this.btn_AddKunde.Location = new System.Drawing.Point(415, 365);
			this.btn_AddKunde.Name = "btn_AddKunde";
			this.btn_AddKunde.Size = new System.Drawing.Size(117, 23);
			this.btn_AddKunde.TabIndex = 15;
			this.btn_AddKunde.Text = "Kunde hinzufügen";
			this.btn_AddKunde.UseVisualStyleBackColor = true;
			this.btn_AddKunde.Click += new System.EventHandler(this.btn_AddKunde_Click);
			// 
			// btn_DeleteKunde
			// 
			this.btn_DeleteKunde.Location = new System.Drawing.Point(538, 365);
			this.btn_DeleteKunde.Name = "btn_DeleteKunde";
			this.btn_DeleteKunde.Size = new System.Drawing.Size(117, 23);
			this.btn_DeleteKunde.TabIndex = 16;
			this.btn_DeleteKunde.Text = "Kunde löschen";
			this.btn_DeleteKunde.UseVisualStyleBackColor = true;
			this.btn_DeleteKunde.Click += new System.EventHandler(this.btn_DeleteKunde_Click);
			// 
			// KundenverwaltungDlg
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(666, 395);
			this.Controls.Add(this.btn_DeleteKunde);
			this.Controls.Add(this.btn_AddKunde);
			this.Controls.Add(this.dateTimePicker1);
			this.Controls.Add(this.textBox4);
			this.Controls.Add(this.textBox3);
			this.Controls.Add(this.textBox2);
			this.Controls.Add(this.textBox1);
			this.Controls.Add(this.tb_Name);
			this.Controls.Add(this.tb_Vorname);
			this.Controls.Add(this.lbl_GebDate);
			this.Controls.Add(this.lbl_Strasse);
			this.Controls.Add(this.lbl_HausNr);
			this.Controls.Add(this.lbl_Plz);
			this.Controls.Add(this.lbl_Ort);
			this.Controls.Add(this.lbl_Name);
			this.Controls.Add(this.lbl_Vorname);
			this.Controls.Add(this.dgv_Kunde);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "KundenverwaltungDlg";
			this.ShowIcon = false;
			this.ShowInTaskbar = false;
			this.Load += new System.EventHandler(this.KundenverwaltungDlg_Load);
			((System.ComponentModel.ISupportInitialize)(this.dgv_Kunde)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.KundeBindingSource)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.DataGridView dgv_Kunde;
		private System.Windows.Forms.Label lbl_Vorname;
		private System.Windows.Forms.Label lbl_Name;
		private System.Windows.Forms.Label lbl_Ort;
		private System.Windows.Forms.Label lbl_Plz;
		private System.Windows.Forms.Label lbl_HausNr;
		private System.Windows.Forms.Label lbl_Strasse;
		private System.Windows.Forms.Label lbl_GebDate;
		private System.Windows.Forms.TextBox tb_Vorname;
		private System.Windows.Forms.TextBox tb_Name;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.TextBox textBox2;
		private System.Windows.Forms.TextBox textBox3;
		private System.Windows.Forms.TextBox textBox4;
		private System.Windows.Forms.DateTimePicker dateTimePicker1;
		private System.Windows.Forms.BindingSource KundeBindingSource;
		private System.Windows.Forms.Button btn_AddKunde;
		private System.Windows.Forms.Button btn_DeleteKunde;
		private System.Windows.Forms.DataGridViewTextBoxColumn vornameDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn straßeDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn hausNrDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn pLZDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn ortDataGridViewTextBoxColumn;
	}
}