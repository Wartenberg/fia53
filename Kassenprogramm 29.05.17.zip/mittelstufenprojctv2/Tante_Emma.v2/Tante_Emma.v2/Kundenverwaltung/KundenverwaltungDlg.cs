﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Tante_Emma.v2.Kundenverwaltung
{
	public partial class KundenverwaltungDlg : Form
	{
		private List<Kunde> CustomerList;

		public KundenverwaltungDlg()
		{
			InitializeComponent();
		}

		private void KundenverwaltungDlg_Load(object sender, EventArgs e)
		{
			CustomerList = Kunde.GetAllKunden();

			if (CustomerList != null)
				KundeBindingSource.DataSource = CustomerList;
		}

		private void btn_DeleteKunde_Click(object sender, EventArgs e)
		{
			if (KundeBindingSource.Current != null)
			{
				if (MessageBox.Show("Wollen Sie den Kunden wirklich löschen?", "Frage", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
				{
					(KundeBindingSource.Current as Kunde).DeleteDB();
					CustomerList.Remove(KundeBindingSource.Current as Kunde);

					KundeBindingSource.ResetBindings(false);
				}
			}
		}

		private void btn_AddKunde_Click(object sender, EventArgs e)
		{
			var NewKunde = new Kunde();
			NewKunde.InsertDB();
			CustomerList.Add(NewKunde);
			KundeBindingSource.ResetBindings(false);
		}

		private void ControlsValidated(object sender, EventArgs e)
		{
			if (KundeBindingSource.Current != null)
			{
				(KundeBindingSource.Current as Kunde).UpdateDB();
			}
		}
	}
}
