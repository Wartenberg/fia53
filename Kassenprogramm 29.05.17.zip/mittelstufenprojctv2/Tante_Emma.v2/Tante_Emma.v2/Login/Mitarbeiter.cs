﻿using System;

namespace Tante_Emma.v2.Login
{
	public class Mitarbeiter
	{
		#region Private Member
		private Guid _id;
		private string _vorname;
		private string _name;
		private DateTime _geburtsdatum;
		private string _straße;
		private string _hausnr;
		private int _plz;
		private string _ort;
		#endregion

		#region C'tor
		public Mitarbeiter()
		{
			_id = Guid.NewGuid();
			_vorname = String.Empty;
			_name = String.Empty;
			_geburtsdatum = DateTime.Now;
			_straße = String.Empty;
			_hausnr = String.Empty;
			_plz = 0;
			_ort = String.Empty;
		}
		#endregion

		#region Properties
		public Guid ID
		{
			get
			{
				return _id;
			}
			set
			{
				if (value != null && value != Guid.Empty)
					_id = value;
			}
		}

		public string Vorname
		{
			get
			{
				return _vorname;
			}
			set
			{
				if (!String.IsNullOrEmpty(value) && value != _vorname)
					_vorname = value;
			}
		}

		public string Name
		{
			get
			{
				return _name;
			}
			set
			{
				if (!String.IsNullOrEmpty(value) && value != _name)
					_name = value;
			}
		}

		public DateTime Geburtsdatum
		{
			get
			{
				return _geburtsdatum;
			}
			set
			{
				if (value < DateTime.Now)
					_geburtsdatum = value;
			}
		}

		public string Straße
		{
			get
			{
				return _straße;
			}
			set
			{
				if (!String.IsNullOrEmpty(value) && value != _straße)
					_straße = value;
			}
		}

		public string Hausnummer
		{
			get
			{
				return
					_hausnr;
			}
			set
			{
				if (!String.IsNullOrEmpty(value) && value != _hausnr)
					_hausnr = value;
			}
		}

		public int Plz
		{
			get
			{
				return _plz;
			}
			set
			{
				// Eine PLZ hat in Deutschland immer 5 Ziffern
				if (value > 9999 && value < 100000)
					_plz = value;
			}
		}

		public string Ort
		{
			get
			{
				return _ort;
			}
			set
			{
				if (!String.IsNullOrEmpty(value) && value != _ort)
					_ort = value;
			}
		}
		#endregion
	}
}
