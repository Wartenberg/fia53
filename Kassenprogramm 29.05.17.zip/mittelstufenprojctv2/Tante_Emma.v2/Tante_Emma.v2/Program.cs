﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace Tante_Emma.v2
{
	static class Program
	{
		public static Login.Benutzer CurrentBenutzer = null;
		public static List<Login.Benutzer> BenutzerListe = new List<Login.Benutzer>();

		/// <summary>
		/// Der Haupteinstiegspunkt für die Anwendung.
		/// </summary>
		[STAThread]
		static void Main()
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);

			var LoginDlg = new Login.Login();
			if (LoginDlg.ShowDialog() == DialogResult.OK)
			{
				Application.Run(new Kasse.Kasse());
			}
		}
	}
}
