﻿using System;
using System.Data;
using System.Collections.Generic;

namespace Tante_Emma.v2.Lager
{
	public class Bestand : Interfaces.IDBMethoden
	{
		#region private Member
		private Guid _id;
		private Guid _artikelid;
		private int _regal;
		private int _platz;
		private int _menge;
		#endregion

		#region C'tor
		public Bestand()
		{
			if (_id == null || _id == Guid.Empty)
				_id = Guid.NewGuid();

			_artikelid = Guid.Empty;
			_regal = 0;
			_menge = 0;
			_platz = 0;
		}

		public Bestand(Guid Id)
			: this()
		{
			this._id = Id;
		}
		#endregion

		#region Properties
		public Guid ID
		{
			get
			{
				return _id;
			}
			set
			{
				if (value != null && value != Guid.Empty)
					_id = value;
			}
		}

		public Guid ArtikelID
		{
			get
			{
				return _artikelid;
			}
			set
			{
				if (value != null && value != Guid.Empty)
					_artikelid = value;
			}
		}

		public int Regal
		{
			get
			{
				return _regal;
			}
			set
			{
				if (value >= 1)
					_regal = value;
			}
		}

		public int Platz
		{
			get
			{
				return _platz;
			}
			set
			{
				if (value >= 1)
					_platz = value;
			}
		}

		public int Menge
		{
			get
			{
				return _menge;
			}
			set
			{
				if (value >= 0)
					_menge = value;

			}
		}
		#endregion

		#region DB-Methoden
		public void LoadData()
		{
			try
			{
				var con = new MySQL_Anbindung.MySQLConnect();
				string UpdateQuery = String.Format(@"
                    select * from Bestand where ID='{0}'", this.ID);

				foreach (DataRow row in con.QueryEx(UpdateQuery).Rows)
				{
					this.ArtikelID = (Guid)row["fiArtikel"];
					this.Regal = (int)row["RegalNummer"];
					this.Platz = (int)row["PlatzNummer"];
					this.Menge = (int)row["Menge"];
				}
			}
			catch (Exception ex)
			{

			}
		}

		public void UpdateDB()
		{
			try
			{
				var con = new MySQL_Anbindung.MySQLConnect();
				string UpdateQuery = String.Format(@"
                    update Bestand set
                    fiArtikel = '{1}',
                    RegalNummer = {2}, 
                    PlatzNummer = {3}, 
                    Menge = {4}
                    where ID = '{0}'",
					 ID, ArtikelID, Regal, Platz, Menge);

				con.QueryEx(UpdateQuery);
			}
			catch (Exception ex)
			{

			}
		}

		public void InsertDB()
		{
			try
			{
				var con = new MySQL_Anbindung.MySQLConnect();
				string UpdateQuery = String.Format(@"
                    Insert into Bestand(ID, fiArtikel, RegalNummer, PlatzNummer, Menge)
                    Values ('{0}', '{1}', {2}, {3}, {4})",
					 ID, ArtikelID, Regal, Platz, Menge);

				con.QueryEx(UpdateQuery);
			}
			catch (Exception ex)
			{

			}
		}

		public void DeleteDB()
		{
			try
			{
				var con = new MySQL_Anbindung.MySQLConnect();
				string UpdateQuery = String.Format(@"
                    Delete from Bestand where Id='{0}'", ID);

				con.QueryEx(UpdateQuery);
			}
			catch (Exception ex)
			{

			}
		}

		public static List<Bestand> GetListByArtikelId(Guid ArtikelId)
		{
			try
			{
				var tempList = new List<Bestand>();
				var con = new MySQL_Anbindung.MySQLConnect();
				string UpdateQuery = String.Format(@"
                    select * from Bestand where fiArtikel='{0}'", ArtikelId);

				foreach (DataRow row in con.QueryEx(UpdateQuery).Rows)
				{
					var bestand = new Bestand();

					bestand.ID = (Guid)row["ID"];
					bestand.ArtikelID = (Guid)row["fiArtikel"];
					bestand.Regal = (int)row["RegalNummer"];
					bestand.Platz = (int)row["PlatzNummer"];
					bestand.Menge = (int)row["Menge"];

					tempList.Add(bestand);
				}

				return tempList;
			}
			catch (Exception ex)
			{

			}

			return null;
		}
		#endregion
	}
}
