﻿namespace Tante_Emma.v2.Lager
{
    partial class Lieferung
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.components = new System.ComponentModel.Container();
			this.gb_Produkte = new System.Windows.Forms.GroupBox();
			this.lb_Menge = new System.Windows.Forms.Label();
			this.lb_Platznummer = new System.Windows.Forms.Label();
			this.lb_Regalnummer = new System.Windows.Forms.Label();
			this.lb_Preis = new System.Windows.Forms.Label();
			this.lb_Artikeltyp = new System.Windows.Forms.Label();
			this.lb_Produktname = new System.Windows.Forms.Label();
			this.lb_ProduktNr = new System.Windows.Forms.Label();
			this.cb_Artikeltyp = new System.Windows.Forms.ComboBox();
			this.tb_Platznummer = new System.Windows.Forms.TextBox();
			this.tb_Regalnummer = new System.Windows.Forms.TextBox();
			this.tb_Menge = new System.Windows.Forms.TextBox();
			this.tb_Preis = new System.Windows.Forms.TextBox();
			this.tb_ProduktName = new System.Windows.Forms.TextBox();
			this.tb_ProduktNr = new System.Windows.Forms.TextBox();
			this.dgv_Lieferung = new System.Windows.Forms.DataGridView();
			this.artikelNrDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.artikeltypDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.preisDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.gesamtmengeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ArtikelBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.button1 = new System.Windows.Forms.Button();
			this.gb_Produkte.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgv_Lieferung)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.ArtikelBindingSource)).BeginInit();
			this.SuspendLayout();
			// 
			// gb_Produkte
			// 
			this.gb_Produkte.Controls.Add(this.lb_Menge);
			this.gb_Produkte.Controls.Add(this.lb_Platznummer);
			this.gb_Produkte.Controls.Add(this.lb_Regalnummer);
			this.gb_Produkte.Controls.Add(this.lb_Preis);
			this.gb_Produkte.Controls.Add(this.lb_Artikeltyp);
			this.gb_Produkte.Controls.Add(this.lb_Produktname);
			this.gb_Produkte.Controls.Add(this.lb_ProduktNr);
			this.gb_Produkte.Controls.Add(this.cb_Artikeltyp);
			this.gb_Produkte.Controls.Add(this.tb_Platznummer);
			this.gb_Produkte.Controls.Add(this.tb_Regalnummer);
			this.gb_Produkte.Controls.Add(this.tb_Menge);
			this.gb_Produkte.Controls.Add(this.tb_Preis);
			this.gb_Produkte.Controls.Add(this.tb_ProduktName);
			this.gb_Produkte.Controls.Add(this.tb_ProduktNr);
			this.gb_Produkte.Location = new System.Drawing.Point(12, 12);
			this.gb_Produkte.Name = "gb_Produkte";
			this.gb_Produkte.Size = new System.Drawing.Size(146, 377);
			this.gb_Produkte.TabIndex = 0;
			this.gb_Produkte.TabStop = false;
			this.gb_Produkte.Text = "Produkte";
			this.gb_Produkte.Enter += new System.EventHandler(this.gb_Produkte_Enter);
			// 
			// lb_Menge
			// 
			this.lb_Menge.AutoSize = true;
			this.lb_Menge.Location = new System.Drawing.Point(6, 182);
			this.lb_Menge.Name = "lb_Menge";
			this.lb_Menge.Size = new System.Drawing.Size(40, 13);
			this.lb_Menge.TabIndex = 13;
			this.lb_Menge.Text = "Menge";
			this.lb_Menge.Visible = false;
			// 
			// lb_Platznummer
			// 
			this.lb_Platznummer.AutoSize = true;
			this.lb_Platznummer.Location = new System.Drawing.Point(6, 260);
			this.lb_Platznummer.Name = "lb_Platznummer";
			this.lb_Platznummer.Size = new System.Drawing.Size(70, 13);
			this.lb_Platznummer.TabIndex = 12;
			this.lb_Platznummer.Text = "Platznummer:";
			this.lb_Platznummer.Visible = false;
			// 
			// lb_Regalnummer
			// 
			this.lb_Regalnummer.AutoSize = true;
			this.lb_Regalnummer.Location = new System.Drawing.Point(6, 221);
			this.lb_Regalnummer.Name = "lb_Regalnummer";
			this.lb_Regalnummer.Size = new System.Drawing.Size(75, 13);
			this.lb_Regalnummer.TabIndex = 11;
			this.lb_Regalnummer.Text = "Regalnummer:";
			this.lb_Regalnummer.Visible = false;
			// 
			// lb_Preis
			// 
			this.lb_Preis.AutoSize = true;
			this.lb_Preis.Location = new System.Drawing.Point(6, 143);
			this.lb_Preis.Name = "lb_Preis";
			this.lb_Preis.Size = new System.Drawing.Size(33, 13);
			this.lb_Preis.TabIndex = 10;
			this.lb_Preis.Text = "Preis:";
			this.lb_Preis.Visible = false;
			// 
			// lb_Artikeltyp
			// 
			this.lb_Artikeltyp.AutoSize = true;
			this.lb_Artikeltyp.Location = new System.Drawing.Point(6, 103);
			this.lb_Artikeltyp.Name = "lb_Artikeltyp";
			this.lb_Artikeltyp.Size = new System.Drawing.Size(53, 13);
			this.lb_Artikeltyp.TabIndex = 9;
			this.lb_Artikeltyp.Text = "Artikeltyp:";
			// 
			// lb_Produktname
			// 
			this.lb_Produktname.AutoSize = true;
			this.lb_Produktname.Location = new System.Drawing.Point(6, 64);
			this.lb_Produktname.Name = "lb_Produktname";
			this.lb_Produktname.Size = new System.Drawing.Size(78, 13);
			this.lb_Produktname.TabIndex = 8;
			this.lb_Produktname.Text = "Produkt Name:";
			// 
			// lb_ProduktNr
			// 
			this.lb_ProduktNr.AutoSize = true;
			this.lb_ProduktNr.Location = new System.Drawing.Point(6, 25);
			this.lb_ProduktNr.Name = "lb_ProduktNr";
			this.lb_ProduktNr.Size = new System.Drawing.Size(58, 13);
			this.lb_ProduktNr.TabIndex = 7;
			this.lb_ProduktNr.Text = "ProduktNr:";
			// 
			// cb_Artikeltyp
			// 
			this.cb_Artikeltyp.FormattingEnabled = true;
			this.cb_Artikeltyp.Location = new System.Drawing.Point(6, 119);
			this.cb_Artikeltyp.Name = "cb_Artikeltyp";
			this.cb_Artikeltyp.Size = new System.Drawing.Size(106, 21);
			this.cb_Artikeltyp.TabIndex = 6;
			// 
			// tb_Platznummer
			// 
			this.tb_Platznummer.Location = new System.Drawing.Point(6, 276);
			this.tb_Platznummer.Name = "tb_Platznummer";
			this.tb_Platznummer.Size = new System.Drawing.Size(106, 20);
			this.tb_Platznummer.TabIndex = 5;
			this.tb_Platznummer.Visible = false;
			// 
			// tb_Regalnummer
			// 
			this.tb_Regalnummer.Location = new System.Drawing.Point(6, 237);
			this.tb_Regalnummer.Name = "tb_Regalnummer";
			this.tb_Regalnummer.Size = new System.Drawing.Size(106, 20);
			this.tb_Regalnummer.TabIndex = 4;
			this.tb_Regalnummer.Visible = false;
			// 
			// tb_Menge
			// 
			this.tb_Menge.Location = new System.Drawing.Point(6, 198);
			this.tb_Menge.Name = "tb_Menge";
			this.tb_Menge.Size = new System.Drawing.Size(106, 20);
			this.tb_Menge.TabIndex = 3;
			this.tb_Menge.Visible = false;
			// 
			// tb_Preis
			// 
			this.tb_Preis.Location = new System.Drawing.Point(6, 159);
			this.tb_Preis.Name = "tb_Preis";
			this.tb_Preis.Size = new System.Drawing.Size(106, 20);
			this.tb_Preis.TabIndex = 2;
			this.tb_Preis.Visible = false;
			// 
			// tb_ProduktName
			// 
			this.tb_ProduktName.Location = new System.Drawing.Point(6, 80);
			this.tb_ProduktName.Name = "tb_ProduktName";
			this.tb_ProduktName.Size = new System.Drawing.Size(106, 20);
			this.tb_ProduktName.TabIndex = 1;
			// 
			// tb_ProduktNr
			// 
			this.tb_ProduktNr.Location = new System.Drawing.Point(6, 41);
			this.tb_ProduktNr.Name = "tb_ProduktNr";
			this.tb_ProduktNr.Size = new System.Drawing.Size(106, 20);
			this.tb_ProduktNr.TabIndex = 0;
			// 
			// dgv_Lieferung
			// 
			this.dgv_Lieferung.AllowUserToAddRows = false;
			this.dgv_Lieferung.AllowUserToDeleteRows = false;
			this.dgv_Lieferung.AllowUserToResizeColumns = false;
			this.dgv_Lieferung.AllowUserToResizeRows = false;
			this.dgv_Lieferung.AutoGenerateColumns = false;
			this.dgv_Lieferung.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dgv_Lieferung.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.artikelNrDataGridViewTextBoxColumn,
            this.artikeltypDataGridViewTextBoxColumn,
            this.nameDataGridViewTextBoxColumn,
            this.preisDataGridViewTextBoxColumn,
            this.gesamtmengeDataGridViewTextBoxColumn});
			this.dgv_Lieferung.DataSource = this.ArtikelBindingSource;
			this.dgv_Lieferung.Location = new System.Drawing.Point(164, 18);
			this.dgv_Lieferung.MultiSelect = false;
			this.dgv_Lieferung.Name = "dgv_Lieferung";
			this.dgv_Lieferung.ReadOnly = true;
			this.dgv_Lieferung.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.dgv_Lieferung.Size = new System.Drawing.Size(545, 371);
			this.dgv_Lieferung.TabIndex = 2;
			// 
			// artikelNrDataGridViewTextBoxColumn
			// 
			this.artikelNrDataGridViewTextBoxColumn.DataPropertyName = "ArtikelNr";
			this.artikelNrDataGridViewTextBoxColumn.HeaderText = "ArtikelNr";
			this.artikelNrDataGridViewTextBoxColumn.Name = "artikelNrDataGridViewTextBoxColumn";
			this.artikelNrDataGridViewTextBoxColumn.ReadOnly = true;
			// 
			// artikeltypDataGridViewTextBoxColumn
			// 
			this.artikeltypDataGridViewTextBoxColumn.DataPropertyName = "Artikeltyp";
			this.artikeltypDataGridViewTextBoxColumn.HeaderText = "Artikeltyp";
			this.artikeltypDataGridViewTextBoxColumn.Name = "artikeltypDataGridViewTextBoxColumn";
			this.artikeltypDataGridViewTextBoxColumn.ReadOnly = true;
			// 
			// nameDataGridViewTextBoxColumn
			// 
			this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
			this.nameDataGridViewTextBoxColumn.HeaderText = "Name";
			this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
			this.nameDataGridViewTextBoxColumn.ReadOnly = true;
			// 
			// preisDataGridViewTextBoxColumn
			// 
			this.preisDataGridViewTextBoxColumn.DataPropertyName = "Preis";
			this.preisDataGridViewTextBoxColumn.HeaderText = "Preis";
			this.preisDataGridViewTextBoxColumn.Name = "preisDataGridViewTextBoxColumn";
			this.preisDataGridViewTextBoxColumn.ReadOnly = true;
			// 
			// gesamtmengeDataGridViewTextBoxColumn
			// 
			this.gesamtmengeDataGridViewTextBoxColumn.DataPropertyName = "Gesamtmenge";
			this.gesamtmengeDataGridViewTextBoxColumn.HeaderText = "Gesamtmenge";
			this.gesamtmengeDataGridViewTextBoxColumn.Name = "gesamtmengeDataGridViewTextBoxColumn";
			this.gesamtmengeDataGridViewTextBoxColumn.ReadOnly = true;
			// 
			// ArtikelBindingSource
			// 
			this.ArtikelBindingSource.DataSource = typeof(Tante_Emma.v2.Lager.Artikel);
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(511, 395);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(75, 23);
			this.button1.TabIndex = 3;
			this.button1.Text = "button1";
			this.button1.UseVisualStyleBackColor = true;
			// 
			// Lieferung
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(719, 426);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.dgv_Lieferung);
			this.Controls.Add(this.gb_Produkte);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "Lieferung";
			this.ShowIcon = false;
			this.ShowInTaskbar = false;
			this.Text = "Lieferung";
			this.Load += new System.EventHandler(this.Lieferung_Load);
			this.gb_Produkte.ResumeLayout(false);
			this.gb_Produkte.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgv_Lieferung)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.ArtikelBindingSource)).EndInit();
			this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gb_Produkte;
        private System.Windows.Forms.Label lb_Menge;
        private System.Windows.Forms.Label lb_Platznummer;
        private System.Windows.Forms.Label lb_Regalnummer;
        private System.Windows.Forms.Label lb_Preis;
        private System.Windows.Forms.Label lb_Artikeltyp;
        private System.Windows.Forms.Label lb_Produktname;
        private System.Windows.Forms.Label lb_ProduktNr;
        private System.Windows.Forms.ComboBox cb_Artikeltyp;
        private System.Windows.Forms.TextBox tb_Platznummer;
        private System.Windows.Forms.TextBox tb_Regalnummer;
        private System.Windows.Forms.TextBox tb_Menge;
        private System.Windows.Forms.TextBox tb_Preis;
        private System.Windows.Forms.TextBox tb_ProduktName;
        private System.Windows.Forms.TextBox tb_ProduktNr;
        private System.Windows.Forms.DataGridView dgv_Lieferung;
		private System.Windows.Forms.BindingSource ArtikelBindingSource;
		private System.Windows.Forms.DataGridViewTextBoxColumn artikelNrDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn artikeltypDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn preisDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn gesamtmengeDataGridViewTextBoxColumn;
		private System.Windows.Forms.Button button1;
	}
}