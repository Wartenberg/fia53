﻿namespace Tante_Emma.v2.Lager
{
    partial class Lager
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.components = new System.ComponentModel.Container();
			this.dgv_Lager = new System.Windows.Forms.DataGridView();
			this.artikelNrDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.artikeltypDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.preisDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.gesamtmengeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ArtikelBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.btn_AddArtikel = new System.Windows.Forms.Button();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.btn_DeleteArtikel = new System.Windows.Forms.Button();
			this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.tsmi_LagerzugangBuchen = new System.Windows.Forms.ToolStripMenuItem();
			((System.ComponentModel.ISupportInitialize)(this.dgv_Lager)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.ArtikelBindingSource)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.contextMenuStrip1.SuspendLayout();
			this.SuspendLayout();
			// 
			// dgv_Lager
			// 
			this.dgv_Lager.AllowUserToAddRows = false;
			this.dgv_Lager.AllowUserToDeleteRows = false;
			this.dgv_Lager.AllowUserToResizeColumns = false;
			this.dgv_Lager.AllowUserToResizeRows = false;
			this.dgv_Lager.AutoGenerateColumns = false;
			this.dgv_Lager.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dgv_Lager.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.artikelNrDataGridViewTextBoxColumn,
            this.artikeltypDataGridViewTextBoxColumn,
            this.nameDataGridViewTextBoxColumn,
            this.preisDataGridViewTextBoxColumn,
            this.gesamtmengeDataGridViewTextBoxColumn});
			this.dgv_Lager.DataSource = this.ArtikelBindingSource;
			this.dgv_Lager.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
			this.dgv_Lager.Location = new System.Drawing.Point(12, 12);
			this.dgv_Lager.MultiSelect = false;
			this.dgv_Lager.Name = "dgv_Lager";
			this.dgv_Lager.RowHeadersVisible = false;
			this.dgv_Lager.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.dgv_Lager.ShowCellErrors = false;
			this.dgv_Lager.ShowRowErrors = false;
			this.dgv_Lager.Size = new System.Drawing.Size(504, 289);
			this.dgv_Lager.TabIndex = 0;
			this.dgv_Lager.TabStop = false;
			this.dgv_Lager.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_Lager_CellEndEdit);
			this.dgv_Lager.MouseClick += new System.Windows.Forms.MouseEventHandler(this.dgv_Lager_MouseClick);
			// 
			// artikelNrDataGridViewTextBoxColumn
			// 
			this.artikelNrDataGridViewTextBoxColumn.DataPropertyName = "ArtikelNr";
			this.artikelNrDataGridViewTextBoxColumn.HeaderText = "ArtikelNr";
			this.artikelNrDataGridViewTextBoxColumn.Name = "artikelNrDataGridViewTextBoxColumn";
			// 
			// artikeltypDataGridViewTextBoxColumn
			// 
			this.artikeltypDataGridViewTextBoxColumn.DataPropertyName = "Artikeltyp";
			this.artikeltypDataGridViewTextBoxColumn.HeaderText = "Artikeltyp";
			this.artikeltypDataGridViewTextBoxColumn.Name = "artikeltypDataGridViewTextBoxColumn";
			// 
			// nameDataGridViewTextBoxColumn
			// 
			this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
			this.nameDataGridViewTextBoxColumn.HeaderText = "Name";
			this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
			// 
			// preisDataGridViewTextBoxColumn
			// 
			this.preisDataGridViewTextBoxColumn.DataPropertyName = "Preis";
			this.preisDataGridViewTextBoxColumn.HeaderText = "Preis";
			this.preisDataGridViewTextBoxColumn.Name = "preisDataGridViewTextBoxColumn";
			// 
			// gesamtmengeDataGridViewTextBoxColumn
			// 
			this.gesamtmengeDataGridViewTextBoxColumn.DataPropertyName = "Gesamtmenge";
			this.gesamtmengeDataGridViewTextBoxColumn.HeaderText = "Gesamtmenge";
			this.gesamtmengeDataGridViewTextBoxColumn.Name = "gesamtmengeDataGridViewTextBoxColumn";
			this.gesamtmengeDataGridViewTextBoxColumn.ReadOnly = true;
			// 
			// ArtikelBindingSource
			// 
			this.ArtikelBindingSource.DataSource = typeof(Tante_Emma.v2.Lager.Artikel);
			// 
			// btn_AddArtikel
			// 
			this.btn_AddArtikel.Location = new System.Drawing.Point(274, 308);
			this.btn_AddArtikel.Name = "btn_AddArtikel";
			this.btn_AddArtikel.Size = new System.Drawing.Size(118, 28);
			this.btn_AddArtikel.TabIndex = 2;
			this.btn_AddArtikel.Text = "Artikel hinzufügen";
			this.btn_AddArtikel.UseVisualStyleBackColor = true;
			this.btn_AddArtikel.Click += new System.EventHandler(this.btn_AddArtikel_Click);
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = global::Tante_Emma.v2.Properties.Resources.offer;
			this.pictureBox1.Location = new System.Drawing.Point(306, 12);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(210, 114);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox1.TabIndex = 3;
			this.pictureBox1.TabStop = false;
			this.pictureBox1.Visible = false;
			// 
			// btn_DeleteArtikel
			// 
			this.btn_DeleteArtikel.Location = new System.Drawing.Point(398, 308);
			this.btn_DeleteArtikel.Name = "btn_DeleteArtikel";
			this.btn_DeleteArtikel.Size = new System.Drawing.Size(118, 28);
			this.btn_DeleteArtikel.TabIndex = 4;
			this.btn_DeleteArtikel.Text = "Artikel löschen";
			this.btn_DeleteArtikel.UseVisualStyleBackColor = true;
			this.btn_DeleteArtikel.Click += new System.EventHandler(this.btn_DeleteArtikel_Click);
			// 
			// contextMenuStrip1
			// 
			this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmi_LagerzugangBuchen});
			this.contextMenuStrip1.Name = "contextMenuStrip1";
			this.contextMenuStrip1.Size = new System.Drawing.Size(186, 48);
			// 
			// tsmi_LagerzugangBuchen
			// 
			this.tsmi_LagerzugangBuchen.Name = "tsmi_LagerzugangBuchen";
			this.tsmi_LagerzugangBuchen.Size = new System.Drawing.Size(185, 22);
			this.tsmi_LagerzugangBuchen.Text = "Lagerzugang buchen";
			this.tsmi_LagerzugangBuchen.Click += new System.EventHandler(this.tsmi_LagerzugangBuchen_Click);
			// 
			// Lager
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(524, 344);
			this.Controls.Add(this.btn_DeleteArtikel);
			this.Controls.Add(this.btn_AddArtikel);
			this.Controls.Add(this.dgv_Lager);
			this.Controls.Add(this.pictureBox1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "Lager";
			this.ShowIcon = false;
			this.ShowInTaskbar = false;
			this.Text = "Lagerverwaltung";
			this.Load += new System.EventHandler(this.Lager_Load);
			((System.ComponentModel.ISupportInitialize)(this.dgv_Lager)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.ArtikelBindingSource)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.contextMenuStrip1.ResumeLayout(false);
			this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_Lager;
        private System.Windows.Forms.Button btn_AddArtikel;
        private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.BindingSource ArtikelBindingSource;
		private System.Windows.Forms.DataGridViewTextBoxColumn artikelNrDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn artikeltypDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn preisDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn gesamtmengeDataGridViewTextBoxColumn;
		private System.Windows.Forms.Button btn_DeleteArtikel;
		private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
		private System.Windows.Forms.ToolStripMenuItem tsmi_LagerzugangBuchen;
	}
}