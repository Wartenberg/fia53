﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Tante_Emma.v2.Lager
{
	public partial class NeuerBestand : Form
	{
		private Bestand CurrentBestand;

		public NeuerBestand()
		{
			InitializeComponent();
		}

		public NeuerBestand(Bestand OldBestand)
			: this()
		{
			CurrentBestand = OldBestand;
			BestandBindingSource.DataSource = CurrentBestand;
		}

		private void btn_Abbrechen_Click(object sender, EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
		}

		private void btn_OK_Click(object sender, EventArgs e)
		{
			if (nud_Menge.Value > 0 && nud_Platz.Value > 0 && nud_Regal.Value > 0)
				this.DialogResult = DialogResult.OK;
			else
				MessageBox.Show("Es sind nicht alle Werte korrekt ausgefüllt.\nJeder Wert muss größer als 0 null. Bitte stellen Sie sicher, dass dies der Fall ist.",
										"Warnung", MessageBoxButtons.OK, MessageBoxIcon.Warning);
		}
	}
}
