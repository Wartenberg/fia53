﻿namespace Tante_Emma.v2.Rechteverwaltung
{
    partial class Passwort_Ändern
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Passwort_Ändern));
            this.gb_Passwortänder = new System.Windows.Forms.GroupBox();
            this.lb_Passwort = new System.Windows.Forms.Label();
            this.btn_Abbrechen = new System.Windows.Forms.Button();
            this.lb_PasswortWdh = new System.Windows.Forms.Label();
            this.lb_Neuespasswort = new System.Windows.Forms.Label();
            this.lb_AltesPasswort = new System.Windows.Forms.Label();
            this.btn_Ändern = new System.Windows.Forms.Button();
            this.tb_PasswortWdh = new System.Windows.Forms.TextBox();
            this.tb_NeuesPasswort = new System.Windows.Forms.TextBox();
            this.tb_AltesPasswort = new System.Windows.Forms.TextBox();
            this.gb_Passwortänder.SuspendLayout();
            this.SuspendLayout();
            // 
            // gb_Passwortänder
            // 
            this.gb_Passwortänder.Controls.Add(this.lb_Passwort);
            this.gb_Passwortänder.Controls.Add(this.btn_Abbrechen);
            this.gb_Passwortänder.Controls.Add(this.lb_PasswortWdh);
            this.gb_Passwortänder.Controls.Add(this.lb_Neuespasswort);
            this.gb_Passwortänder.Controls.Add(this.lb_AltesPasswort);
            this.gb_Passwortänder.Controls.Add(this.btn_Ändern);
            this.gb_Passwortänder.Controls.Add(this.tb_PasswortWdh);
            this.gb_Passwortänder.Controls.Add(this.tb_NeuesPasswort);
            this.gb_Passwortänder.Controls.Add(this.tb_AltesPasswort);
            this.gb_Passwortänder.Location = new System.Drawing.Point(12, 12);
            this.gb_Passwortänder.Name = "gb_Passwortänder";
            this.gb_Passwortänder.Size = new System.Drawing.Size(328, 195);
            this.gb_Passwortänder.TabIndex = 0;
            this.gb_Passwortänder.TabStop = false;
            this.gb_Passwortänder.Text = "Passwort Ändern";
            // 
            // lb_Passwort
            // 
            this.lb_Passwort.AutoSize = true;
            this.lb_Passwort.Location = new System.Drawing.Point(143, 128);
            this.lb_Passwort.Name = "lb_Passwort";
            this.lb_Passwort.Size = new System.Drawing.Size(0, 13);
            this.lb_Passwort.TabIndex = 8;
            // 
            // btn_Abbrechen
            // 
            this.btn_Abbrechen.Location = new System.Drawing.Point(235, 153);
            this.btn_Abbrechen.Name = "btn_Abbrechen";
            this.btn_Abbrechen.Size = new System.Drawing.Size(75, 23);
            this.btn_Abbrechen.TabIndex = 5;
            this.btn_Abbrechen.Text = "Abbrechen";
            this.btn_Abbrechen.UseVisualStyleBackColor = true;
            this.btn_Abbrechen.Click += new System.EventHandler(this.btn_Abbrechen_Click);
            // 
            // lb_PasswortWdh
            // 
            this.lb_PasswortWdh.AutoSize = true;
            this.lb_PasswortWdh.Location = new System.Drawing.Point(25, 104);
            this.lb_PasswortWdh.Name = "lb_PasswortWdh";
            this.lb_PasswortWdh.Size = new System.Drawing.Size(112, 13);
            this.lb_PasswortWdh.TabIndex = 6;
            this.lb_PasswortWdh.Text = "Eingabe Wiederholen:";
            // 
            // lb_Neuespasswort
            // 
            this.lb_Neuespasswort.AutoSize = true;
            this.lb_Neuespasswort.Location = new System.Drawing.Point(25, 68);
            this.lb_Neuespasswort.Name = "lb_Neuespasswort";
            this.lb_Neuespasswort.Size = new System.Drawing.Size(87, 13);
            this.lb_Neuespasswort.TabIndex = 5;
            this.lb_Neuespasswort.Text = "Neues Passwort:";
            // 
            // lb_AltesPasswort
            // 
            this.lb_AltesPasswort.AutoSize = true;
            this.lb_AltesPasswort.Location = new System.Drawing.Point(25, 36);
            this.lb_AltesPasswort.Name = "lb_AltesPasswort";
            this.lb_AltesPasswort.Size = new System.Drawing.Size(79, 13);
            this.lb_AltesPasswort.TabIndex = 4;
            this.lb_AltesPasswort.Text = "Altes Passwort:";
            // 
            // btn_Ändern
            // 
            this.btn_Ändern.Location = new System.Drawing.Point(143, 153);
            this.btn_Ändern.Name = "btn_Ändern";
            this.btn_Ändern.Size = new System.Drawing.Size(75, 23);
            this.btn_Ändern.TabIndex = 4;
            this.btn_Ändern.Text = "Ändern";
            this.btn_Ändern.UseVisualStyleBackColor = true;
            this.btn_Ändern.Click += new System.EventHandler(this.btn_Ändern_Click);
            // 
            // tb_PasswortWdh
            // 
            this.tb_PasswortWdh.Enabled = false;
            this.tb_PasswortWdh.Location = new System.Drawing.Point(143, 101);
            this.tb_PasswortWdh.Name = "tb_PasswortWdh";
            this.tb_PasswortWdh.Size = new System.Drawing.Size(167, 20);
            this.tb_PasswortWdh.TabIndex = 3;
            this.tb_PasswortWdh.UseSystemPasswordChar = true;
            this.tb_PasswortWdh.TextChanged += new System.EventHandler(this.tb_PasswortWdh_TextChanged);
            // 
            // tb_NeuesPasswort
            // 
            this.tb_NeuesPasswort.Enabled = false;
            this.tb_NeuesPasswort.Location = new System.Drawing.Point(143, 65);
            this.tb_NeuesPasswort.Name = "tb_NeuesPasswort";
            this.tb_NeuesPasswort.Size = new System.Drawing.Size(167, 20);
            this.tb_NeuesPasswort.TabIndex = 2;
            this.tb_NeuesPasswort.UseSystemPasswordChar = true;
            this.tb_NeuesPasswort.TextChanged += new System.EventHandler(this.tb_NeuesPasswort_TextChanged);
            // 
            // tb_AltesPasswort
            // 
            this.tb_AltesPasswort.Location = new System.Drawing.Point(143, 33);
            this.tb_AltesPasswort.Name = "tb_AltesPasswort";
            this.tb_AltesPasswort.Size = new System.Drawing.Size(167, 20);
            this.tb_AltesPasswort.TabIndex = 1;
            this.tb_AltesPasswort.UseSystemPasswordChar = true;
            this.tb_AltesPasswort.TextChanged += new System.EventHandler(this.tb_AltesPasswort_TextChanged);
            this.tb_AltesPasswort.KeyUp += new System.Windows.Forms.KeyEventHandler(this.tb_AltesPasswort_KeyUp);
            // 
            // Passwort_Ändern
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(375, 219);
            this.Controls.Add(this.gb_Passwortänder);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Passwort_Ändern";
            this.Text = "Passwort_Ändern";
            this.gb_Passwortänder.ResumeLayout(false);
            this.gb_Passwortänder.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gb_Passwortänder;
        private System.Windows.Forms.Label lb_AltesPasswort;
        private System.Windows.Forms.Button btn_Ändern;
        private System.Windows.Forms.TextBox tb_PasswortWdh;
        private System.Windows.Forms.TextBox tb_NeuesPasswort;
        private System.Windows.Forms.TextBox tb_AltesPasswort;
        private System.Windows.Forms.Label lb_Neuespasswort;
        private System.Windows.Forms.Label lb_PasswortWdh;
        private System.Windows.Forms.Button btn_Abbrechen;
        private System.Windows.Forms.Label lb_Passwort;
    }
}