﻿namespace Tante_Emma.v2.Rechteverwaltung
{
    partial class HinzufügenundBearbeiten
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Ok = new System.Windows.Forms.Button();
            this.btn_Abbrechen = new System.Windows.Forms.Button();
            this.tb_Benutzername = new System.Windows.Forms.TextBox();
            this.tb_Passwort = new System.Windows.Forms.TextBox();
            this.tb_PasswortWdh = new System.Windows.Forms.TextBox();
            this.cb_Status = new System.Windows.Forms.ComboBox();
            this.gB_HinzufügenBearbeiten = new System.Windows.Forms.GroupBox();
            this.lb_Check = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lb_Passwort = new System.Windows.Forms.Label();
            this.lb_Benutzername = new System.Windows.Forms.Label();
            this.lb_Status = new System.Windows.Forms.Label();
            this.gb_Status = new System.Windows.Forms.GroupBox();
            this.gb_Infos = new System.Windows.Forms.GroupBox();
            this.lb_PlzOrt = new System.Windows.Forms.Label();
            this.lb_StraßeNr = new System.Windows.Forms.Label();
            this.lb_Geburtsdat = new System.Windows.Forms.Label();
            this.lb_Name = new System.Windows.Forms.Label();
            this.lb_Vorname = new System.Windows.Forms.Label();
            this.tb_Ort = new System.Windows.Forms.TextBox();
            this.tb_Plz = new System.Windows.Forms.TextBox();
            this.tb_Hausnr = new System.Windows.Forms.TextBox();
            this.tb_Straße = new System.Windows.Forms.TextBox();
            this.dtp_Geburtsdatum = new System.Windows.Forms.DateTimePicker();
            this.tb_Name = new System.Windows.Forms.TextBox();
            this.tb_Vorname = new System.Windows.Forms.TextBox();
            this.gB_HinzufügenBearbeiten.SuspendLayout();
            this.gb_Status.SuspendLayout();
            this.gb_Infos.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_Ok
            // 
            this.btn_Ok.Location = new System.Drawing.Point(22, 423);
            this.btn_Ok.Name = "btn_Ok";
            this.btn_Ok.Size = new System.Drawing.Size(75, 23);
            this.btn_Ok.TabIndex = 5;
            this.btn_Ok.Text = "Ok";
            this.btn_Ok.UseVisualStyleBackColor = true;
            this.btn_Ok.Click += new System.EventHandler(this.btn_Ok_Click);
            // 
            // btn_Abbrechen
            // 
            this.btn_Abbrechen.Location = new System.Drawing.Point(181, 423);
            this.btn_Abbrechen.Name = "btn_Abbrechen";
            this.btn_Abbrechen.Size = new System.Drawing.Size(75, 23);
            this.btn_Abbrechen.TabIndex = 6;
            this.btn_Abbrechen.Text = "Abbrechen";
            this.btn_Abbrechen.UseVisualStyleBackColor = true;
            this.btn_Abbrechen.Click += new System.EventHandler(this.btn_Abbrechen_Click);
            // 
            // tb_Benutzername
            // 
            this.tb_Benutzername.Location = new System.Drawing.Point(92, 26);
            this.tb_Benutzername.Name = "tb_Benutzername";
            this.tb_Benutzername.Size = new System.Drawing.Size(152, 20);
            this.tb_Benutzername.TabIndex = 2;
            // 
            // tb_Passwort
            // 
            this.tb_Passwort.Location = new System.Drawing.Point(92, 52);
            this.tb_Passwort.Name = "tb_Passwort";
            this.tb_Passwort.Size = new System.Drawing.Size(152, 20);
            this.tb_Passwort.TabIndex = 3;
            this.tb_Passwort.UseSystemPasswordChar = true;
            this.tb_Passwort.TextChanged += new System.EventHandler(this.tb_Passwort_TextChanged);
            this.tb_Passwort.KeyUp += new System.Windows.Forms.KeyEventHandler(this.tb_Passwort_KeyUp_1);
            // 
            // tb_PasswortWdh
            // 
            this.tb_PasswortWdh.Enabled = false;
            this.tb_PasswortWdh.Location = new System.Drawing.Point(92, 78);
            this.tb_PasswortWdh.Name = "tb_PasswortWdh";
            this.tb_PasswortWdh.Size = new System.Drawing.Size(152, 20);
            this.tb_PasswortWdh.TabIndex = 4;
            this.tb_PasswortWdh.UseSystemPasswordChar = true;
            this.tb_PasswortWdh.TextChanged += new System.EventHandler(this.tb_PasswortWdh_TextChanged);
            // 
            // cb_Status
            // 
            this.cb_Status.FormattingEnabled = true;
            this.cb_Status.Items.AddRange(new object[] {
            "Chef",
            "Hilfskraft",
            "Personal"});
            this.cb_Status.Location = new System.Drawing.Point(92, 24);
            this.cb_Status.Name = "cb_Status";
            this.cb_Status.Size = new System.Drawing.Size(152, 21);
            this.cb_Status.TabIndex = 1;
            // 
            // gB_HinzufügenBearbeiten
            // 
            this.gB_HinzufügenBearbeiten.Controls.Add(this.lb_Check);
            this.gB_HinzufügenBearbeiten.Controls.Add(this.label4);
            this.gB_HinzufügenBearbeiten.Controls.Add(this.lb_Passwort);
            this.gB_HinzufügenBearbeiten.Controls.Add(this.lb_Benutzername);
            this.gB_HinzufügenBearbeiten.Controls.Add(this.tb_PasswortWdh);
            this.gB_HinzufügenBearbeiten.Controls.Add(this.tb_Benutzername);
            this.gB_HinzufügenBearbeiten.Controls.Add(this.tb_Passwort);
            this.gB_HinzufügenBearbeiten.Location = new System.Drawing.Point(12, 12);
            this.gB_HinzufügenBearbeiten.Name = "gB_HinzufügenBearbeiten";
            this.gB_HinzufügenBearbeiten.Size = new System.Drawing.Size(257, 142);
            this.gB_HinzufügenBearbeiten.TabIndex = 6;
            this.gB_HinzufügenBearbeiten.TabStop = false;
            this.gB_HinzufügenBearbeiten.Text = "Benutzer";
            // 
            // lb_Check
            // 
            this.lb_Check.AutoSize = true;
            this.lb_Check.Location = new System.Drawing.Point(89, 101);
            this.lb_Check.Name = "lb_Check";
            this.lb_Check.Size = new System.Drawing.Size(0, 13);
            this.lb_Check.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 81);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 26);
            this.label4.TabIndex = 9;
            this.label4.Text = "Passwort \r\nWiederholen:";
            // 
            // lb_Passwort
            // 
            this.lb_Passwort.AutoSize = true;
            this.lb_Passwort.Location = new System.Drawing.Point(6, 55);
            this.lb_Passwort.Name = "lb_Passwort";
            this.lb_Passwort.Size = new System.Drawing.Size(53, 13);
            this.lb_Passwort.TabIndex = 8;
            this.lb_Passwort.Text = "Passwort:";
            // 
            // lb_Benutzername
            // 
            this.lb_Benutzername.AutoSize = true;
            this.lb_Benutzername.Location = new System.Drawing.Point(6, 29);
            this.lb_Benutzername.Name = "lb_Benutzername";
            this.lb_Benutzername.Size = new System.Drawing.Size(78, 13);
            this.lb_Benutzername.TabIndex = 6;
            this.lb_Benutzername.Text = "Benutzername:";
            // 
            // lb_Status
            // 
            this.lb_Status.AutoSize = true;
            this.lb_Status.Location = new System.Drawing.Point(6, 27);
            this.lb_Status.Name = "lb_Status";
            this.lb_Status.Size = new System.Drawing.Size(40, 13);
            this.lb_Status.TabIndex = 7;
            this.lb_Status.Text = "Status:";
            // 
            // gb_Status
            // 
            this.gb_Status.Controls.Add(this.cb_Status);
            this.gb_Status.Controls.Add(this.lb_Status);
            this.gb_Status.Location = new System.Drawing.Point(12, 160);
            this.gb_Status.Name = "gb_Status";
            this.gb_Status.Size = new System.Drawing.Size(257, 63);
            this.gb_Status.TabIndex = 8;
            this.gb_Status.TabStop = false;
            this.gb_Status.Text = "Status";
            // 
            // gb_Infos
            // 
            this.gb_Infos.Controls.Add(this.lb_PlzOrt);
            this.gb_Infos.Controls.Add(this.lb_StraßeNr);
            this.gb_Infos.Controls.Add(this.lb_Geburtsdat);
            this.gb_Infos.Controls.Add(this.lb_Name);
            this.gb_Infos.Controls.Add(this.lb_Vorname);
            this.gb_Infos.Controls.Add(this.tb_Ort);
            this.gb_Infos.Controls.Add(this.tb_Plz);
            this.gb_Infos.Controls.Add(this.tb_Hausnr);
            this.gb_Infos.Controls.Add(this.tb_Straße);
            this.gb_Infos.Controls.Add(this.dtp_Geburtsdatum);
            this.gb_Infos.Controls.Add(this.tb_Name);
            this.gb_Infos.Controls.Add(this.tb_Vorname);
            this.gb_Infos.Location = new System.Drawing.Point(13, 229);
            this.gb_Infos.Name = "gb_Infos";
            this.gb_Infos.Size = new System.Drawing.Size(256, 188);
            this.gb_Infos.TabIndex = 9;
            this.gb_Infos.TabStop = false;
            this.gb_Infos.Text = "Personenbezogene Informationen";
            // 
            // lb_PlzOrt
            // 
            this.lb_PlzOrt.AutoSize = true;
            this.lb_PlzOrt.Location = new System.Drawing.Point(5, 139);
            this.lb_PlzOrt.Name = "lb_PlzOrt";
            this.lb_PlzOrt.Size = new System.Drawing.Size(43, 13);
            this.lb_PlzOrt.TabIndex = 12;
            this.lb_PlzOrt.Text = "Plz/Ort:";
            // 
            // lb_StraßeNr
            // 
            this.lb_StraßeNr.AutoSize = true;
            this.lb_StraßeNr.Location = new System.Drawing.Point(6, 113);
            this.lb_StraßeNr.Name = "lb_StraßeNr";
            this.lb_StraßeNr.Size = new System.Drawing.Size(83, 13);
            this.lb_StraßeNr.TabIndex = 11;
            this.lb_StraßeNr.Text = "Straße/Hausnr.:";
            // 
            // lb_Geburtsdat
            // 
            this.lb_Geburtsdat.AutoSize = true;
            this.lb_Geburtsdat.Location = new System.Drawing.Point(6, 90);
            this.lb_Geburtsdat.Name = "lb_Geburtsdat";
            this.lb_Geburtsdat.Size = new System.Drawing.Size(76, 13);
            this.lb_Geburtsdat.TabIndex = 10;
            this.lb_Geburtsdat.Text = "Geburtsdatum:";
            // 
            // lb_Name
            // 
            this.lb_Name.AutoSize = true;
            this.lb_Name.Location = new System.Drawing.Point(6, 60);
            this.lb_Name.Name = "lb_Name";
            this.lb_Name.Size = new System.Drawing.Size(38, 13);
            this.lb_Name.TabIndex = 9;
            this.lb_Name.Text = "Name:";
            // 
            // lb_Vorname
            // 
            this.lb_Vorname.AutoSize = true;
            this.lb_Vorname.Location = new System.Drawing.Point(6, 34);
            this.lb_Vorname.Name = "lb_Vorname";
            this.lb_Vorname.Size = new System.Drawing.Size(52, 13);
            this.lb_Vorname.TabIndex = 8;
            this.lb_Vorname.Text = "Vorname:";
            // 
            // tb_Ort
            // 
            this.tb_Ort.Location = new System.Drawing.Point(153, 136);
            this.tb_Ort.Name = "tb_Ort";
            this.tb_Ort.Size = new System.Drawing.Size(90, 20);
            this.tb_Ort.TabIndex = 7;
            // 
            // tb_Plz
            // 
            this.tb_Plz.Location = new System.Drawing.Point(91, 136);
            this.tb_Plz.Name = "tb_Plz";
            this.tb_Plz.Size = new System.Drawing.Size(56, 20);
            this.tb_Plz.TabIndex = 6;
            // 
            // tb_Hausnr
            // 
            this.tb_Hausnr.Location = new System.Drawing.Point(212, 110);
            this.tb_Hausnr.Name = "tb_Hausnr";
            this.tb_Hausnr.Size = new System.Drawing.Size(31, 20);
            this.tb_Hausnr.TabIndex = 5;
            // 
            // tb_Straße
            // 
            this.tb_Straße.Location = new System.Drawing.Point(91, 110);
            this.tb_Straße.Name = "tb_Straße";
            this.tb_Straße.Size = new System.Drawing.Size(115, 20);
            this.tb_Straße.TabIndex = 4;
            // 
            // dtp_Geburtsdatum
            // 
            this.dtp_Geburtsdatum.Location = new System.Drawing.Point(91, 84);
            this.dtp_Geburtsdatum.Name = "dtp_Geburtsdatum";
            this.dtp_Geburtsdatum.Size = new System.Drawing.Size(152, 20);
            this.dtp_Geburtsdatum.TabIndex = 2;
            // 
            // tb_Name
            // 
            this.tb_Name.Location = new System.Drawing.Point(91, 57);
            this.tb_Name.Name = "tb_Name";
            this.tb_Name.Size = new System.Drawing.Size(152, 20);
            this.tb_Name.TabIndex = 1;
            // 
            // tb_Vorname
            // 
            this.tb_Vorname.Location = new System.Drawing.Point(91, 31);
            this.tb_Vorname.Name = "tb_Vorname";
            this.tb_Vorname.Size = new System.Drawing.Size(152, 20);
            this.tb_Vorname.TabIndex = 0;
            // 
            // HinzufügenundBearbeiten
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(283, 469);
            this.Controls.Add(this.gb_Infos);
            this.Controls.Add(this.gb_Status);
            this.Controls.Add(this.gB_HinzufügenBearbeiten);
            this.Controls.Add(this.btn_Abbrechen);
            this.Controls.Add(this.btn_Ok);
            this.Name = "HinzufügenundBearbeiten";
            this.Text = "HinzufügenundBearbeiten";
            this.Load += new System.EventHandler(this.HinzufügenundBearbeiten_Load);
            this.gB_HinzufügenBearbeiten.ResumeLayout(false);
            this.gB_HinzufügenBearbeiten.PerformLayout();
            this.gb_Status.ResumeLayout(false);
            this.gb_Status.PerformLayout();
            this.gb_Infos.ResumeLayout(false);
            this.gb_Infos.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Ok;
        private System.Windows.Forms.Button btn_Abbrechen;
        private System.Windows.Forms.TextBox tb_Benutzername;
        private System.Windows.Forms.TextBox tb_Passwort;
        private System.Windows.Forms.TextBox tb_PasswortWdh;
        private System.Windows.Forms.ComboBox cb_Status;
        private System.Windows.Forms.GroupBox gB_HinzufügenBearbeiten;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lb_Passwort;
        private System.Windows.Forms.Label lb_Status;
        private System.Windows.Forms.Label lb_Benutzername;
        private System.Windows.Forms.Label lb_Check;
        private System.Windows.Forms.GroupBox gb_Status;
        private System.Windows.Forms.GroupBox gb_Infos;
        private System.Windows.Forms.Label lb_PlzOrt;
        private System.Windows.Forms.Label lb_StraßeNr;
        private System.Windows.Forms.Label lb_Geburtsdat;
        private System.Windows.Forms.Label lb_Name;
        private System.Windows.Forms.Label lb_Vorname;
        private System.Windows.Forms.TextBox tb_Ort;
        private System.Windows.Forms.TextBox tb_Plz;
        private System.Windows.Forms.TextBox tb_Hausnr;
        private System.Windows.Forms.TextBox tb_Straße;
        private System.Windows.Forms.DateTimePicker dtp_Geburtsdatum;
        private System.Windows.Forms.TextBox tb_Name;
        private System.Windows.Forms.TextBox tb_Vorname;
    }
}