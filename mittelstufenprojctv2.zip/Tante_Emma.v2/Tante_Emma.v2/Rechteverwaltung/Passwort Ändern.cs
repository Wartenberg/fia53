﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Tante_Emma.v2.Rechteverwaltung
{
    public partial class Passwort_Ändern : Form
    {
        private MySQL_Anbindung.MySQLConnect con;
        public Passwort_Ändern()
        {
            InitializeComponent();
        }

        private void btn_Abbrechen_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_Ändern_Click(object sender, EventArgs e)
        {
            if (tb_NeuesPasswort.Text == tb_PasswortWdh.Text && tb_AltesPasswort.Text == Program.CurrentBenutzer.Passwort)
            {
                Program.CurrentBenutzer.Passwort = tb_NeuesPasswort.Text;
                Program.CurrentBenutzer.UpdateDB();
                this.Close();
            }
            else
            {
                MessageBox.Show("Ihr altes Passwort ist falsch");

            }
        }

        private void tb_AltesPasswort_TextChanged(object sender, EventArgs e)
        {
            if (tb_AltesPasswort.Text == Program.CurrentBenutzer.Passwort)
            {
                tb_NeuesPasswort.Enabled = true;
                tb_PasswortWdh.Enabled = true;
            }
        }

        private void tb_PasswortWdh_TextChanged(object sender, EventArgs e)
        {
            if (tb_NeuesPasswort.Text == tb_PasswortWdh.Text)
            {
                    lb_Passwort.ForeColor = System.Drawing.Color.Green;
                    lb_Passwort.Text = "Passwort stimmt über ein";
                }
                else
                {
                    lb_Passwort.ForeColor = System.Drawing.Color.Red;
                    lb_Passwort.Text = "Passwort stimmt nicht über ein";
                }
            
        }

        private void tb_AltesPasswort_KeyUp(object sender, KeyEventArgs e)
        {
            if (tb_AltesPasswort.Text != Program.CurrentBenutzer.Passwort)
            {
                tb_NeuesPasswort.Enabled = false;
                tb_PasswortWdh.Enabled = false;
            }
        }

        private void tb_NeuesPasswort_TextChanged(object sender, EventArgs e)
        {
            if (tb_NeuesPasswort.Text == tb_PasswortWdh.Text)
            {
                    lb_Passwort.ForeColor = System.Drawing.Color.Green;
                    lb_Passwort.Text = "Passwort stimmt über ein";
                
            }
            else
            {
                lb_Passwort.ForeColor = System.Drawing.Color.Red;
                lb_Passwort.Text = "Passwort stimmt nicht über ein";
            }
        }
    }
}
