﻿namespace Tante_Emma.v2.Login
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lb_Passwort = new System.Windows.Forms.Label();
            this.tb_Passwort = new System.Windows.Forms.TextBox();
            this.btn_Anmelden = new System.Windows.Forms.Button();
            this.cb_Username = new System.Windows.Forms.ComboBox();
            this.lb_Username = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Tante_Emma.v2.Properties.Resources.neulich_bei_tante_emma_e709f38a_24e1_4304_9329_8c620f5ed180_min;
            this.pictureBox1.Location = new System.Drawing.Point(-3, -7);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(384, 309);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // lb_Passwort
            // 
            this.lb_Passwort.AutoSize = true;
            this.lb_Passwort.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lb_Passwort.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lb_Passwort.Location = new System.Drawing.Point(119, 176);
            this.lb_Passwort.Name = "lb_Passwort";
            this.lb_Passwort.Size = new System.Drawing.Size(50, 13);
            this.lb_Passwort.TabIndex = 6;
            this.lb_Passwort.Text = "Passwort";
            // 
            // tb_Passwort
            // 
            this.tb_Passwort.Location = new System.Drawing.Point(117, 192);
            this.tb_Passwort.Name = "tb_Passwort";
            this.tb_Passwort.Size = new System.Drawing.Size(121, 20);
            this.tb_Passwort.TabIndex = 2;
            this.tb_Passwort.UseSystemPasswordChar = true;
            // 
            // btn_Anmelden
            // 
            this.btn_Anmelden.Location = new System.Drawing.Point(262, 164);
            this.btn_Anmelden.Name = "btn_Anmelden";
            this.btn_Anmelden.Size = new System.Drawing.Size(75, 36);
            this.btn_Anmelden.TabIndex = 3;
            this.btn_Anmelden.Text = "Anmelden";
            this.btn_Anmelden.UseVisualStyleBackColor = true;
            this.btn_Anmelden.Click += new System.EventHandler(this.btn_Anmelden_Click);
            // 
            // cb_Username
            // 
            this.cb_Username.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_Username.FormattingEnabled = true;
            this.cb_Username.Location = new System.Drawing.Point(117, 147);
            this.cb_Username.Name = "cb_Username";
            this.cb_Username.Size = new System.Drawing.Size(121, 21);
            this.cb_Username.TabIndex = 4;
            this.cb_Username.SelectedIndexChanged += new System.EventHandler(this.cb_Username_SelectedIndexChanged);
            // 
            // lb_Username
            // 
            this.lb_Username.AutoSize = true;
            this.lb_Username.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lb_Username.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lb_Username.Location = new System.Drawing.Point(119, 131);
            this.lb_Username.Name = "lb_Username";
            this.lb_Username.Size = new System.Drawing.Size(55, 13);
            this.lb_Username.TabIndex = 9;
            this.lb_Username.Text = "Username";
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(378, 298);
            this.Controls.Add(this.lb_Username);
            this.Controls.Add(this.btn_Anmelden);
            this.Controls.Add(this.cb_Username);
            this.Controls.Add(this.tb_Passwort);
            this.Controls.Add(this.lb_Passwort);
            this.Controls.Add(this.pictureBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Login";
            this.Text = "Login";
            this.Load += new System.EventHandler(this.Login_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lb_Passwort;
        private System.Windows.Forms.TextBox tb_Passwort;
        private System.Windows.Forms.Button btn_Anmelden;
        private System.Windows.Forms.ComboBox cb_Username;
        private System.Windows.Forms.Label lb_Username;
    }
}