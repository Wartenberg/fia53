﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using MySql.Data.MySqlClient;
using System.Windows.Forms;

namespace Tante_Emma.v2.Kasse
{
    public partial class Kasse : Form
    {
        DataTable data = new DataTable();
        private static List<Artikel> listArtikel = new List<Artikel>();
        public Kasse()
        {

            InitializeComponent();

        #region Rechtevergebung
            if (Program.CurrentBenutzer.RechteID == 1)
            {
                //NOOP
            }
            else if (Program.CurrentBenutzer.RechteID == 2)
            {

            }
            else if (Program.CurrentBenutzer.RechteID == 3)
            {

            }
            else
            {
                MessageBox.Show("Ein Fehler ist bei den Rechten aufgetreten!!");
            }
        }
        #endregion


        #region Kasse_Load
        private void Kasse_Load(object sender, EventArgs e)
        {
            Load_Kasse();
        }

        #endregion


        #region Suchfeld
        // Suche im Textfeld "Suche" über Linq
        private void tb_Suche_TextChanged(object sender, EventArgs e)
        {
            {
            
                var filterArtikel = (from a in listArtikel
                                     where a.Name.ToUpper().Contains(tb_Suche.Text.ToUpper())
                                     select a).ToList();
                dgv_Produkte.DataSource = filterArtikel;
            }
        }
        #endregion


        #region Button_Click Anzahl
        private void btn_Plus_Click(object sender, EventArgs e)
        {
            if (tb_Anzahl.Text == "")
            {
                tb_Anzahl.Text = "1";
            }
            else if (dgv_Produkte.SelectedRows.Count == 0)
            {
                tb_Anzahl.Text = "1";
                MessageBox.Show("Makieren sie Ihr Produkt");
            }

            else
            {
                int Anzahl = Convert.ToInt32(tb_Anzahl.Text);

                Anzahl++;

                tb_Anzahl.Text = Anzahl.ToString();

            }

        }

        private void btn_Minus_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(tb_Anzahl.Text) <= 1)
            {
                tb_Anzahl.Text = "1";
            }
            else if (tb_Anzahl.Text == "")
            {
                tb_Anzahl.Text = "1";
            }
            else
            {
                int Anzahl = Convert.ToInt32(tb_Anzahl.Text);

                Anzahl--;

                tb_Anzahl.Text = Anzahl.ToString();

            }

        }

        private void tb_Anzahl_TextChanged(object sender, EventArgs e)
        {
            if (dgv_Produkte.SelectedRows.Count == 0)
            {
                MessageBox.Show("Makieren sie Ihr Produkt");
            }
            else
            {
                if (Convert.ToInt32(tb_Anzahl.Text) == 0)
                {
                    btn_Warenkorb.Enabled = false;
                    btn_Minus.Enabled = false;
                    btn_Plus.Enabled = false;
                }
                else if (Convert.ToInt32(tb_Anzahl.Text) <= Convert.ToInt32(dgv_Produkte.SelectedRows[0].Cells[4].Value.ToString()))
                {
                    btn_Warenkorb.Enabled = true;
                    int anzahl = Convert.ToInt32(tb_Anzahl.Text);
                    double einzelbetrag = Convert.ToDouble(tb_EinzelPreis.Text);
                    double gesamtpreis = anzahl * einzelbetrag;


                    tb_Summe.Text = Convert.ToString(gesamtpreis);
                }
                else
                {
                    MessageBox.Show("Die Lagermenge kann nicht überschritten werden");
                    tb_Anzahl.Text = dgv_Produkte.SelectedRows[0].Cells[4].Value.ToString();
                }

            }
        }


        #endregion


        #region Button_Click Warenkorb Kaufen Bestellen
        // Warenkorb Datagridview mit Produkten füllen
        private void btn_Warenkorb_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(tb_Anzahl.Text) <= Convert.ToInt32(dgv_Produkte.SelectedRows[0].Cells[4].Value.ToString()))
            {
                data.Rows.Add(dgv_Produkte.SelectedRows[0].Cells[0].Value.ToString(), dgv_Produkte.SelectedRows[0].Cells[1].Value.ToString(), dgv_Produkte.SelectedRows[0].Cells[2].Value.ToString(), tb_Summe.Text, tb_Anzahl.Text, dgv_Produkte.SelectedRows[0].Cells[5].Value.ToString(), dgv_Produkte.SelectedRows[0].Cells[6].Value.ToString());
                this.dgv_Warenkorb.Columns[0].Visible = false;
                this.dgv_Warenkorb.Columns[5].Visible = false;
                this.dgv_Warenkorb.Columns[6].Visible = false;
                dgv_Warenkorb.DataSource = data;

                int menge = Convert.ToInt32(dgv_Produkte.SelectedRows[0].Cells[4].Value.ToString()) - Convert.ToInt32(tb_Anzahl.Text);
                dgv_Produkte.SelectedRows[0].Cells[4].Value = menge;
                tb_Anzahl.Text = dgv_Produkte.SelectedRows[0].Cells[4].Value.ToString();

                decimal gesamt = 0;

                for (int i = 0; i < dgv_Warenkorb.Rows.Count; ++i)
                {
                    gesamt += Convert.ToDecimal(dgv_Warenkorb.Rows[i].Cells[3].Value);
                }
                tb_Gesamtbetrag.Text = gesamt.ToString() + (" €");
                if (dgv_Produkte.SelectedRows[0].Cells[4].Value.ToString() == "0" )
                {
                    tb_Anzahl.Text = "0";
                }
                else
                {
                    tb_Anzahl.Text = "1";
                }
             
            }

            else
            {
                MessageBox.Show("Die Lagermenge kann nicht überschritten werden");
            }
        }

        private void dgv_Warenkorb_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {

            }
            else
            {
                ContextMenuStrip mymenu = new ContextMenuStrip();
                int postiton_xy_mouse_row = dgv_Warenkorb.HitTest(e.X, e.Y).RowIndex;

                if (postiton_xy_mouse_row >= 0)
                {
                    mymenu.Items.Add("Löschen").Name = "Löschen";

                }
                mymenu.Show(dgv_Warenkorb, new Point(e.X, e.Y));

                mymenu.ItemClicked += new ToolStripItemClickedEventHandler(mymenu_ItemClicked);

            }
        }
        void mymenu_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

            int index = Convert.ToInt32(dgv_Warenkorb.SelectedRows[0].Cells[0].Value.ToString());

            int menge = (int)dgv_Warenkorb.SelectedRows[0].Cells[4].Value;

            foreach (DataGridViewRow item in dgv_Produkte.Rows)
            {
                if ((int)item.Cells[0].Value == index)
                {
                    item.Cells[4].Value = Convert.ToInt32(item.Cells[4].Value) + menge;
                }
            }

            int rowIndex = dgv_Warenkorb.SelectedRows[0].Index;
            dgv_Warenkorb.Rows.RemoveAt(rowIndex);



            decimal gesamt = 0;


            for (int i = 0; i < dgv_Warenkorb.Rows.Count; ++i)
            {
                gesamt += Convert.ToDecimal(dgv_Warenkorb.Rows[i].Cells[3].Value);
            }
            tb_Gesamtbetrag.Text = gesamt.ToString() + (" €");
        }

        private void btn_Kaufen_Click(object sender, EventArgs e)
        {
            if (dgv_Warenkorb.RowCount == 0)
            {
                MessageBox.Show("Ihr Warenkorb ist leer");
            }
            else
            {
                if (MessageBox.Show("Wollen Sie die Produkte wirklich kaufen?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {

                    

                    data.Clear();

                    //Update

                    tb_Summe.Text = "";
                    tb_Gesamtbetrag.Text = "";
                }
            }

        }
        private void dgv_Produkte_SelectionChanged(object sender, EventArgs e)
        {
            if (dgv_Produkte.SelectedRows.Count > 0 && Convert.ToInt32(dgv_Produkte.SelectedRows[0].Cells[4].Value.ToString()) == 0)
            {
                tb_Anzahl.Text = "0";
                btn_Minus.Enabled = false;
                btn_Plus.Enabled = false;
            }
            else if (dgv_Produkte.SelectedRows.Count > 0 && Convert.ToInt32(dgv_Produkte.SelectedRows[0].Cells[4].Value.ToString()) >= 0)
            {
                btn_Minus.Enabled = true;
                btn_Plus.Enabled = true;
                btn_Warenkorb.Enabled = true;
                tb_EinzelPreis.Text = dgv_Produkte.SelectedRows[0].Cells[3].Value.ToString();

                int anzahl = Convert.ToInt32(tb_Anzahl.Text);
                double einzelbetrag = Convert.ToDouble(tb_EinzelPreis.Text);
                double gesamtpreis = anzahl * einzelbetrag;


                tb_Summe.Text = Convert.ToString(gesamtpreis);

                tb_Anzahl.Text = "1";
            }
        }


        #endregion

        
        #region ToolStripButton Kundenverwaltung Lagerverwaltung
        private void tsb_Lagerverwaltung_Click(object sender, EventArgs e)
        {
            Lager.Lager la = new Lager.Lager();
            la.ShowDialog();
        }
        #endregion
        

        #region TollStripButton Extras
        private void passwortÄndernToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Rechteverwaltung.Passwort_Ändern psae = new Rechteverwaltung.Passwort_Ändern();
            psae.ShowDialog();
        }
        #endregion


        #region TollStripButton Benutzerveraltung
        private void benutzerveraltungToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Rechteverwaltung.Benutzerverwaltung rb = new Rechteverwaltung.Benutzerverwaltung();
            rb.ShowDialog();
        }
        #endregion


        #region Methoden
        public void Load_Kasse()
        {

            // Datagridview Produkte mit Artikelklasse füllen
            var artikel = new Artikel();

            listArtikel = artikel.getArtikel();

            dgv_Produkte.DataSource = listArtikel;

            // Einstellung Einkaufswagen Datagridview
            this.dgv_Produkte.RowHeadersVisible = false;
            dgv_Produkte.Columns[0].Visible = false;
            dgv_Produkte.Columns[5].Visible = false;
            dgv_Produkte.Columns[6].Visible = false;


            //Datagridview Warenkorb mit Datatable füllen

            data.Columns.Add("ID", typeof(int));
            data.Columns.Add("Name", typeof(string));
            data.Columns.Add("Artikeltyp", typeof(string));
            data.Columns.Add("Preis", typeof(decimal));
            data.Columns.Add("Menge", typeof(int));
            data.Columns.Add("RegalNummer", typeof(int));
            data.Columns.Add("Platznummer", typeof(int));
            dgv_Warenkorb.DataSource = data;

            // Einstellung Einkaufswagen Datagridview
            this.dgv_Warenkorb.RowHeadersVisible = false;
            this.dgv_Warenkorb.Columns["Menge"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            this.dgv_Warenkorb.Columns["Preis"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }
        #endregion
    }
}

