﻿namespace Tante_Emma.v2.Lager
{
    partial class Lager
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgv_Lager = new System.Windows.Forms.DataGridView();
            this.btn_Änderung = new System.Windows.Forms.Button();
            this.btn_Lieferung = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Lager)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv_Lager
            // 
            this.dgv_Lager.AllowUserToAddRows = false;
            this.dgv_Lager.AllowUserToDeleteRows = false;
            this.dgv_Lager.AllowUserToResizeColumns = false;
            this.dgv_Lager.AllowUserToResizeRows = false;
            this.dgv_Lager.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Lager.Location = new System.Drawing.Point(12, 132);
            this.dgv_Lager.Name = "dgv_Lager";
            this.dgv_Lager.RowHeadersVisible = false;
            this.dgv_Lager.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_Lager.Size = new System.Drawing.Size(742, 289);
            this.dgv_Lager.TabIndex = 0;
            this.dgv_Lager.TabStop = false;
            // 
            // btn_Änderung
            // 
            this.btn_Änderung.Location = new System.Drawing.Point(12, 427);
            this.btn_Änderung.Name = "btn_Änderung";
            this.btn_Änderung.Size = new System.Drawing.Size(130, 35);
            this.btn_Änderung.TabIndex = 1;
            this.btn_Änderung.Text = "Änderung";
            this.btn_Änderung.UseVisualStyleBackColor = true;
            // 
            // btn_Lieferung
            // 
            this.btn_Lieferung.Location = new System.Drawing.Point(624, 427);
            this.btn_Lieferung.Name = "btn_Lieferung";
            this.btn_Lieferung.Size = new System.Drawing.Size(130, 35);
            this.btn_Lieferung.TabIndex = 2;
            this.btn_Lieferung.Text = "Lieferung";
            this.btn_Lieferung.UseVisualStyleBackColor = true;
            this.btn_Lieferung.Click += new System.EventHandler(this.btn_Lieferung_Click_1);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Tante_Emma.v2.Properties.Resources.offer;
            this.pictureBox1.Location = new System.Drawing.Point(578, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(176, 114);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // Lager
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(774, 477);
            this.Controls.Add(this.btn_Lieferung);
            this.Controls.Add(this.btn_Änderung);
            this.Controls.Add(this.dgv_Lager);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Lager";
            this.Text = "Lager";
            this.Load += new System.EventHandler(this.Lager_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Lager)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_Lager;
        private System.Windows.Forms.Button btn_Änderung;
        private System.Windows.Forms.Button btn_Lieferung;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}