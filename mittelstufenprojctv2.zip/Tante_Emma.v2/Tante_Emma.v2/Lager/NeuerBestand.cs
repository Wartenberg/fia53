﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Tante_Emma.v2.Lager
{
    public partial class NeuerBestand : Form
    {
        private readonly string _id;
        private readonly string _menge;
        private readonly string _platznummer;
        private readonly string _regalnummer;
        private MySQL_Anbindung.MySQLConnect con;

        private static List<Kasse.Artikel> listArtikel = new List<Kasse.Artikel>();
        public NeuerBestand(string id = "", string Platznummer = "", string Regalnummer ="",  string Menge = "")
        {
            InitializeComponent();
            _id = id;
            _menge = Menge;
            _regalnummer = Regalnummer;
            _platznummer = Platznummer;
        }

        private void btn_Abbrechen_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void NeuerBestand_Load(object sender, EventArgs e)
        {
            tb_AlterBestand.Text = _menge;

        }

        private void btn_OK_Click(object sender, EventArgs e)
        {
            con = new MySQL_Anbindung.MySQLConnect();
            con.MysqlQuery("UPDATE Bestand SET Menge = (" + tb_NeuerBestand.Text + ") WHERE fiArtikel = " + _id + " AND RegalNummer = " + _regalnummer + " AND PlatzNummer = " + _platznummer + ";");
            con.QueryEx();

            if (MessageBox.Show("Die Lieferung wurde eingelagert", "", MessageBoxButtons.OK, MessageBoxIcon.Information) == DialogResult.OK)
            {

                this.Close();
            }

        }
    }
}
