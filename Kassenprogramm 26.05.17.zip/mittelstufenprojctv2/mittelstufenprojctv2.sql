DROP DATABASE IF EXISTS EMMA;
CREATE DATABASE EMMA;
USE EMMA;

DROP TABLE IF EXISTS Rechte;
DROP TABLE IF EXISTS Artikel;
DROP TABLE IF EXISTS Bestand;
DROP TABLE IF EXISTS Bestellung;
DROP TABLE IF EXISTS Posten;
DROP TABLE IF EXISTS Person;
DROP TABLE IF EXISTS Mitarbeiter;

CREATE TABLE `Rechte` (
  `ID` int(11) NOT NULL,
  `Status` enum('Hilfskraft','Personal','Chef') NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB;

CREATE TABLE `Kunde` (
  `ID` char(36) NOT NULL,
  `Vorname` varchar(45) DEFAULT NULL,
  `Name` varchar(45) DEFAULT NULL,
  `Geburtsdatum` DATE ,
  `Str` varchar(45) DEFAULT NULL,
  `Hnr` varchar(7) DEFAULT NULL,
  `Plz` char(5) DEFAULT NULL,
  `Ort` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB ;


CREATE TABLE `Mitarbeiter` (
  `ID` char(36) NOT NULL,
  `fiRechte` int(11) NOT NULL,
  `Benutzername` varchar(45) NOT NULL,
  `Passwort` varchar(45) NOT NULL,
  `Vorname` varchar(45) DEFAULT NULL,
  `Name` varchar(45) DEFAULT NULL,
  `Geburtsdatum` DATE ,
  `Str` varchar(45) DEFAULT NULL,
  `Hnr` varchar(7) DEFAULT NULL,
  `Plz` char(5) DEFAULT NULL,
  `Ort` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `fiRechte` (`fiRechte`),
 FOREIGN KEY (`fiRechte`) REFERENCES `rechte` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB;


CREATE TABLE `Artikel` (
  `ID` char(36) NOT NULL,
  `Name` varchar(45) NULL,
  `Preis` double DEFAULT NULL,
  `ArtikelTyp` varchar(45) DEFAULT NULL,
  `ArtikelNr` varchar(25) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB;

CREATE TABLE `Bestand` (
  `ID` char(36) NOT NULL,
  `fiArtikel` char(36) NOT NULL,
  `RegalNummer` int(11) DEFAULT NULL,
  `PlatzNummer` int(11) DEFAULT NULL,
  `Menge` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  CONSTRAINT `bestand_ibfk_1` FOREIGN KEY (`fiArtikel`) REFERENCES `artikel` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB ;


CREATE TABLE `Bestellung` (
  `ID` char(36) NOT NULL,
  `fiPerson` char(36) NOT NULL,
  `fiMitarbeiter` char(36) NOT NULL,
  `wiederkehrend` int(11) DEFAULT NULL,
  `ausfuehrung` date DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `fiPerson` (`fiPerson`),
  KEY `fiMitarbeiter` (`fiMitarbeiter`),
  CONSTRAINT `bestellung_ibfk_1` FOREIGN KEY (`fiPerson`) REFERENCES `person` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `bestellung_ibfk_2` FOREIGN KEY (`fiMitarbeiter`) REFERENCES `mitarbeiter` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE `Posten` (
  `ID` char(36) NOT NULL,
  `fiArtikel` char(36) NOT NULL,
  `fiBestellung` char(36) NOT NULL,
  `MENGE` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `fiArtikel` (`fiArtikel`),
  KEY `fiBestellung` (`fiBestellung`),
  CONSTRAINT `posten_ibfk_1` FOREIGN KEY (`fiArtikel`) REFERENCES `artikel` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `posten_ibfk_2` FOREIGN KEY (`fiBestellung`) REFERENCES `bestellung` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB;

INSERT INTO `emma`.`Artikel`
(`ID`,
`Name`,
`Preis`,
`Artikeltyp`)
VALUES
(UUID(),"Apfel", 0.36,"Obst"),
(UUID(),"Birne", 0.41,"Obst"),
(UUID(),"Bananen", 1.29,"Obst"),
(UUID(),"Schokolade", 2.32,"Süßwaren"),
(UUID(),"Kakao", 1.83,"Süßwaren"),
(UUID(),"Milch", 0.23,"Milchprodukte"),
(UUID(),"Honig", 0.43,"Süßwaren"),
(UUID(),"Brot", 1.23,"Backwaren"),
(UUID(),"Mega Hero Zeitschrift", 2.49,"Zeitschrift");

INSERT INTO `emma`.`bestand`
(`fiArtikel`,
`RegalNummer`,
`PlatzNummer`,
`Menge`)
VALUES
(1, 3, 1, 7),
(1, 5, 2, 23),
(3, 3, 4, 3),
(7, 2, 5, 4),
(5, 6, 3, 8),
(1, 7, 5, 3),
(2, 3, 2, 11),
(3, 1, 4, 6),
(4, 8, 8, 4),
(6, 9, 3, 14),
(7, 8, 3, 4),
(9, 3, 6, 1),
(5, 1, 8, 9),
(4, 3, 2, 21),
(9, 8, 1, 6);

INSERT INTO `emma`.`person`
(`ID`,`Vorname`,
`Name`,
`Geburtsdatum`,
`Str`,
`Hnr`,
`Plz`,
`Ort`)
VALUES
(UUID(),"Fritz", "Baumgart", "1993-20-04", "Herbst Straße", "2a", "48290", "Köln"),
(UUID(),"Norbert", "Bügelbrett", "2001-03-01", "Brüggen Straße", "2a", "32390", "Köln"),
(UUID(),"Anna", "Weg", "1995-05-03", "Orbit Allee", "2a", "43490", "Köln"),
(UUID(),"Rudolf", "Gather", "1986-02-04", "Troisdorfer Straße", "2a", "43230", "Köln"),
(UUID(),"Arnold", "Black", "1991-05-08", "Zentralen Straße", "2a", "48340", "Köln"),
(UUID(),"Emma", "Rich", "1987-03-02", "Luxenburger Straße", "32", "48340", "Köln");

INSERT INTO `emma`.`Rechte` 
  (`Id`,
  `Status`)
  VALUES 
  (1,"Chef"),
  (2,"Hilfskraft"),
  (3,"Personal");

INSERT INTO `emma`.`mitarbeiter`
(`ID`,`fiRechte`,
`Benutzername`,
`Passwort`,
`Vorname`,
`Name`,
`Geburtsdatum`,
`Str`,
`Hnr`,
`Plz`,
`Ort`)
VALUES
(UUID(),1, "Fabian", "test","Fabian", "Küpper", "1992-03-01", "Brüggen Straße", "14", "50127", "Bergheim"),
(UUID(),2, "Pascal", "test" ,"Pascal", "Lentz", "1992-02-11", "Carl-Benz-Straße", "22", "50171", "Kerpen"),
(UUID(),2, "Julius", "test","Julius", "Jupp-Tupp", "1993-03-12","Brahmsstaße", "33", "32390", "Köln"),
(UUID(),3, "Rudi", "test","Rudi", "Bügelbrett", "2001-03-01", "Petunienweg", "2a", "32390", "Köln");

INSERT INTO `emma`.`bestellung`
(`ID`,
`fiPerson`,
`fiMitarbeiter`,
`wiederkehrend`,
`ausfuehrung`)
VALUES
(UUID(),3, 3, null, null),
(UUID(),3, 2, null, null),
(UUID(),5, 1, null, null),
(UUID(),2, 4, null, null);

INSERT INTO `emma`.`posten`
(`fiArtikel`,
`fiBestellung`,
`MENGE`)
VALUES
(1, 1, 5),
(2, 3, 3),
(3, 2, 8),
(4, 2, 4);


select * from Mitarbeiter;
delete from Mitarbeiter where id = 5;

