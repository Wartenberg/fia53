﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


namespace Tante_Emma.v2.Rechteverwaltung
{
	public partial class Benutzerverwaltung : Form
	{
		public Benutzerverwaltung()
		{
			InitializeComponent();
		}

		private void Benutzerverwaltung_Load(object sender, EventArgs e)
		{
			InitializeTree();
		}

		private void btn_Schließen_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		private void btn_Hinzufügen_Click(object sender, EventArgs e)
		{
			HinzufügenundBearbeiten hb = new HinzufügenundBearbeiten("Benutzer hinzufügen");
			hb.ShowDialog();

			InitializeTree();
		}
		public void InitializeTree()
		{
			if (tv_Benutzer.Nodes.Count > 0)
				tv_Benutzer.Nodes.Clear();

			tv_Benutzer.Nodes.Add("ChefNode", "Chef");
			tv_Benutzer.Nodes.Add("HilfskraftNode", "Hilfskraft");
			tv_Benutzer.Nodes.Add("PersonalNode", "Personal");

			foreach (var Benutzer in Program.BenutzerListe)
			{
				TreeNode Node = new TreeNode(Benutzer.Benutzername);
				Node.Tag = Benutzer;

				if (Benutzer.RechteID == 1)
					tv_Benutzer.Nodes["ChefNode"].Nodes.Add(Node);
				else if (Benutzer.RechteID == 2)
					tv_Benutzer.Nodes["HilfskraftNode"].Nodes.Add(Node);
				else if (Benutzer.RechteID == 3)
					tv_Benutzer.Nodes["PersonalNode"].Nodes.Add(Node);
			}
		}

		private void btn_Entfernen_Click(object sender, EventArgs e)
		{
			if (tv_Benutzer.SelectedNode != null &&
				 tv_Benutzer.SelectedNode.Tag != null &&
				 tv_Benutzer.SelectedNode.Tag is Login.Benutzer)
			{
				(tv_Benutzer.SelectedNode.Tag as Login.Benutzer).DeleteDB();
				tv_Benutzer.Nodes.Remove(tv_Benutzer.SelectedNode);

				InitializeTree();
			}
		}

		private void btn_Bearbeiten_Click(object sender, EventArgs e)
		{
			if (tv_Benutzer.SelectedNode != null &&
				 tv_Benutzer.SelectedNode.Tag != null &&
				 tv_Benutzer.SelectedNode.Tag is Login.Benutzer)
			{
				var Edit = new HinzufügenundBearbeiten("Benutzer bearbeiten");
				Edit.Mitarbeiter = tv_Benutzer.SelectedNode.Tag as Login.Benutzer;
				Edit.ShowDialog();

				InitializeTree();
			}
		}

		private void tv_Benutzer_AfterSelect(object sender, TreeViewEventArgs e)
		{
			if (tv_Benutzer.SelectedNode == tv_Benutzer.Nodes["ChefNode"] ||
				 tv_Benutzer.SelectedNode == tv_Benutzer.Nodes["PersonalNode"] ||
				 tv_Benutzer.SelectedNode == tv_Benutzer.Nodes["HilfskraftNode"])
			{
				btn_Bearbeiten.Enabled = false;
				btn_Entfernen.Enabled = false;
				btn_Hinzufügen.Enabled = false;
			}
			else
			{
				btn_Bearbeiten.Enabled = true;
				btn_Entfernen.Enabled = true;
				btn_Hinzufügen.Enabled = true;
			}
		}
	}
}
