﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace Tante_Emma.v2.Rechteverwaltung
{
    public class Rechte
    {
        private string _Bezeichnung = String.Empty;
        private int _ID = 0;

        public Rechte()
        {

        }

        public Rechte(int Id)
        {
            _ID = Id;
        }

        public string Bezeichnung
        {
            get
            {
                return _Bezeichnung;
            }
        }

        public int ID
        {
            get
            {
                return _ID;
            }
        }

        public void LoadData()
        {
            try
            {
                var con = new MySQL_Anbindung.MySQLConnect();
                string Query = String.Format(@"
                    select * from Rechte where ID='{0}'", this.ID);

                foreach (DataRow row in con.QueryEx(Query).Rows)
                {
                    _Bezeichnung = (string)row["Status"];
                }
            }
            catch (Exception ex)
            {

            }
        }
    }
}
