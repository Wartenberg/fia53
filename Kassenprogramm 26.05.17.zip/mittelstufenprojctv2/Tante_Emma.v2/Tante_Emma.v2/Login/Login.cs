﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


namespace Tante_Emma.v2.Login
{
	public partial class Login : Form
	{
		public Login()
		{
			InitializeComponent();
		}
		#region Login Load
		private void Login_Load(object sender, EventArgs e)
		{
			Benutzer.GetAllBenutzer();

			cb_Username.DataSource = Program.BenutzerListe;
			cb_Username.DisplayMember = "Benutzername";
		}

		#endregion

		#region Button_Click Anmeldung
		private void btn_Anmelden_Click(object sender, EventArgs e)
		{
			if (tb_Passwort.Text == Program.CurrentBenutzer.Passwort)
			{
				this.DialogResult = DialogResult.OK;
			}
			else
			{
				MessageBox.Show("Das Passwort ist ungültig");
			}
		}
		#endregion

		private void cb_Username_SelectedIndexChanged(object sender, EventArgs e)
		{
			Program.CurrentBenutzer = (Benutzer)(sender as ComboBox).SelectedItem;
		}
	}
}
