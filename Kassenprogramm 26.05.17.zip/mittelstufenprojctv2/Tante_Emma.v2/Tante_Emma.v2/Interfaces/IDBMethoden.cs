﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tante_Emma.v2.Interfaces
{
	interface IDBMethoden
	{
		void LoadData();

		void InsertDB();
		void UpdateDB();
		void DeleteDB();

		Guid ID
		{
			get;
			set;
		}
	}
}
