﻿namespace Tante_Emma.v2.Lager
{
    partial class NeuerBestand
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.components = new System.ComponentModel.Container();
			this.btn_OK = new System.Windows.Forms.Button();
			this.btn_Abbrechen = new System.Windows.Forms.Button();
			this.gb_Bestand = new System.Windows.Forms.GroupBox();
			this.nud_Menge = new System.Windows.Forms.NumericUpDown();
			this.lbl_Menge = new System.Windows.Forms.Label();
			this.nud_Platz = new System.Windows.Forms.NumericUpDown();
			this.lbl_Platz = new System.Windows.Forms.Label();
			this.nud_Regal = new System.Windows.Forms.NumericUpDown();
			this.lbl_Regal = new System.Windows.Forms.Label();
			this.BestandBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.gb_Bestand.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.nud_Menge)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.nud_Platz)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.nud_Regal)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.BestandBindingSource)).BeginInit();
			this.SuspendLayout();
			// 
			// btn_OK
			// 
			this.btn_OK.Location = new System.Drawing.Point(12, 141);
			this.btn_OK.Name = "btn_OK";
			this.btn_OK.Size = new System.Drawing.Size(75, 23);
			this.btn_OK.TabIndex = 0;
			this.btn_OK.Text = "Ok";
			this.btn_OK.UseVisualStyleBackColor = true;
			this.btn_OK.Click += new System.EventHandler(this.btn_OK_Click);
			// 
			// btn_Abbrechen
			// 
			this.btn_Abbrechen.Location = new System.Drawing.Point(97, 141);
			this.btn_Abbrechen.Name = "btn_Abbrechen";
			this.btn_Abbrechen.Size = new System.Drawing.Size(75, 23);
			this.btn_Abbrechen.TabIndex = 1;
			this.btn_Abbrechen.Text = "Abbrechen";
			this.btn_Abbrechen.UseVisualStyleBackColor = true;
			this.btn_Abbrechen.Click += new System.EventHandler(this.btn_Abbrechen_Click);
			// 
			// gb_Bestand
			// 
			this.gb_Bestand.Controls.Add(this.nud_Menge);
			this.gb_Bestand.Controls.Add(this.lbl_Menge);
			this.gb_Bestand.Controls.Add(this.nud_Platz);
			this.gb_Bestand.Controls.Add(this.lbl_Platz);
			this.gb_Bestand.Controls.Add(this.nud_Regal);
			this.gb_Bestand.Controls.Add(this.lbl_Regal);
			this.gb_Bestand.Location = new System.Drawing.Point(12, 12);
			this.gb_Bestand.Name = "gb_Bestand";
			this.gb_Bestand.Size = new System.Drawing.Size(160, 120);
			this.gb_Bestand.TabIndex = 6;
			this.gb_Bestand.TabStop = false;
			this.gb_Bestand.Text = "Lagerzugang buchen";
			// 
			// nud_Menge
			// 
			this.nud_Menge.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.BestandBindingSource, "Menge", true));
			this.nud_Menge.Location = new System.Drawing.Point(69, 85);
			this.nud_Menge.Name = "nud_Menge";
			this.nud_Menge.Size = new System.Drawing.Size(70, 20);
			this.nud_Menge.TabIndex = 6;
			// 
			// lbl_Menge
			// 
			this.lbl_Menge.AutoSize = true;
			this.lbl_Menge.Location = new System.Drawing.Point(7, 87);
			this.lbl_Menge.Name = "lbl_Menge";
			this.lbl_Menge.Size = new System.Drawing.Size(33, 13);
			this.lbl_Menge.TabIndex = 5;
			this.lbl_Menge.Text = "Platz:";
			// 
			// nud_Platz
			// 
			this.nud_Platz.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.BestandBindingSource, "Platz", true));
			this.nud_Platz.Location = new System.Drawing.Point(69, 59);
			this.nud_Platz.Name = "nud_Platz";
			this.nud_Platz.Size = new System.Drawing.Size(70, 20);
			this.nud_Platz.TabIndex = 4;
			// 
			// lbl_Platz
			// 
			this.lbl_Platz.AutoSize = true;
			this.lbl_Platz.Location = new System.Drawing.Point(7, 61);
			this.lbl_Platz.Name = "lbl_Platz";
			this.lbl_Platz.Size = new System.Drawing.Size(33, 13);
			this.lbl_Platz.TabIndex = 3;
			this.lbl_Platz.Text = "Platz:";
			// 
			// nud_Regal
			// 
			this.nud_Regal.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.BestandBindingSource, "Regal", true));
			this.nud_Regal.Location = new System.Drawing.Point(69, 33);
			this.nud_Regal.Name = "nud_Regal";
			this.nud_Regal.Size = new System.Drawing.Size(70, 20);
			this.nud_Regal.TabIndex = 2;
			// 
			// lbl_Regal
			// 
			this.lbl_Regal.AutoSize = true;
			this.lbl_Regal.Location = new System.Drawing.Point(7, 35);
			this.lbl_Regal.Name = "lbl_Regal";
			this.lbl_Regal.Size = new System.Drawing.Size(38, 13);
			this.lbl_Regal.TabIndex = 1;
			this.lbl_Regal.Text = "Regal:";
			// 
			// BestandBindingSource
			// 
			this.BestandBindingSource.DataSource = typeof(Tante_Emma.v2.Lager.Bestand);
			// 
			// NeuerBestand
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(190, 181);
			this.Controls.Add(this.gb_Bestand);
			this.Controls.Add(this.btn_Abbrechen);
			this.Controls.Add(this.btn_OK);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "NeuerBestand";
			this.ShowIcon = false;
			this.ShowInTaskbar = false;
			this.gb_Bestand.ResumeLayout(false);
			this.gb_Bestand.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.nud_Menge)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.nud_Platz)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.nud_Regal)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.BestandBindingSource)).EndInit();
			this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_OK;
        private System.Windows.Forms.Button btn_Abbrechen;
        private System.Windows.Forms.GroupBox gb_Bestand;
		private System.Windows.Forms.NumericUpDown nud_Menge;
		private System.Windows.Forms.Label lbl_Menge;
		private System.Windows.Forms.NumericUpDown nud_Platz;
		private System.Windows.Forms.Label lbl_Platz;
		private System.Windows.Forms.NumericUpDown nud_Regal;
		private System.Windows.Forms.Label lbl_Regal;
		private System.Windows.Forms.BindingSource BestandBindingSource;
	}
}