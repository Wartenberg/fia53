﻿using System;
using System.Collections.Generic;
using System.Data;

namespace Tante_Emma.v2.Lager
{
	public class Artikel : Interfaces.IDBMethoden
	{
		#region Private Member
		private Guid _id;
		private string _name;
		private double _preis;
		private string _artikeltyp;
		private int _gesamtmenge;
		private string _artikelnr;
		private List<Bestand> _listBestand;
		#endregion

		#region C'tor
		public Artikel()
		{
			_id = Guid.NewGuid();
			_name = String.Empty;
			_preis = 0.0;
			_artikeltyp = String.Empty;
			_gesamtmenge = 0;
			_artikelnr = String.Empty;
			_listBestand = new List<Bestand>();
		}
		#endregion

		#region Properties
		public Guid ID
		{
			get
			{
				return _id;
			}
			set
			{
				if (value != null && value != Guid.Empty)
					_id = value;
			}
		}

		public string Name
		{
			get
			{
				return _name;
			}
			set
			{ 
				if (!String.IsNullOrEmpty(value) && value != _name)
					_name = value;
			}
		}

		public string Artikeltyp
		{
			get
			{
				return _artikeltyp;
			}
			set
			{
				if (!String.IsNullOrEmpty(value) && value != _name)
					_artikeltyp = value;
			}
		}

		public string ArtikelNr
		{
			get
			{
				return _artikelnr;
			}
			set
			{
				if (!String.IsNullOrEmpty(value) && _artikelnr != value)
					_artikelnr = value;
			}
		}

		public double Preis
		{
			get
			{
				return _preis;
			}
			set
			{
				if (value >= 0.0)
				_preis = value;
			}
		}

		public int Gesamtmenge
		{
			get
			{
				try
				{
					int temp = 0;
					foreach (var bestand in _listBestand)
						temp += bestand.Menge;

					return temp;
				}
				catch
				{
					return 0;
				}
			}
		}

		public List<Bestand> Bestandsliste
		{
			get
			{
				return _listBestand;
			}
		}
		#endregion

		#region DB-Methoden
		public void LoadData()
		{
			try
			{
				var con = new MySQL_Anbindung.MySQLConnect();
				string UpdateQuery = String.Format(@"
                    select * from Artikel where ID='{0}'", this.ID);

				foreach (DataRow row in con.QueryEx(UpdateQuery).Rows)
				{
					Name = (string)row["Name"];
					Preis = (double)row["Preis"];
					Artikeltyp = (string)row["ArtikelTyp"];
					ArtikelNr = (string)row["ArtikelNr"];

					_listBestand = Bestand.GetListByArtikelId(this.ID);
				}
			}
			catch (Exception ex)
			{

			}
		}

		public void UpdateDB()
		{
			try
			{
				var con = new MySQL_Anbindung.MySQLConnect();
				string UpdateQuery = String.Format(@"
                    update Artikel set
                    Name = '{1}',
                    Preis = {2}, 
                    ArtikelTyp = '{3}', 
                    ArtikelNr = '{4}'
                    where ID = '{0}'",
					 ID, Name, Preis.ToString().Replace(',', '.'), Artikeltyp, ArtikelNr);

				con.QueryEx(UpdateQuery);
			}
			catch (Exception ex)
			{

			}
		}

		public void InsertDB()
		{
			try
			{
				var con = new MySQL_Anbindung.MySQLConnect();
				string UpdateQuery = String.Format(@"
                    Insert into Artikel(ID, Name, Preis, ArtikelTyp, ArtikelNr)
                    Values ('{0}', '{1}', {2}, '{3}', '{4}')",
					 ID, Name, Preis.ToString().Replace(',', '.'), Artikeltyp, ArtikelNr);

				con.QueryEx(UpdateQuery);
			}
			catch (Exception ex)
			{

			}
		}

		public void DeleteDB()
		{
			try
			{
				var con = new MySQL_Anbindung.MySQLConnect();
				string UpdateQuery = String.Format(@"
                    Delete from Artikel where Id='{0}'", ID);

				con.QueryEx(UpdateQuery);

				foreach (var bestand in _listBestand)
					bestand.DeleteDB();
			}
			catch (Exception ex)
			{

			}
		}

		public static List<Artikel> GetAllArtikel()
		{
			try
			{
				var listArtikel = new List<Artikel>();

				var con = new MySQL_Anbindung.MySQLConnect();
				var Query = "SELECT ID FROM ARTIKEL;";

				foreach (DataRow row in con.QueryEx(Query).Rows)
				{
					var artikel = new Artikel() { ID = (Guid)row["ID"] };
					artikel.LoadData();
					listArtikel.Add(artikel);
				}

				return listArtikel;
			}
			catch (Exception ex)
			{

			}

			return null;
		}
		#endregion
	}
}
