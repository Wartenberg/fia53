﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Tante_Emma.v2.Lager
{
	public partial class Lieferung : Form
	{
		private static List<Artikel> listArtikel = new List<Artikel>();

		public Lieferung()
		{
			InitializeComponent();
		}

		#region Lieferung Load
		private void Lieferung_Load(object sender, EventArgs e)
		{
			ArtikelBindingSource.DataSource = Artikel.GetAllArtikel();
		}
		#endregion

		private void gb_Produkte_Enter(object sender, EventArgs e)
		{

		}
	}
}

